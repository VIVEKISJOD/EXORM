# EXORM changelog

## Step 2 (after first green build)
- Logo: the user's neon green EXORM image is now the app icon (green background, black EXORM text) and the launch screen image.
- Launch animation: 1.3 seconds (logo grows in 0.6s, holds 0.4s, fades out 0.3s, with a progress line). File: Splash.kt.
- Event form: extra event dates (add/remove), "Advance taken" (saved as a payment with note "Advance", so balances stay right), event follow-up date with a "Delete this follow-up" button.
- Event follow-ups appear in the Follow-ups tab (Followup now has eventId) and get the Call button.
- Delete follow-up: trash button on every follow-up card, and on the event page.
- Calendar shows an event on all of its dates.
- Deleting an event also deletes its follow-up.
- NOT compiled or phone-tested yet. Check the Actions run, then test on the phone.

## Step 3
- In-app update: "Download & install" downloads the APK inside the app with a progress bar, then opens Android's install screen. No browser.
- First time only: Android asks to allow installs from EXORM (permission REQUEST_INSTALL_PACKAGES added). Android always shows its own Install confirmation; apps cannot skip it.

## Step 5
- Events: new "Location map link" box. On the event page, "View location on map" opens a menu: Open in Maps, or Delete location (removes only the link, the venue text stays). Plain addresses also work (opens in Maps search).

## Step 6
- New add-on "Event Equipment List" (Settings → Add-ons, on/off). When on, the event form has "Equipment to use": add items with quantity, delete any row. The event page lists them.
- When you create a collection after an event, the equipment list is filled in automatically (only when the add-on is on).
- Turning off Event Planner also turns this add-on off. Turning it off only hides it; saved lists are kept.
