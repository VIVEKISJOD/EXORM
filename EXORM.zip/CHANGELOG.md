# EXORM changelog

## Step 2 (after first green build)
- Logo: the user's neon green EXORM image is now the app icon (green background, black EXORM text) and the launch screen image.
- Launch animation: 1.3 seconds (logo grows in 0.6s, holds 0.4s, fades out 0.3s, with a progress line). File: Splash.kt.
- Event form: extra event dates (add/remove), "Advance taken" (saved as a payment with note "Advance", so balances stay right), event follow-up date with a "Delete this follow-up" button.
- Event follow-ups appear in the Follow-ups tab (Followup now has eventId) and get the Call button.
- Delete follow-up: trash button on every follow-up card, and on the event page.
- Calendar shows an event on all of its dates.
- Deleting an event also deletes its follow-up.
- NOT compiled or phone-tested yet. Check the Actions run, then test on the phone.

## Step 3
- In-app update: "Download & install" downloads the APK inside the app with a progress bar, then opens Android's install screen. No browser.
- First time only: Android asks to allow installs from EXORM (permission REQUEST_INSTALL_PACKAGES added). Android always shows its own Install confirmation; apps cannot skip it.

## Step 5
- Events: new "Location map link" box. On the event page, "View location on map" opens a menu: Open in Maps, or Delete location (removes only the link, the venue text stays). Plain addresses also work (opens in Maps search).

## Step 6
- New add-on "Event Equipment List" (Settings → Add-ons, on/off). When on, the event form has "Equipment to use": add items with quantity, delete any row. The event page lists them.
- When you create a collection after an event, the equipment list is filled in automatically (only when the add-on is on).
- Turning off Event Planner also turns this add-on off. Turning it off only hides it; saved lists are kept.

## Step 7
- New event without a customer: leave the customer empty and a customer is created for you (from the name/phone you type, or from the event type and date). Quick add -> New event now opens the form straight away.
- Delete event: trash button on every event card, and a "Delete event" button on the edit screen (with a confirm).
- Reports (Home and Calendar): revenue from completed events, received, still to receive, booked ahead, last 6 months chart, and revenue by event type. Filter: This month, Last 3 months, This year, All time.
- Showcase add-on (Settings -> Add-ons, on/off): gallery of decor setups with category (Boy Birthday, Girl Birthday, ...), photos, description and optional raw material and costing (cost, selling price, profit). Photos are stored on the phone and are NOT part of backups.

## Step 8
- Thank-you message: on a Completed event there is a "Send thank-you message" button. Write or edit the message (a default is ready), add photos to send, and WhatsApp opens with everything ready. You can save your own default text. The event shows "Thank-you sent on ...".
