# EXORM changelog

## Step 2 (after first green build)
- Logo: the user's neon green EXORM image is now the app icon (green background, black EXORM text) and the launch screen image.
- Launch animation: 1.3 seconds (logo grows in 0.6s, holds 0.4s, fades out 0.3s, with a progress line). File: Splash.kt.
- Event form: extra event dates (add/remove), "Advance taken" (saved as a payment with note "Advance", so balances stay right), event follow-up date with a "Delete this follow-up" button.
- Event follow-ups appear in the Follow-ups tab (Followup now has eventId) and get the Call button.
- Delete follow-up: trash button on every follow-up card, and on the event page.
- Calendar shows an event on all of its dates.
- Deleting an event also deletes its follow-up.
- NOT compiled or phone-tested yet. Check the Actions run, then test on the phone.

## Step 3
- In-app update: "Download & install" downloads the APK inside the app with a progress bar, then opens Android's install screen. No browser.
- First time only: Android asks to allow installs from EXORM (permission REQUEST_INSTALL_PACKAGES added). Android always shows its own Install confirmation; apps cannot skip it.

## Step 5
- Events: new "Location map link" box. On the event page, "View location on map" opens a menu: Open in Maps, or Delete location (removes only the link, the venue text stays). Plain addresses also work (opens in Maps search).

## Step 6
- New add-on "Event Equipment List" (Settings → Add-ons, on/off). When on, the event form has "Equipment to use": add items with quantity, delete any row. The event page lists them.
- When you create a collection after an event, the equipment list is filled in automatically (only when the add-on is on).
- Turning off Event Planner also turns this add-on off. Turning it off only hides it; saved lists are kept.

## Step 7
- New event without a customer: leave the customer empty and a customer is created for you (from the name/phone you type, or from the event type and date). Quick add -> New event now opens the form straight away.
- Delete event: trash button on every event card, and a "Delete event" button on the edit screen (with a confirm).
- Reports (Home and Calendar): revenue from completed events, received, still to receive, booked ahead, last 6 months chart, and revenue by event type. Filter: This month, Last 3 months, This year, All time.
- Showcase add-on (Settings -> Add-ons, on/off): gallery of decor setups with category (Boy Birthday, Girl Birthday, ...), photos, description and optional raw material and costing (cost, selling price, profit). Photos are stored on the phone and are NOT part of backups.

## Step 8
- Thank-you message: on a Completed event there is a "Send thank-you message" button. Write or edit the message (a default is ready), add photos to send, and WhatsApp opens with everything ready. You can save your own default text. The event shows "Thank-you sent on ...".

## Step 9 - Leads (part A: the Leads list, no auto-call yet)
- New add-on "Leads (JustDial)" (Settings -> Add-ons). It is OFF by default. Turning it off only hides it; your leads are kept.
- When it is on, Home shows a "Leads" button. The Leads screen has two tabs: Today and All time, newest first. Leads marked "Not interested" are hidden from Today but stay in All time.
- Each lead card shows name, place, service, received time, number (or "not known yet"), and call result (Called / Failed / Skipped / "Not called"). Status chips: New, Called, Replied, Talked, Follow-up, Not interested. "Edit / note" opens a form with a free note box. A Call button (opens the dialer) and a WhatsApp chip show when a number is known.
- "Confirmed" is the ONLY thing that makes a real customer. If the lead has no number it asks you to type it first. If the number already belongs to a customer, you get the same warning as the customer form (Use existing / Save anyway / Cancel). After that the lead is marked Converted and has an "Open customer" button.
- Until you tap Confirmed, leads do not appear in Customers, Follow-ups, Calendar, Reports or Home totals.
- Buttons: Add lead, Test lead (adds a fake lead after a confirm), delete one lead (with confirm; a customer already made from it is kept).
- Leads are saved in the same data file and in backups. Old backups still load (leads are optional).
- Not built yet: auto-call, reading numbers from the call log, JustDial notification reading (that is the next step). The call-result field is only filled by the next step; for now cards show "Not called".
- NOT compiled or phone-tested yet. Check the Actions run first, then test.

## Step 10 - Auto-call for JustDial leads (part B)
- Leads screen has one big ON/OFF switch "Auto-call new JustDial leads". It is saved between app launches, but after a phone restart it is OFF again and you turn it on yourself (no boot receiver). It will not turn ON until the setup checklist has the JustDial app, notification access, accessibility and phone state permission.
- ON: a notification "Auto-call is ON" stays in the status bar (foreground service). OFF: nothing is called; new leads are still recorded as "Skipped: switch OFF" and are never called later.
- How it works: EXORM reads the JustDial lead notification (name and place), opens that lead in JustDial, taps the blue Call button (and one more button if a pop-up or the dialer asks), then reads the number from your call log after the call and fills it into the lead.
- Loud sound: when EXORM starts calling a new lead it plays the alarm sound at full alarm volume. It stops when the call starts, when something fails, when you tap Stop sound, or after 60 seconds.
- Each customer is called only once. EXORM keeps its own called list (by phone number when known, otherwise by name + place). Deleting or clearing leads does not reset it. "Reset called list" on the Leads screen resets it (with confirm). Manual Call from a lead card always works.
- Calls are at least 30 seconds apart; extra leads wait in a queue.
- Setup checklist screen (Leads -> Setup checklist): green/red for notification access, accessibility, call permission, call log permission, phone state, notifications, display over other apps; choose the JustDial app from your installed apps; optional filter word; Xiaomi/HyperOS steps with buttons (restricted settings, Autostart, battery, pop-ups, lock in recents).
- Test lead now runs the same rules: switch OFF = "Skipped: switch OFF"; ON = loud sound, then a real call straight to the test number. It does not test the JustDial tapping.
- Failures show on the lead as "Failed: <reason>", and the card keeps its Call button.
- Home: the section "New enquiries without a follow-up" is removed.
- Honest limits: the phone screen must be on and unlocked; a JustDial update can break the tapping; the number appears in the lead only after the call ends; not compiled or phone-tested.
