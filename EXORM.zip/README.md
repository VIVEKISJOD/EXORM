# EXORM

Offline-first business app for Android (Kotlin + Jetpack Compose). Customers, follow-ups with one-tap dialer,
and optional add-ons: **Event Planner** (calendar, quotations with revisions + PDF, payments) and
**Equipment Collection** (post-event collection tasks, item by item).

Data is stored only on the phone (one private JSON file). Backup/restore and CSV export are in Settings.

## Build and install (phone only)
1. Create a **public** GitHub repository (public is needed so installed apps can see updates).
2. Add the file `.github/workflows/build.yml` (copy from this project).
3. Upload `EXORM.zip` to the repository root (Add file → Upload files). Commit.
4. Open the **Actions** tab, wait for the green tick (about 5–8 minutes).
5. Open **Releases**, download `EXORM.apk`, install it (allow "install unknown apps" for your browser).

## Updating
Upload a new `EXORM.zip` (same name, replace) or edit the source files. Every push builds a new release.
Installed apps check Releases on start and offer **Download** when a newer build exists. Data is kept.

## Logo
Replace `app/src/main/res/drawable/ic_launcher_foreground.xml` with your own `ic_launcher_foreground.png`
(delete the .xml). Keep important parts of the logo in the centre 60% of the image.

## Signing
`exorm-release.jks` is a personal side-loading key included so every build has the same signature
(required for updates to install over the old version). Do not publish to the Play Store with it.
