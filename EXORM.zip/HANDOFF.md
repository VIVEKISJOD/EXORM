# EXORM — Full Handoff for another AI

Paste this whole file into the new chat, and attach EXORM.zip (the current project) and the original master prompt.

## 1. Who and what
- User: beginner, no coding knowledge, works ONLY from an Android phone via GitHub web (no PC, no Android Studio). Wants complete files, not snippets. Wants one ZIP they can upload straight to GitHub.
- Business: SHAGUN SFX AND DECOR (Diwali/wedding/ring-ceremony decoration and special effects).
- App name: **EXORM**. Native Android (Kotlin + Jetpack Compose), package `com.exorm.app`, minSdk 26, targetSdk/compileSdk 34.
- Original brief = "MASTER PROMPT — SHAGUN SFX AND DECOR BUSINESS MANAGEMENT APP" (customers, follow-up tracker, quotations with revisions + PDF, event calendar, leftover equipment collection as a core workflow, inventory, payments, reports/CSV/backup, WhatsApp/dialer shortcuts, offline-first, no paid services). Priority order from that prompt: 1 customer/event records, 2 follow-ups and quotations, 3 equipment collection reminders and inventory accuracy, 4 payments, 5 UI polish, 6 reports.

## 2. Extra requests the user made in chat
1. Name it EXORM; deliver in ONE zip for direct GitHub upload; do everything "in one go".
2. Logo: DONE in Step 2. User sent a neon green image with black "EXORM" text. Used as the app icon (green background `#2BE600`, black text, `drawable-nodpi/ic_launcher_foreground.png`) and as the launch image (`drawable-nodpi/exorm_logo.png`).
3. **Add-ons** option in Settings that changes what the app does per business type (e.g. event planner gets event dates, calendar, quotations given to customers, follow-ups).
4. Follow-up cards must have a **Call button that opens the phone dialer**.
5. **Auto-update**: when the GitHub repo is updated, users get the update.
6. **Theme: AMOLED black + glass with blur effects.**
7. UI references (screenshots): dark CRM with yellow rounded cards (customer network, customer info with task calendar, interaction history); light purple calendar + add-event form; blue/orange quotation list and extra-charge form. Direction used: pure black, translucent glass cards, yellow accent (#EAE35E), pill bottom bar, round icon buttons, month calendar with dots.

## 3. Delivery / build pipeline
- Repo must be **public** (the in-app updater calls the unauthenticated GitHub API).
- User creates `.github/workflows/build.yml` by pasting its text (GitHub web "Create new file"), then uploads `EXORM.zip` to repo root.
- Workflow (ubuntu-latest, JDK 17, `gradle/actions/setup-gradle` with Gradle 8.9, no wrapper jar): unzips any `*.zip` at root (excluding `.github/*`, nothing committed back), runs `gradle :app:assembleRelease`, copies APK to `EXORM.apk`, uploads artifact, then `gh release create v<run_number> EXORM.apk`.
- Versioning: `versionCode = GITHUB_RUN_NUMBER`, `versionName = 1.0.<run>`; `BuildConfig.GITHUB_REPO` comes from `GITHUB_REPOSITORY`. Local builds use `OWNER/REPO` and skip update checks.
- Signing: `exorm-release.jks` committed in repo root (alias `exorm`, password `exorm123`, validity 100 years) so every build has the same signature, which is required for updates to install over old versions. Personal side-loading only; not for Play Store.
- Updater (`Updater` in Util.kt): GET `/repos/{repo}/releases/latest`, tag digits compared to `BuildConfig.VERSION_CODE`; if newer, `UpdateDialog` (Components.kt) downloads the APK in-app (`Updater.download`, progress bar, saved to cacheDir/EXORM-update.apk) and opens Android's install screen via FileProvider (`Updater.install`). First time the user must allow "install unknown apps" for EXORM (manifest has REQUEST_INSTALL_PACKAGES). Android always shows its own install confirmation; fully silent install is not possible. (Step 3; not yet built/tested.)
- `lint { abortOnError=false; checkReleaseBuilds=false }` is set to avoid lint failing the release build.
- Gradle: AGP 8.5.2, Kotlin 1.9.24, Compose compiler 1.5.14, Compose BOM 2024.09.00, activity-compose 1.9.2, core-ktx 1.13.1, material3, material-icons-core. No Room, no KSP/kapt, no other plugins (deliberately, to reduce build risk).

## 4. STATUS — important
- Step 1 build (first zip): GitHub Actions went green after fixing a line broken across two lines in build.yml (`github.sha`). The workflow now passes run number and commit as env vars (RUN_NUMBER, COMMIT_SHA).
- Step 2 zip (see section 10) has NOT been built or phone-tested yet. Next AI: ask the user for the Actions result first.
- Original note: **the code was written without being compiled or run** (no network/Android SDK in the authoring sandbox; only bracket balance was checked). Expect possible compile errors on the first GitHub Actions run. First job for the next AI: get the Actions log (red lines) from the user and fix compile errors, then test on the phone. No automated tests exist.

## 5. Architecture and file map (`app/src/main/java/com/exorm/app/`)
- `Models.kt` — data classes with hand-written JSON (org.json): Customer, Followup, QItem, Quote (items, discount, taxPct, status, validUntil, notes, `history` list of previous-version strings, derived `effStatus()` → Expired), Payment, Event (payments list, `collect` = ""/yes/no/unsure, `paid`, `balance`), CItem (name, qty, got, missing, damaged), Collect (derived `eff()` status; stored status only Active/Cancelled/Issue Reported), Settings (business, bizPhone, currency, cc, addons set, reminders, autoUpdate, onboarded), Addon list (`events`, `collections`; collections requires events), `addon(id)`/`setAddon`.
- `Store.kt` — singleton, snapshot state lists, single private file `filesDir/exorm_data.json` (atomic tmp+rename), `put/remove`, cascade deletes, `toJson/load/validate` (backup format: `{"app":"EXORM","schema":1,...}`), `save()` also re-syncs reminders.
- `Util.kt` — formatting (₹ via Settings.currency, Indian grouping), date helpers, `dial` (ACTION_DIAL), `whatsapp` (wa.me with country code, default 91), date/time pickers, share helpers (FileProvider authority `<pkg>.files`, cache dir), quote numbering `Q-YYYY-0001`, quote share text, `Reminders` (AlarmManager `setAndAllowWhileIdle`, inexact so no exact-alarm permission; keys `f:`/`c:`/`e:`; follow-up at its time, collection 9:00 on its date, event 9:00 the day before for Confirmed/In Progress), `Updater`, `PdfMaker` (android.graphics.pdf, local).
- `Receivers.kt` — `ExormApp`, `ReminderReceiver` (re-validates the item still exists/open before notifying; tap opens customer via `customerId` extra), `BootReceiver` (reschedules).
- `Components.kt` — theme, `GlassBackground` (black + blurred radial glows), `Glass` card, buttons, chips, `TF`, `DateField`, dialogs, `BottomBar`.
- `MainActivity.kt` — `Screen` sealed interface, `Nav` object (own simple back stack, no Navigation library), root composable, quick-add dialog, notification permission request (API 33+), update check on start, first-launch add-on welcome dialog.
- `ScreensA.kt` — Home dashboard, Customers (+ edit with duplicate-phone warning, detail), Follow-ups (Today/Overdue/Upcoming/Completed/Not interested), `LogDialog`, `ScheduleDialog`, `MessageDialog` (editable WhatsApp templates, nothing auto-sent).
- `ScreensB.kt` — Calendar (month grid; hollow dot = enquiry/tentative = not booked), Event edit/detail (payments, status chips, completion prompt), `CollectPrompt` (the three choices), Quotes list/edit (revisions kept in `history`)/detail (PDF share + text share).
- `ScreensC.kt` — Collections list (Pending/Today/Soon/Overdue/Partial/Issues/Done/All + "decide: not sure yet"), Collection detail (planned date editable, +2/+3 day buttons, tick items individually, missing/damaged qty, notes, report issue, cancel), Add-ons screen, Settings (business info, reminders switch, backup create/restore with validation + confirm, customers CSV, update check).
- Res: manifest (INTERNET, POST_NOTIFICATIONS, RECEIVE_BOOT_COMPLETED, FileProvider, receivers), black theme, adaptive icon (placeholder vector `drawable/ic_launcher_foreground.xml`; to use the user's logo delete it and add `ic_launcher_foreground.png`).

## 6. Design decisions worth knowing
- Event completion and equipment collection are separate: marking Completed only asks the 3-way question; nothing is auto-collected. Default collection date = event date + 2 days, editable, and never silently overwritten (changing an event date shows a "move collection / keep" dialog).
- Quotes are never counted as revenue; Home "balance to receive" uses agreed minus paid for Confirmed/In Progress/Completed events only.
- Payment dialog blocks amounts above remaining balance when an agreed amount is set.
- Reminders are local only; a reminder never marks anything contacted/collected.
- Add-ons only hide features; data is retained.
- Data is JSON file, not Room (master prompt preferred Room; changed for build reliability since nothing could be compiled). Storage is isolated in `Store`, so Room/sync can be added later.
- Backups are NOT encrypted; the app does not claim otherwise.

## 7. Not built yet (remaining from the master prompt)
1. Inventory module (items, owned/available/assigned/awaiting/missing/damaged, assign to events, overlap/insufficient-stock warnings, update stock from actual collection).
2. Reports screen (enquiries vs confirmed, quote accept/reject, payments by period, revenue, missing/damaged equipment); payments-received-in-period.
3. Overdue-payment due dates. (Advance field done in Step 2, stored as a payment with note "Advance".)
4. Global search across quotes/venues/equipment; richer filters (service type, payment status).
5. Equipment assigned to events; collection photos.
6. Event reminders for prep deadlines (setup date field doesn't exist yet); event end time; "services booked" field.
7. Unit tests (balances, quote totals, collection status, dates); instrumented checks.
8. (Logo done.) In-app (non-browser) APK install; optional encryption.
9. Phone/tablet responsive layouts beyond the single-column phone layout.

## 8. Suggested next steps for the new AI
1. Ask the user for the GitHub Actions error log (or confirm it built), fix compile errors, keep delivering a FULL zip each time (user uploads zip → workflow builds → release → app updates).
2. Have the user test: customer add, duplicate warning, follow-up call button, quote PDF share, event → Completed → collection prompt, notifications permission, backup/restore.
3. Then build stage 2 (inventory + collection↔inventory link + reports), then tests.
4. Keep a CHANGELOG/HANDOFF with each zip; never claim a feature is verified unless the build and a phone test confirm it.

## 9. User preferences observed
Beginner; phone-only; wants everything in a single zip with minimal manual steps; hates placeholders/fake buttons; likes keeping a handoff file per step; reference-driven UI (screenshots); wants honest status.

## 10. Step 2 — what changed (current zip)
Files touched: Models.kt, Store.kt, ScreensA.kt, ScreensB.kt, MainActivity.kt, app/build.gradle.kts (added `androidx.compose.animation:animation`), new Splash.kt, res (logo PNGs, colors.xml `icon_bg` = #2BE600, old `ic_launcher_foreground.xml` deleted), CHANGELOG.md, HANDOFF.md, .github/workflows/build.yml.
- **Launch animation** (`SplashOverlay` in Splash.kt): exactly 1.3 s = logo scales/fades in 0.6 s, holds 0.4 s, fades out 0.3 s, plus a green progress line. Shown once per launch via `rememberSaveable` in `ExormRoot`; the welcome add-on dialog waits until it ends.
- **Event form** (`EventEditScreen`): "More event dates" (add/remove extra dates, stored in `Event.dates`); "Advance taken" (creates/updates/removes a Payment with note exactly "Advance"; blocked if advance + other payments exceed agreed amount); "Event follow-up date & time" with a red "Delete this follow-up" button (the date field also has its own X).
- **Event follow-ups**: saved as a normal `Followup` with new field `eventId`, so they show in the Follow-ups tab with the Call button and get reminders. Editing the event updates it; clearing the date deletes it; deleting the event deletes it (`Store.deleteEvent`).
- **Delete follow-up**: trash button on every `FollowRow` (with confirm) and on the Event detail page. Event detail also shows extra dates and the follow-up.
- **Calendar** shows an event on all its dates (`Event.allDays()`); the event card still shows the main date.
- Old backups still load (new fields are optional).
- Known limits: day reminders (9:00 the day before) use only the main event date; the extra-date days have no separate reminder.

## 11. Rule from the user
Every zip must come with an updated handoff file (this file) and CHANGELOG.md. Deliver the full zip plus EXORM_HANDOFF.md every time.

## 12. Step 3
In-app update download + install added (see section 3 Updater and CHANGELOG.md). Not yet built or phone-tested. To test: it needs a NEWER release than the installed build, so build twice.

## 13. Step 4 — repo README
User said the app needs nothing more for now and asked for the repo to be made ready for users. `README.md` (user-facing: features, install, in-app update, data/privacy, permissions, owner build steps) is uploaded DIRECTLY to the repo root, not inside the zip (the workflow never commits unzipped files back, so a README inside the zip would never show on GitHub). No code changed in this step.
Open risk to tell the user: `exorm-release.jks` and its password are in the public repo, so anyone could sign an APK with the same key. Fine for personal use; consider moving the key to GitHub Secrets before sharing widely.

## 14. Step 5 — map link
`Event.mapLink` (new optional field). Edit form has a map-link box under Venue. Event detail shows "View location on map" -> dialog with Open in Maps (`openMap` in Util.kt: http/geo links open directly, bare domains get https://, other text becomes a geo: search) and Delete location. Not yet built/tested. README.md (uploaded directly to repo) does not mention the map link yet; mention it next time README is touched.

## 15. Step 6 — event equipment list
New add-on id `equipment` (ADDONS in Models.kt; `setAddon` makes it need `events`; turning events off removes `collections` and `equipment`). `Event.equipment: List<CItem>` (reuses CItem; only name/qty used). `EventEditScreen`: section shown only if `addon("equipment")` (rows: name, qty, delete; "Add equipment" button; blank names dropped on save, qty min 1). Event detail lists them. `CollectPrompt` pre-fills a new Collect's items from `e.equipment` when the add-on is on. Not yet built/tested. README does not list this add-on yet.

## 16. Step 7 — auto customer, delete event, reports, showcase
Files: new Reports.kt and Showcase.kt; edited Models.kt (RawItem, Showcase, Addon "showcase"), Store.kt (showcases list, in backup JSON, deleteShowcase), MainActivity.kt (Screens Reports, Showcase, ShowcaseDetail, ShowcaseEdit), ScreensA.kt (Home buttons), ScreensB.kt (EventRow trash, EventEdit auto customer + delete, Calendar buttons).
- **Auto customer**: `EventEditScreen.commit` creates a `Customer` when `cust` is blank (name from the optional box, else "<type> customer - <date>"; phone from optional box; requirement = type + venue; notes "Created automatically from an event"). No customer is required any more. Quick add -> New event goes straight to the form.
- **Delete event**: `EventRow` has a trash icon + Confirm; edit screen has a Delete event button (pops edit and detail screens). Both call `Store.deleteEvent`.
- **Reports** (`ReportsScreen`): completed events only; revenue = agreed amount, or money received if agreed is 0. Range chips filter by event date month. Bar chart = last 6 months, by-type list with bars. Entry points: Home buttons row and Calendar buttons row (needs Event Planner add-on).
- **Showcase** (add-on id `showcase`, independent of Event Planner): `Showcase(title, category, desc, images, materials: List<RawItem(name, qty text, cost)>, price)`. Photos are picked with GetMultipleContents, shrunk to <=2000px, EXIF-rotated and saved as JPEG in `filesDir/showcase/` (`ShowImages`); shown with `ShowImage` (own bitmap loader, no library). Backup JSON has the showcase text data only, NOT the photos; restoring a backup on another phone gives showcases without pictures. Possible future step: include photos in backup (zip).
- Not yet built or phone-tested. Biggest compile risk areas: Showcase.kt (ExifInterface, activity-result picker) and the new EventEdit code.
- README.md needs the new features added (it is uploaded directly to the repo, not through the zip).

## 17. Step 8 — thank-you message with photos
New file ThankYou.kt: `ThankYouDialog(e, c)`, `sendThanks(ctx, phone, text, files)`, `FileImage`, `DEFAULT_THANKS` (placeholders {name} {event} {biz}). New fields: `Event.thankedAt`, `Settings.thanksMsg` (user's saved default; "Save as my default" in the dialog). Button appears in `EventDetailScreen` when status is Completed and the customer exists.
- Photos: picked with GetMultipleContents (max 10), copied to `cacheDir/share/` (FileProvider path `.` already covers cache), cleared each time the dialog opens. Not stored long term.
- Sending: no photos + phone -> existing `whatsapp()` (wa.me link). Photos -> ACTION_SEND / SEND_MULTIPLE straight to com.whatsapp or com.whatsapp.w4b with the unofficial `jid` extra to open that contact's chat; falls back to the Android share sheet. No phone -> share sheet. The text is also copied to the clipboard because WhatsApp sometimes drops the caption when several photos are sent. The app never sends anything itself; the user taps Send in WhatsApp.
- The `jid` extra is unofficial and could stop working in a future WhatsApp version (then the user just picks the contact).
- Not yet built or phone-tested. README still needs: Reports, Showcase, auto customer, thank-you message (a refreshed README.md is waiting in outputs, upload it directly to the repo after the build is green).
