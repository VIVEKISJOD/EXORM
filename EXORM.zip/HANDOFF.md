# EXORM handoff (stage 1)

## Implemented (written, NOT yet compiled or run by the author)
- Customers: add/edit/search/archive/delete, duplicate-phone warning, call + WhatsApp, message templates.
- Follow-ups: schedule, log conversation (said, price, interest, objection, promise, next date), Today/Overdue/Upcoming/Completed/Not interested, Call button opens dialer.
- Reminders: local notifications (follow-ups, event day-before, collections), re-scheduled after reboot, tap opens customer.
- Add-ons (Settings): Event Planner, Equipment Collection.
- Event Planner: events + calendar (tentative shown as not booked), quotations with revision history + PDF share, payments and balances.
- Collections: prompt on Completed, separate task, +2/+3 days, item-by-item tick, missing/damaged, statuses, date-change warning.
- Backup/restore (validated, confirm before replace), customers CSV export, GitHub-release update check.

## Not built yet
Inventory/stock module, reports screen, notes photos, event equipment assignment, encryption, automated tests.

## Next step
Build in GitHub Actions, fix any compile errors reported in the log, then test on a phone.

## Step 2 update
See CHANGELOG.md. Added: logo/icon from user image, 1.3s launch animation (Splash.kt), event extra dates, advance taken, event follow-up date, delete follow-up. Followup.eventId and Event.dates are new fields (old backups still load).
