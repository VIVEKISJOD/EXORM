plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// GitHub Actions supplies these automatically. Locally they fall back to defaults.
val runNumber = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
val repo = System.getenv("GITHUB_REPOSITORY") ?: "OWNER/REPO"

android {
    namespace = "com.exorm.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.exorm.app"
        minSdk = 26
        targetSdk = 34
        versionCode = runNumber
        versionName = "1.0.$runNumber"
        buildConfigField("String", "GITHUB_REPO", "\"$repo\"")
    }

    signingConfigs {
        create("exorm") {
            storeFile = file("../exorm-release.jks")
            storePassword = "exorm123"
            keyAlias = "exorm"
            keyPassword = "exorm123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("exorm")
        }
        debug {
            signingConfig = signingConfigs.getByName("exorm")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(bom)
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
}
