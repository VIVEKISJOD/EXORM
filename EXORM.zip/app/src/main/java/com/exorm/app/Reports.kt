package com.exorm.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private fun monthKey(ms: Long): Int {
    val c = Calendar.getInstance(); c.timeInMillis = ms
    return c.get(Calendar.YEAR) * 12 + c.get(Calendar.MONTH)
}

/** Revenue of a finished event: the agreed amount, or the money received if no amount was set. */
private fun revenueOf(e: Event): Long = if (e.agreed > 0) e.agreed else e.paid

private fun shortMoney(v: Long): String = when {
    v >= 10000000 -> String.format(Locale.US, "%.1fCr", v / 10000000.0)
    v >= 100000 -> String.format(Locale.US, "%.1fL", v / 100000.0)
    v >= 1000 -> String.format(Locale.US, "%.0fk", v / 1000.0)
    else -> v.toString()
}

@Composable
fun ReportsScreen() {
    val ranges = listOf("This month", "Last 3 months", "This year", "All time")
    var range by remember { mutableStateOf("This year") }
    val now = System.currentTimeMillis()
    val nowKey = monthKey(now)
    val yearNow = nowKey / 12

    fun inRange(e: Event): Boolean {
        val k = monthKey(e.date)
        return when (range) {
            "This month" -> k == nowKey
            "Last 3 months" -> k in (nowKey - 2)..nowKey
            "This year" -> k / 12 == yearNow
            else -> true
        }
    }

    val allDone = Store.events.filter { it.status == "Completed" && it.date > 0 }
    val done = allDone.filter { inRange(it) }
    val revenue = done.sumOf { revenueOf(it) }
    val received = done.sumOf { it.paid }
    val pending = done.sumOf { it.balance.coerceAtLeast(0) }
    val avg = if (done.isNotEmpty()) revenue / done.size else 0L
    val t0 = startOfDay(now)
    val booked = Store.events.filter { (it.status == "Confirmed" || it.status == "In Progress") && it.date >= t0 }.sumOf { it.agreed }

    val months = (5 downTo 0).map { addMonths(now, -it) }
    val monthVals = months.map { m -> val k = monthKey(m); allDone.filter { monthKey(it.date) == k }.sumOf { revenueOf(it) } }
    val maxMonth = (monthVals.maxOrNull() ?: 0L).coerceAtLeast(1L)
    val byType = done.groupBy { it.type.trim().ifBlank { "Other" } }
        .map { (t, l) -> Triple(t, l.size, l.sumOf { revenueOf(it) }) }.sortedByDescending { it.third }
    val maxType = (byType.firstOrNull()?.third ?: 0L).coerceAtLeast(1L)

    Page("Reports", back = true) {
        ChipRow(ranges, range) { range = it }
        Glass(tint = Accent) {
            T("Revenue from completed events", 12, color = Color(0xAA000000))
            T(fmtMoney(revenue), 32, true, Color.Black)
            T(done.size.toString() + (if (done.size == 1) " event done" else " events done") + (if (done.isNotEmpty()) " • average " + fmtMoney(avg) else ""), 12, color = Color(0xAA000000))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Received", fmtMoney(received), Modifier.weight(1f)) { }
            Stat("Still to receive", fmtMoney(pending), Modifier.weight(1f)) { }
        }
        Stat("Booked ahead (confirmed events)", fmtMoney(booked), Modifier.fillMaxWidth()) { }

        Glass {
            T("Last 6 months", 15, true)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().height(140.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                months.forEachIndexed { i, m ->
                    val v = monthVals[i]
                    val h = if (v > 0) maxOf(4f, 84f * v / maxMonth) else 2f
                    Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        if (v > 0) T(shortMoney(v), 9, color = Muted, maxLines = 1)
                        Spacer(Modifier.height(4.dp))
                        Box(Modifier.fillMaxWidth().height(h.dp).clip(RoundedCornerShape(8.dp)).background(if (v > 0) Accent else Color.White.copy(alpha = .10f)))
                        Spacer(Modifier.height(4.dp))
                        T(SimpleDateFormat("MMM", Locale.getDefault()).format(Date(m)), 10, color = Muted, maxLines = 1)
                    }
                }
            }
        }

        Section("By event type")
        if (byType.isEmpty()) Empty("No completed events in this period yet. Mark an event as Completed and it shows up here.")
        byType.forEach { (t, n, amt) ->
            Glass {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { T(t, 15, true, maxLines = 1); T(n.toString() + (if (n == 1) " event" else " events"), 12, color = Muted) }
                    T(fmtMoney(amt), 15, true)
                }
                Spacer(Modifier.height(8.dp))
                val frac = (amt.toFloat() / maxType.toFloat()).coerceIn(0.03f, 1f)
                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = .10f))) {
                    Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(Accent))
                }
            }
        }
        T("Revenue counts completed events only. It uses the agreed amount, or the money received when no amount was set.", 11, color = Muted)
    }
}
