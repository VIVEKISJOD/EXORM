package com.exorm.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.io.File

/** Offline-first storage. All data lives in one JSON file inside the app's private storage. */
object Store {
    lateinit var appCtx: Context
    private lateinit var file: File
    private var ready = false

    val customers = mutableStateListOf<Customer>()
    val followups = mutableStateListOf<Followup>()
    val quotes = mutableStateListOf<Quote>()
    val events = mutableStateListOf<Event>()
    val collections = mutableStateListOf<Collect>()
    val showcases = mutableStateListOf<Showcase>()
    val leads = mutableStateListOf<Lead>()
    var settings by mutableStateOf(Settings())

    fun init(ctx: Context) {
        if (ready) return
        appCtx = ctx.applicationContext
        file = File(appCtx.filesDir, "exorm_data.json")
        if (file.exists()) {
            try { load(JSONObject(file.readText())) } catch (e: Exception) {
                runCatching { file.copyTo(File(appCtx.filesDir, "exorm_data_unreadable.json"), true) }
            }
        }
        ready = true
    }

    fun load(o: JSONObject) {
        customers.clear(); customers.addAll(o.optJSONArray("customers")?.mapObj { Customer.fromJ(it) } ?: emptyList())
        followups.clear(); followups.addAll(o.optJSONArray("followups")?.mapObj { Followup.fromJ(it) } ?: emptyList())
        quotes.clear(); quotes.addAll(o.optJSONArray("quotes")?.mapObj { Quote.fromJ(it) } ?: emptyList())
        events.clear(); events.addAll(o.optJSONArray("events")?.mapObj { Event.fromJ(it) } ?: emptyList())
        collections.clear(); collections.addAll(o.optJSONArray("collections")?.mapObj { Collect.fromJ(it) } ?: emptyList())
        showcases.clear(); showcases.addAll(o.optJSONArray("showcases")?.mapObj { Showcase.fromJ(it) } ?: emptyList())
        leads.clear(); leads.addAll(o.optJSONArray("leads")?.mapObj { Lead.fromJ(it) } ?: emptyList())
        settings = o.optJSONObject("settings")?.let { Settings.fromJ(it) } ?: Settings()
    }

    fun toJson(): JSONObject = JSONObject().put("app", "EXORM").put("schema", 1).put("exportedAt", System.currentTimeMillis())
        .put("customers", customers.toList().toJA { it.toJ() }).put("followups", followups.toList().toJA { it.toJ() })
        .put("quotes", quotes.toList().toJA { it.toJ() }).put("events", events.toList().toJA { it.toJ() })
        .put("collections", collections.toList().toJA { it.toJ() }).put("showcases", showcases.toList().toJA { it.toJ() }).put("leads", leads.toList().toJA { it.toJ() }).put("settings", settings.toJ())

    /** Returns the parsed backup only if it really is an EXORM backup. */
    fun validate(text: String): JSONObject? = try {
        val o = JSONObject(text)
        if (o.optString("app") == "EXORM" && o.has("customers")) {
            // make sure every record parses before we let it replace anything
            o.optJSONArray("customers")?.mapObj { Customer.fromJ(it) }
            o.optJSONArray("followups")?.mapObj { Followup.fromJ(it) }
            o.optJSONArray("quotes")?.mapObj { Quote.fromJ(it) }
            o.optJSONArray("events")?.mapObj { Event.fromJ(it) }
            o.optJSONArray("collections")?.mapObj { Collect.fromJ(it) }
            o.optJSONArray("showcases")?.mapObj { Showcase.fromJ(it) }
            o.optJSONArray("leads")?.mapObj { Lead.fromJ(it) }
            o
        } else null
    } catch (e: Exception) { null }

    fun save() {
        if (!ready) return
        try {
            val tmp = File(file.path + ".tmp")
            tmp.writeText(toJson().toString())
            tmp.renameTo(file)
        } catch (e: Exception) { }
        runCatching { Reminders.sync(appCtx) }
    }

    fun <T : HasId> put(list: MutableList<T>, x: T) {
        val i = list.indexOfFirst { it.id == x.id }
        if (i >= 0) list[i] = x else list.add(x)
        save()
    }

    fun <T : HasId> remove(list: MutableList<T>, id: String) { list.removeAll { it.id == id }; save() }

    fun updateSettings(s: Settings) { settings = s; save() }

    fun deleteCustomer(id: String) {
        val evIds = events.filter { it.customerId == id }.map { it.id }
        followups.removeAll { it.customerId == id }
        quotes.removeAll { it.customerId == id }
        collections.removeAll { it.customerId == id || it.eventId in evIds }
        events.removeAll { it.customerId == id }
        customers.removeAll { it.id == id }
        save()
    }

    fun deleteShowcase(id: String) {
        showcases.find { it.id == id }?.images?.forEach { ShowImages.delete(appCtx, it) }
        showcases.removeAll { it.id == id }
        save()
    }

    fun deleteEvent(id: String) {
        followups.removeAll { it.eventId == id }
        collections.removeAll { it.eventId == id }
        events.removeAll { it.id == id }
        save()
    }
}
