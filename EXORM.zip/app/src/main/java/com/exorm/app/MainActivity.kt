package com.exorm.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

sealed interface Screen {
    object Home : Screen
    object Customers : Screen
    object Followups : Screen
    object Calendar : Screen
    object Quotes : Screen
    object Collections : Screen
    object Settings : Screen
    object Addons : Screen
    object Reports : Screen
    object Showcase : Screen
    object Leads : Screen
    object LeadSetup : Screen
    data class ShowcaseDetail(val id: String) : Screen
    data class ShowcaseEdit(val id: String?) : Screen
    data class CustomerDetail(val id: String) : Screen
    data class CustomerEdit(val id: String?) : Screen
    data class EventDetail(val id: String) : Screen
    data class EventEdit(val id: String?, val customerId: String? = null) : Screen
    data class QuoteDetail(val id: String) : Screen
    data class QuoteEdit(val id: String?, val customerId: String? = null) : Screen
    data class CollectionDetail(val id: String) : Screen
}

object Nav {
    var stack by mutableStateOf<List<Screen>>(listOf(Screen.Home))
    fun go(s: Screen) { stack = stack + s }
    fun back() { if (stack.size > 1) stack = stack.dropLast(1) }
    fun root(s: Screen) { stack = listOf(s) }
    fun replace(s: Screen) { stack = stack.dropLast(1) + s }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Store.init(applicationContext)
        AutoCall.init(applicationContext)
        if (AutoCall.on) AutoCall.startService()
        Reminders.channel(this)
        handle(intent)
        setContent { ExormTheme { ExormRoot() } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val id = i?.getStringExtra("customerId")
        if (!id.isNullOrBlank() && Store.customers.any { it.id == id }) {
            Nav.go(Screen.CustomerDetail(id))
        }
        i?.removeExtra("customerId")
    }
}

@Composable
fun ExormRoot() {
    val ctx = LocalContext.current
    val screen = Nav.stack.last()
    var update by remember { mutableStateOf<Updater.Info?>(null) }
    var quickAdd by remember { mutableStateOf(false) }
    var picking by remember { mutableStateOf<String?>(null) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    BackHandler(enabled = Nav.stack.size > 1) { Nav.back() }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            perm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Store.settings.autoUpdate) Updater.check { i, _ -> update = i }
        Reminders.sync(ctx)
    }

    val tabScreens = listOf<Screen>(Screen.Home, Screen.Customers, Screen.Followups, Screen.Calendar, Screen.Quotes)
    val isRoot = Nav.stack.size == 1 && screen in tabScreens

    var splash by rememberSaveable { mutableStateOf(true) }
    Box(Modifier.fillMaxSize()) {
    GlassBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            Box(Modifier.weight(1f)) {
                when (screen) {
                    Screen.Home -> HomeScreen()
                    Screen.Customers -> CustomersScreen()
                    Screen.Followups -> FollowupsScreen()
                    Screen.Calendar -> CalendarScreen()
                    Screen.Quotes -> QuotesScreen()
                    Screen.Collections -> CollectionsScreen()
                    Screen.Settings -> SettingsScreen()
                    Screen.Addons -> AddonsScreen()
                    Screen.Reports -> ReportsScreen()
                    Screen.Showcase -> ShowcaseScreen()
                    Screen.Leads -> LeadsScreen()
                    Screen.LeadSetup -> LeadSetupScreen()
                    is Screen.ShowcaseDetail -> ShowcaseDetailScreen(screen.id)
                    is Screen.ShowcaseEdit -> ShowcaseEditScreen(screen.id)
                    is Screen.CustomerDetail -> CustomerDetailScreen(screen.id)
                    is Screen.CustomerEdit -> CustomerEditScreen(screen.id)
                    is Screen.EventDetail -> EventDetailScreen(screen.id)
                    is Screen.EventEdit -> EventEditScreen(screen.id, screen.customerId)
                    is Screen.QuoteDetail -> QuoteDetailScreen(screen.id)
                    is Screen.QuoteEdit -> QuoteEditScreen(screen.id, screen.customerId)
                    is Screen.CollectionDetail -> CollectionDetailScreen(screen.id)
                }
                if (isRoot) {
                    Box(Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = 12.dp)) {
                        RoundIcon(Icons.Default.Add, Color.Black, Color(0xFFEAE35E), 56.dp) { quickAdd = true }
                    }
                }
            }
            if (isRoot) BottomBar(screen)
        }
    }
    if (splash) SplashOverlay { splash = false }
    }

    if (quickAdd) {
        AlertDialog(onDismissRequest = { quickAdd = false }, containerColor = DialogBg, title = { Text("Quick add") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    PBtn("New customer", Modifier.fillMaxWidth()) { quickAdd = false; Nav.go(Screen.CustomerEdit(null)) }
                    PBtn("New follow-up", Modifier.fillMaxWidth(), filled = false) { quickAdd = false; picking = "followup" }
                    if (addon("events")) {
                        PBtn("New quotation", Modifier.fillMaxWidth(), filled = false) { quickAdd = false; picking = "quote" }
                        PBtn("New event", Modifier.fillMaxWidth(), filled = false) { quickAdd = false; Nav.go(Screen.EventEdit(null)) }
                    }
                }
            }, confirmButton = {}, dismissButton = { TextButton(onClick = { quickAdd = false }) { Text("Close") } })
    }

    var scheduleFor by remember { mutableStateOf<String?>(null) }
    picking?.let { kind ->
        PickCustomer(onPick = { c ->
            picking = null
            when (kind) {
                "followup" -> scheduleFor = c.id
                "quote" -> Nav.go(Screen.QuoteEdit(null, c.id))
                else -> Nav.go(Screen.EventEdit(null, c.id))
            }
        }, onClose = { picking = null })
    }
    scheduleFor?.let { ScheduleDialog(it) { scheduleFor = null } }

    update?.let { UpdateDialog(it) { update = null } }

    if (!Store.settings.onboarded && !splash) {
        var ev by remember { mutableStateOf(true) }
        var col by remember { mutableStateOf(true) }
        AlertDialog(onDismissRequest = {}, containerColor = DialogBg, title = { Text("Welcome to EXORM") },
            text = {
                Column {
                    Text("Pick the add-ons that fit your business. You can change them later in Settings → Add-ons.")
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(ev, { ev = it; if (!it) col = false }); Text("Event Planner (calendar, quotations, payments)")
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(col, { col = it; if (it) ev = true }); Text("Equipment Collection")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val s = mutableSetOf<String>()
                    if (ev) s.add("events"); if (col) s.add("collections")
                    Store.updateSettings(Store.settings.copy(addons = s, onboarded = true))
                }) { Text("Continue", color = Color(0xFFEAE35E)) }
            })
    }
}
