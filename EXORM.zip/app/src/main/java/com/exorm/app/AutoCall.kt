package com.exorm.app

import android.Manifest
import android.app.KeyguardManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.CallLog
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

const val DEFAULT_WA = "Hello {name}, thank you for your enquiry on JustDial. This is {biz}. We just tried to call you. Please tell us your event date and what you need, and we will send you the details. Thank you!"

/** One lead waiting to be called (or being called right now). */
class CallJob(val leadId: String, val pi: PendingIntent?, val direct: Boolean) {
    var stage = 0          // 0 = opening, 1 = waiting to tap Call, 2 = call is being placed
    var begun = 0L
    var stageAt = 0L
    var tapStart = 0L
}

/**
 * The auto-call brain. Everything runs on the main thread.
 * Saved settings (switch, JustDial app, called list) live in their own SharedPreferences file,
 * NOT in the backup file, so restoring a backup can never forget who was already called.
 */
object AutoCall {
    private const val PREFS = "exorm_auto"
    private lateinit var ctx: Context
    private var inited = false
    private val main = Handler(Looper.getMainLooper())

    /** What the switch on the Leads screen shows. */
    var on by mutableStateOf(false)
    var soundOn by mutableStateOf(false)
    var status by mutableStateOf("")
    var calledCount by mutableStateOf(0)

    private val queue = ArrayDeque<CallJob>()
    private var job: CallJob? = null
    private var lastStart = 0L
    private var ticking = false

    fun init(c: Context) {
        if (inited) return
        ctx = c.applicationContext
        Store.init(ctx)
        inited = true
        on = readOn()
        calledCount = calledSet().size
        waState = waEnabled()
    }

    private fun prefs() = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun bootTime(): Long = System.currentTimeMillis() - SystemClock.elapsedRealtime()

    // ---------- the switch (never survives a phone restart) ----------

    fun readOn(): Boolean {
        val p = prefs()
        if (!p.getBoolean("on", false)) return false
        val saved = p.getLong("boot", 0L)
        if (Math.abs(saved - bootTime()) > 120_000L) {
            p.edit().putBoolean("on", false).apply()
            return false
        }
        return true
    }

    fun switchOn(v: Boolean) {
        prefs().edit().putBoolean("on", v).putLong("boot", bootTime()).apply()
        on = v
        if (v) {
            status = "Auto-call is ON"
            startService()
        } else {
            abortAll("Skipped: switch OFF")
            status = "Auto-call is OFF"
            try { ctx.stopService(Intent(ctx, AutoCallService::class.java)) } catch (e: Exception) { }
        }
    }

    fun startService() {
        try { ContextCompat.startForegroundService(ctx, Intent(ctx, AutoCallService::class.java)) } catch (e: Exception) { }
    }

    // ---------- chosen JustDial app and optional filter word ----------

    fun pkg(): String = prefs().getString("pkg", "") ?: ""
    fun setPkg(p: String) { prefs().edit().putString("pkg", p).apply() }
    fun filter(): String = prefs().getString("filter", "") ?: ""
    fun setFilter(f: String) { prefs().edit().putString("filter", f.trim()).apply() }
    /** Filter words are separated by commas. A notification is accepted if it contains ANY of them. */
    fun filterOk(s: String): Boolean {
        val words = filter().split(",").map { it.trim() }.filter { it.isNotEmpty() }
        return words.isNotEmpty() && words.any { s.contains(it, true) }
    }

    // ---------- small log of what JustDial notifications looked like ----------

    fun addLog(line: String) {
        val t = java.text.SimpleDateFormat("dd MMM hh:mm:ss a", java.util.Locale.getDefault()).format(java.util.Date())
        val old = prefs().getString("notelog", "") ?: ""
        val items = ArrayList<String>()
        if (old.isNotBlank()) items.addAll(old.split("\u0001"))
        items.add(0, t + " - " + line.replace("\u0001", " "))
        while (items.size > 12) items.removeAt(items.size - 1)
        prefs().edit().putString("notelog", items.joinToString("\u0001")).apply()
    }
    fun noteLog(): List<String> {
        val s = prefs().getString("notelog", "") ?: ""
        return if (s.isBlank()) emptyList() else s.split("\u0001")
    }
    fun clearLog() { prefs().edit().remove("notelog").remove("seenpkgs").apply() }

    /** Package names of other apps that posted a notification recently (names only), to help pick the right JustDial app. */
    fun seenPkg(p: String) {
        if (p == "android" || p == "com.android.systemui" || p == ctx.packageName) return
        val old = prefs().getString("seenpkgs", "") ?: ""
        val items = ArrayList<String>()
        if (old.isNotBlank()) items.addAll(old.split(","))
        items.remove(p)
        items.add(0, p)
        while (items.size > 8) items.removeAt(items.size - 1)
        prefs().edit().putString("seenpkgs", items.joinToString(",")).apply()
    }
    fun seenPkgs(): List<String> {
        val s = prefs().getString("seenpkgs", "") ?: ""
        return if (s.isBlank()) emptyList() else s.split(",")
    }

    // ---------- called-once list ----------

    private fun calledSet(): MutableSet<String> = HashSet(prefs().getStringSet("called", emptySet()) ?: emptySet())
    fun nameKey(name: String, place: String): String = "n:" + name.trim().lowercase() + "|" + place.trim().lowercase()
    fun numKey(num: String): String = "p:" + digits(num).takeLast(10)

    fun wasCalled(l: Lead): Boolean {
        val s = calledSet()
        if (!l.test && s.contains(nameKey(l.name, l.place))) return true
        return digits(l.phone).length >= 5 && s.contains(numKey(l.phone))
    }

    private fun markCalled(key: String) {
        val s = calledSet()
        s.add(key)
        prefs().edit().putStringSet("called", s).apply()
        calledCount = s.size
    }

    fun resetCalled() {
        prefs().edit().remove("called").remove("messaged").apply()
        calledCount = 0
    }

    // ---------- permission and setup checks ----------

    fun hasPerm(p: String): Boolean = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    fun notifAccess(): Boolean = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    fun accessibilityOn(): Boolean {
        val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.split(":").any { it.startsWith(ctx.packageName + "/") && it.contains("AutoCallAccess") }
    }
    fun notifPerm(): Boolean = Build.VERSION.SDK_INT < 33 || hasPerm(Manifest.permission.POST_NOTIFICATIONS)
    fun overlayOk(): Boolean = Settings.canDrawOverlays(ctx)

    /** What is still missing before the switch may be turned ON. Empty = ready. */
    fun missingForOn(): List<String> {
        val m = ArrayList<String>()
        if (pkg().isBlank()) m.add("JustDial app")
        if (filter().isBlank()) m.add("filter word")
        if (!notifAccess()) m.add("notification access")
        if (!accessibilityOn()) m.add("accessibility")
        if (!hasPerm(Manifest.permission.READ_PHONE_STATE)) m.add("phone state permission")
        return m
    }

    // ---------- a new JustDial notification arrives ----------

    fun parseNote(title: String, text: String): Pair<String, String> {
        val t = title.trim()
        val x = text.trim()
        val generic = t.isBlank() || t.contains("lead", true) || t.contains("enquiry", true) || t.contains("inquiry", true) || t.contains("justdial", true)
        if (!generic) return Pair(t, x)
        var cut = -1
        var sepLen = 0
        for (s in listOf(",", " - ", " from ", "\n")) {
            val i = x.indexOf(s)
            if (i > 0 && (cut < 0 || i < cut)) { cut = i; sepLen = s.length }
        }
        return if (cut > 0) Pair(x.substring(0, cut).trim(), x.substring(cut + sepLen).trim()) else Pair(x, "")
    }

    fun incoming(title: String, text: String, pi: PendingIntent?) {
        val parsed = parseNote(title, text)
        val name = parsed.first.ifBlank { "JustDial lead" }
        val place = parsed.second
        val now = System.currentTimeMillis()
        // the same enquiry seen again within 30 minutes is the same notification shown twice
        if (Store.leads.any { !it.test && it.name.equals(name, true) && it.place.equals(place, true) && now - it.received < 30 * 60_000L }) return
        var l = Lead(name = name, place = place, received = now, note = "JustDial notification: " + title + " | " + text)
        val onNow = readOn()
        on = onNow
        if (!onNow) l = l.copy(callResult = "Skipped: switch OFF")
        else if (wasCalled(l)) l = l.copy(callResult = "Skipped: already called")
        Store.put(Store.leads, l)
        if (onNow && l.callResult.isBlank()) {
            queue.addLast(CallJob(l.id, pi, false))
            ensureTick()
        }
    }

    /** Test lead: same rules (switch, called once, queue, sound), but the number is known, so it dials directly. */
    fun runTest(l0: Lead) {
        var l = l0
        val onNow = readOn()
        on = onNow
        if (!onNow) l = l.copy(callResult = "Skipped: switch OFF")
        else if (wasCalled(l)) l = l.copy(callResult = "Skipped: already called")
        Store.put(Store.leads, l)
        if (onNow && l.callResult.isBlank()) {
            queue.addLast(CallJob(l.id, null, true))
            ensureTick()
        }
    }

    // ---------- the queue ----------

    private val tickRun = Runnable { tick() }

    private fun ensureTick() {
        if (!ticking) { ticking = true; main.postDelayed(tickRun, 1000L) }
    }

    private fun tick() {
        ticking = false
        try { step() } catch (e: Exception) {
            val j = job
            if (j != null) fail(j, "error: " + (e.message ?: "unknown")) else queue.clear()
        }
        try { waStep() } catch (e: Exception) {
            val id = waJob
            val l = if (id != null) Store.leads.find { it.id == id } else null
            if (l != null) waFail(l, "error: " + (e.message ?: "unknown")) else waJob = null
        }
        if (job != null || queue.isNotEmpty() || waJob != null || waQueue.isNotEmpty()) ensureTick()
    }

    @Suppress("DEPRECATION")
    private fun callState(): Int = try {
        (ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).callState
    } catch (e: Exception) { TelephonyManager.CALL_STATE_IDLE }

    private fun isLocked(): Boolean {
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return km.isKeyguardLocked || !pm.isInteractive
    }

    private fun step() {
        val now = System.currentTimeMillis()
        if (!readOn()) { on = false; abortAll("Skipped: switch OFF"); return }
        val j = job
        if (j == null) {
            if (queue.isEmpty()) return
            if (now - lastStart < 30_000L) { status = "Waiting 30 seconds between calls..."; return }
            if (callState() != TelephonyManager.CALL_STATE_IDLE) { status = "Waiting for the current call to end..."; return }
            val next = queue.removeFirst()
            next.begun = now
            next.stageAt = now
            next.stage = 0
            job = next
            lastStart = now
            startSound()
            status = "Starting a call..."
            return
        }
        when (j.stage) {
            0 -> openStage(j, now)
            1 -> tapStage(j, now)
            else -> dialStage(j, now)
        }
    }

    private fun openStage(j: CallJob, now: Long) {
        val l = Store.leads.find { it.id == j.leadId }
        if (l == null) { stopSound(); job = null; return }
        if (isLocked()) {
            status = "Phone is locked. Unlock it to continue..."
            if (now - j.begun > 90_000L) fail(j, "phone was locked")
            return
        }
        if (j.direct) {
            if (!hasPerm(Manifest.permission.CALL_PHONE)) { fail(j, "call permission missing"); return }
            try {
                val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                tm.placeCall(Uri.fromParts("tel", l.phone, null), Bundle())
                j.stage = 2
                j.tapStart = now
                j.stageAt = now
                status = "Calling the test number..."
            } catch (e: Exception) { fail(j, "could not start the call") }
            return
        }
        if (AutoCallAccess.instance == null) { fail(j, "accessibility is off"); return }
        val p = pkg()
        if (p.isBlank()) { fail(j, "JustDial app not chosen"); return }
        var opened = false
        val pi = j.pi
        if (pi != null) {
            try { pi.send(); opened = true } catch (e: Exception) { opened = false }
        }
        if (!opened) {
            val li = ctx.packageManager.getLaunchIntentForPackage(p)
            if (li != null) {
                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { ctx.startActivity(li); opened = true } catch (e: Exception) { opened = false }
            }
        }
        if (!opened) { fail(j, "could not open JustDial"); return }
        j.stage = 1
        j.stageAt = now
        status = "Opened JustDial, looking for the Call button..."
    }

    private fun tapStage(j: CallJob, now: Long) {
        val l = Store.leads.find { it.id == j.leadId }
        if (l == null) { stopSound(); job = null; return }
        val acc = AutoCallAccess.instance
        if (acc == null) { fail(j, "accessibility is off"); return }
        if (now - j.stageAt > 1500L && acc.tapCall(pkg(), l.name)) {
            j.stage = 2
            j.tapStart = now
            j.stageAt = now
            status = "Tapped Call in JustDial..."
            return
        }
        if (now - j.stageAt > 30_000L) fail(j, "Call button not found in JustDial")
    }

    private fun dialStage(j: CallJob, now: Long) {
        if (callState() == TelephonyManager.CALL_STATE_OFFHOOK) { success(j); return }
        if (!j.direct) AutoCallAccess.instance?.followUp(pkg())
        if (now - j.stageAt > 30_000L) fail(j, "call did not start")
    }

    private fun success(j: CallJob) {
        stopSound()
        val l = Store.leads.find { it.id == j.leadId }
        if (l != null) {
            Store.put(Store.leads, l.copy(callResult = "Called", status = if (l.status == "New") "Called" else l.status))
            if (!l.test) markCalled(nameKey(l.name, l.place))
            if (digits(l.phone).length >= 5) { markCalled(numKey(l.phone)); queueWa(l.id) }
            else watchCallLog(l.id, j.tapStart)
        }
        status = "Call placed"
        job = null
    }

    private fun fail(j: CallJob, reason: String) {
        stopSound()
        val l = Store.leads.find { it.id == j.leadId }
        if (l != null) Store.put(Store.leads, l.copy(callResult = "Failed: " + reason))
        status = "Failed: " + reason
        job = null
    }

    /** Switch turned OFF (or something stopped everything): nothing waiting will ever be called later. */
    fun abortAll(result: String) {
        stopSound()
        val ids = ArrayList<String>()
        val j = job
        if (j != null) ids.add(j.leadId)
        queue.forEach { ids.add(it.leadId) }
        queue.clear()
        waQueue.clear()
        waJob = null
        job = null
        ids.forEach { id ->
            val l = Store.leads.find { it.id == id }
            if (l != null && l.callResult.isBlank()) Store.put(Store.leads, l.copy(callResult = result))
        }
    }

    // ---------- number from the phone's call log ----------

    private fun lastOutgoingSince(since: Long): String? {
        return try {
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.DATE),
                CallLog.Calls.TYPE + " = ? AND " + CallLog.Calls.DATE + " >= ?",
                arrayOf(CallLog.Calls.OUTGOING_TYPE.toString(), since.toString()), CallLog.Calls.DATE + " ASC"
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) { null }
    }

    /** The call log entry only appears when the call ends, so we keep looking for up to 30 minutes. */
    private fun watchCallLog(leadId: String, since: Long) {
        if (!hasPerm(Manifest.permission.READ_CALL_LOG)) return
        val end = System.currentTimeMillis() + 30 * 60_000L
        val r = object : Runnable {
            override fun run() {
                val num = lastOutgoingSince(since - 5000L)
                if (num != null && digits(num).length >= 5) {
                    val l = Store.leads.find { it.id == leadId }
                    if (l != null && digits(l.phone).length < 5) Store.put(Store.leads, l.copy(phone = num))
                    markCalled(numKey(num))
                    queueWa(leadId)
                } else if (System.currentTimeMillis() < end) {
                    main.postDelayed(this, 5000L)
                }
            }
        }
        main.postDelayed(r, 5000L)
    }

    // ---------- automatic WhatsApp message (after the call, when the number is known) ----------

    var waState by mutableStateOf(false)
    var waStatus by mutableStateOf("")
    private val waQueue = ArrayList<String>()
    private var waJob: String? = null
    private var waAt = 0L
    private var waLast = 0L

    fun waEnabled(): Boolean = prefs().getBoolean("wa_on", false)
    fun switchWa(v: Boolean) {
        prefs().edit().putBoolean("wa_on", v).apply()
        waState = v
        if (!v) { waQueue.clear(); waJob = null; waStatus = "" }
    }
    fun waText(): String = prefs().getString("wa_text", DEFAULT_WA) ?: DEFAULT_WA
    fun setWaText(t: String) { prefs().edit().putString("wa_text", t).apply() }

    private fun msgSet(): MutableSet<String> = HashSet(prefs().getStringSet("messaged", emptySet()) ?: emptySet())
    private fun msgKey(num: String): String = "w:" + digits(num).takeLast(10)

    private fun queueWa(leadId: String) {
        if (!waEnabled() || !readOn()) return
        val l = Store.leads.find { it.id == leadId } ?: return
        if (digits(l.phone).length < 8 || l.waResult.isNotBlank()) return
        if (msgSet().contains(msgKey(l.phone))) {
            Store.put(Store.leads, l.copy(waResult = "Skipped: already messaged"))
            return
        }
        if (waQueue.contains(leadId) || waJob == leadId) return
        waQueue.add(leadId)
        ensureTick()
    }

    private fun waFail(l: Lead, reason: String) {
        Store.put(Store.leads, l.copy(waResult = "Failed: " + reason))
        waStatus = "WhatsApp failed: " + reason
        waJob = null
        waLast = System.currentTimeMillis()
    }

    private fun openWa(l: Lead): Boolean {
        val d = digits(l.phone)
        val full = if (d.length == 10) Store.settings.cc + d else d
        val text = waText().replace("{name}", l.name.ifBlank { "there" }).replace("{biz}", Store.settings.business)
        val uri = Uri.parse("https://wa.me/" + full + "?text=" + Uri.encode(text))
        for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            val i = Intent(Intent.ACTION_VIEW, uri)
            i.setPackage(p)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { ctx.startActivity(i); return true } catch (e: Exception) { }
        }
        return false
    }

    private fun waStep() {
        val now = System.currentTimeMillis()
        val id = waJob
        if (id == null) {
            if (waQueue.isEmpty()) return
            if (job != null || callState() != TelephonyManager.CALL_STATE_IDLE) { waStatus = "WhatsApp waits for the call to end..."; return }
            if (now - waLast < 20_000L) return
            if (isLocked()) { waStatus = "Unlock the phone to send the WhatsApp message..."; return }
            val next = waQueue.removeAt(0)
            val l = Store.leads.find { it.id == next } ?: return
            waJob = next
            waAt = now
            if (AutoCallAccess.instance == null) { waFail(l, "accessibility is off"); return }
            if (!openWa(l)) { waFail(l, "WhatsApp not installed or could not open"); return }
            waStatus = "Opening WhatsApp..."
            return
        }
        val l = Store.leads.find { it.id == id }
        if (l == null) { waJob = null; return }
        val acc = AutoCallAccess.instance
        if (acc == null) { waFail(l, "accessibility is off"); return }
        if (now - waAt > 2000L && acc.tapSend()) {
            val s = msgSet()
            s.add(msgKey(l.phone))
            prefs().edit().putStringSet("messaged", s).apply()
            Store.put(Store.leads, l.copy(waResult = "Send tapped"))
            waStatus = "WhatsApp: Send tapped"
            waJob = null
            waLast = now
            return
        }
        if (now - waAt > 30_000L) waFail(l, "Send button not found (number may not be on WhatsApp)")
    }

    // ---------- loud sound ----------

    private var player: MediaPlayer? = null
    private var oldVol = -1
    private val autoStop = Runnable { stopSound() }

    fun startSound() {
        if (player != null) return
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            try {
                oldVol = am.getStreamVolume(AudioManager.STREAM_ALARM)
                am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
            } catch (e: Exception) { }
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val mp = MediaPlayer()
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            mp.setDataSource(ctx, uri)
            mp.isLooping = true
            mp.setVolume(1f, 1f)
            mp.prepare()
            mp.start()
            player = mp
            soundOn = true
            main.postDelayed(autoStop, 60_000L)
        } catch (e: Exception) {
            player = null
            soundOn = false
        }
    }

    fun stopSound() {
        main.removeCallbacks(autoStop)
        try { player?.stop() } catch (e: Exception) { }
        try { player?.release() } catch (e: Exception) { }
        player = null
        soundOn = false
        if (oldVol >= 0) {
            try { (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).setStreamVolume(AudioManager.STREAM_ALARM, oldVol, 0) } catch (e: Exception) { }
            oldVol = -1
        }
    }
}
