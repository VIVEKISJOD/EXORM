package com.exorm.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/** Showcase photos are copied (and shrunk) into the app's private storage. */
object ShowImages {
    fun dir(ctx: Context): File = File(ctx.filesDir, "showcase").also { it.mkdirs() }
    fun file(ctx: Context, name: String): File = File(dir(ctx), name)
    fun delete(ctx: Context, name: String) { runCatching { file(ctx, name).delete() } }

    private fun rotation(ctx: Context, uri: Uri): Float = try {
        ctx.contentResolver.openInputStream(uri)?.use { s ->
            when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } ?: 0f
    } catch (e: Exception) { 0f }

    fun import(ctx: Context, uri: Uri): String? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (raw == null) null else {
            val rot = rotation(ctx, uri)
            val bmp: Bitmap = if (rot != 0f) {
                val m = Matrix(); m.postRotate(rot)
                Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            } else raw
            val name = newId() + ".jpg"
            FileOutputStream(file(ctx, name)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            if (bmp !== raw) raw.recycle()
            bmp.recycle()
            name
        }
    } catch (e: Exception) { null }
}

@Composable
fun ShowImage(name: String, modifier: Modifier = Modifier, scale: ContentScale = ContentScale.Crop, maxPx: Int = 900) {
    val ctx = LocalContext.current
    var bmp by remember(name) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(name) {
        bmp = withContext(Dispatchers.IO) {
            try {
                val f = ShowImages.file(ctx, name)
                val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.path, b)
                var s = 1
                while (b.outWidth / (s * 2) >= maxPx || b.outHeight / (s * 2) >= maxPx) s *= 2
                BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })?.asImageBitmap()
            } catch (e: Exception) { null }
        }
    }
    val b = bmp
    if (b != null) Image(bitmap = b, contentDescription = null, modifier = modifier, contentScale = scale)
    else Box(modifier.background(Color.White.copy(alpha = .06f)))
}

val SHOW_CATS = listOf("Boy Birthday", "Girl Birthday", "Wedding", "Baby Shower", "Anniversary", "Corporate", "Other")

@Composable
fun ShowcaseScreen() {
    var cat by remember { mutableStateOf("All") }
    val all = Store.showcases.toList().sortedByDescending { it.created }
    val cats = listOf("All") + all.map { it.category.trim() }.filter { it.isNotBlank() }.distinct()
    val sel = if (cat in cats) cat else "All"
    val shown = if (sel == "All") all else all.filter { it.category.trim() == sel }
    Page("Showcase", back = true, actions = { RoundIcon(Icons.Default.Add, Color.Black, Accent) { Nav.go(Screen.ShowcaseEdit(null)) } }) {
        T("Your decor ideas and setups. Photos stay on this phone and are not part of backups.", 12, color = Muted)
        if (cats.size > 1) ChipRow(cats, sel) { cat = it }
        if (shown.isEmpty()) Empty("Nothing here yet. Tap + to add your first showcase, like Boy Birthday or Girl Birthday decor.")
        shown.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { s -> ShowCard(s, Modifier.weight(1f)) }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun ShowCard(s: Showcase, modifier: Modifier) {
    Glass(modifier, onClick = { Nav.go(Screen.ShowcaseDetail(s.id)) }, pad = 0.dp) {
        Box(Modifier.fillMaxWidth().height(140.dp), contentAlignment = Alignment.Center) {
            if (s.images.isNotEmpty()) ShowImage(s.images.first(), Modifier.fillMaxSize(), maxPx = 500)
            else {
                Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = .06f)))
                Icon(Icons.Default.Star, null, tint = Muted, modifier = Modifier.size(36.dp))
            }
            if (s.images.size > 1) {
                Box(Modifier.align(Alignment.BottomEnd).padding(8.dp).clip(RoundedCornerShape(50)).background(Color(0x99000000))
                    .padding(horizontal = 8.dp, vertical = 2.dp)) { T("+" + (s.images.size - 1), 11) }
            }
        }
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            T(s.title, 14, true, maxLines = 2)
            if (s.category.isNotBlank()) T(s.category, 11, color = Muted, maxLines = 1)
            if (s.price > 0) T(fmtMoney(s.price), 13, color = Accent)
        }
    }
}

@Composable
fun ShowcaseDetailScreen(id: String) {
    val s = Store.showcases.find { it.id == id }
    if (s == null) { Page("Showcase", back = true) { Empty("This showcase no longer exists.") }; return }
    var big by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf(false) }
    Page(s.title, back = true, actions = { RoundIcon(Icons.Default.Edit) { Nav.go(Screen.ShowcaseEdit(s.id)) } }) {
        if (s.images.isNotEmpty()) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                s.images.forEach { n ->
                    ShowImage(n, Modifier.width(280.dp).height(210.dp).clip(RoundedCornerShape(20.dp)).clickable { big = n })
                }
            }
        }
        if (s.category.isNotBlank()) Tag(s.category, Accent)
        if (s.desc.isNotBlank()) Glass { T(s.desc, 14) }
        if (s.materials.isNotEmpty() || s.price > 0) Glass {
            T("Raw material & costing", 16, true)
            Spacer(Modifier.height(8.dp))
            s.materials.forEach { m ->
                Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    T(m.name + (if (m.qty.isNotBlank()) " • " + m.qty else ""), 14, modifier = Modifier.weight(1f))
                    T(fmtMoney(m.cost), 14)
                }
            }
            if (s.materials.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T("Total cost", 14, true, modifier = Modifier.weight(1f)); T(fmtMoney(s.cost), 14, true)
                }
            }
            if (s.price > 0) {
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T("Selling price", 14, true, modifier = Modifier.weight(1f)); T(fmtMoney(s.price), 14, true)
                }
                if (s.materials.isNotEmpty()) {
                    val profit = s.price - s.cost
                    val pct = profit * 100 / s.price
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        T("Profit", 14, true, if (profit >= 0) Accent else Danger, Modifier.weight(1f))
                        T(fmtMoney(profit) + " (" + pct + "%)", 14, true, if (profit >= 0) Accent else Danger)
                    }
                }
            }
        }
        PBtn("Delete showcase", Modifier.fillMaxWidth(), filled = false, danger = true, icon = Icons.Default.Delete) { deleting = true }
    }
    big?.let { n ->
        Dialog(onDismissRequest = { big = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Box(Modifier.fillMaxSize().background(Color.Black).clickable { big = null }, contentAlignment = Alignment.Center) {
                ShowImage(n, Modifier.fillMaxSize(), ContentScale.Fit, 1800)
            }
        }
    }
    if (deleting) Confirm("Delete this showcase?", "Its photos will also be removed from this phone.",
        onYes = { deleting = false; Nav.back(); Store.deleteShowcase(s.id) }, onNo = { deleting = false })
}

@Composable
fun ShowcaseEditScreen(id: String?) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val old = Store.showcases.find { it.id == id }
    var title by remember { mutableStateOf(old?.title ?: "") }
    var category by remember { mutableStateOf(old?.category ?: "") }
    var desc by remember { mutableStateOf(old?.desc ?: "") }
    var images by remember { mutableStateOf(old?.images ?: emptyList<String>()) }
    var mats by remember { mutableStateOf(old?.materials ?: emptyList<RawItem>()) }
    var price by remember { mutableStateOf(if ((old?.price ?: 0) > 0) old!!.price.toString() else "") }
    var err by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }
    val added = remember { mutableListOf<String>() }
    DisposableEffect(Unit) { onDispose { if (!saved) added.forEach { ShowImages.delete(ctx, it) } } }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            busy = true
            scope.launch(Dispatchers.IO) {
                val names = uris.mapNotNull { ShowImages.import(ctx, it) }
                withContext(Dispatchers.Main) { added.addAll(names); images = images + names; busy = false }
            }
        }
    }
    val catOptions = (SHOW_CATS + Store.showcases.map { it.category.trim() }.filter { it.isNotBlank() }).distinct()

    Page(if (old == null) "New showcase" else "Edit showcase", back = true) {
        TF("Title * (e.g. Jungle theme birthday)", title, { title = it })
        TF("Category (e.g. Boy Birthday)", category, { category = it })
        ChipRow(catOptions, category.trim()) { category = it }
        TF("Description (optional)", desc, { desc = it }, lines = 3)

        T("Photos (optional)", 12, color = Muted)
        if (images.isNotEmpty()) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                images.forEach { n ->
                    Box {
                        ShowImage(n, Modifier.size(110.dp).clip(RoundedCornerShape(16.dp)), maxPx = 400)
                        Box(Modifier.align(Alignment.TopEnd).padding(4.dp)) {
                            RoundIcon(Icons.Default.Close, Color.White, Color(0xAA000000), 30.dp) {
                                if (n in added) { ShowImages.delete(ctx, n); added.remove(n) }
                                images = images - n
                            }
                        }
                    }
                }
            }
        }
        PBtn(if (busy) "Adding photos..." else "Add photos", Modifier.fillMaxWidth(), filled = false, icon = Icons.Default.Add) {
            if (!busy) pick.launch("image/*")
        }

        T("Raw material & costing (optional)", 12, color = Muted)
        mats.forEachIndexed { i, m ->
            Glass(pad = 10.dp) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TF("Material", m.name, { v -> mats = mats.mapIndexed { j, x -> if (j == i) x.copy(name = v) else x } }, Modifier.weight(1f))
                    RoundIcon(Icons.Default.Delete, Danger, size = 40.dp) { mats = mats.filterIndexed { j, _ -> j != i } }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TF("Qty (e.g. 2 kg)", m.qty, { v -> mats = mats.mapIndexed { j, x -> if (j == i) x.copy(qty = v) else x } }, Modifier.weight(1f))
                    TF("Cost", if (m.cost > 0) m.cost.toString() else "",
                        { v -> mats = mats.mapIndexed { j, x -> if (j == i) x.copy(cost = v.filter { c -> c.isDigit() }.take(9).toLongOrNull() ?: 0L) else x } },
                        Modifier.weight(1f), KeyboardType.Number)
                }
            }
        }
        PBtn("Add material", Modifier.fillMaxWidth(), filled = false, icon = Icons.Default.Add) { mats = mats + RawItem("") }
        if (mats.any { it.cost > 0 }) T("Total cost: " + fmtMoney(mats.sumOf { it.cost }), 14, true, Accent)
        TF("Selling price (optional)", price, { price = it.filter { c -> c.isDigit() }.take(9) }, kb = KeyboardType.Number)

        if (err.isNotBlank()) T(err, 13, color = Danger)
        PBtn("Save", Modifier.fillMaxWidth()) {
            if (title.isBlank()) err = "Enter a title"
            else if (busy) err = "Wait until the photos finish adding"
            else {
                val s = (old ?: Showcase()).copy(title = title.trim(), category = category.trim(), desc = desc.trim(), images = images,
                    materials = mats.filter { it.name.isNotBlank() }.map { it.copy(name = it.name.trim(), qty = it.qty.trim()) },
                    price = price.toLongOrNull() ?: 0L)
                old?.images?.filter { it !in images }?.forEach { ShowImages.delete(ctx, it) }
                saved = true
                Store.put(Store.showcases, s)
                Nav.back()
            }
        }
    }
}
