package com.exorm.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

const val DEFAULT_THANKS = "Hello {name}, thank you for choosing {biz}! It was a pleasure working with you on your {event}. We hope you and your guests loved it. We would be happy to see you again for your next celebration! – {biz}"

/** Copies a picked photo into the app cache so it can be shared safely. */
private fun copyToShareCache(ctx: Context, uri: Uri): File? = try {
    val dir = File(ctx.cacheDir, "share").also { it.mkdirs() }
    val ext = when (ctx.contentResolver.getType(uri)) { "image/png" -> ".png"; "image/webp" -> ".webp"; else -> ".jpg" }
    val f = File(dir, "thanks_" + newId() + ext)
    ctx.contentResolver.openInputStream(uri)?.use { i -> FileOutputStream(f).use { o -> i.copyTo(o) } }
    if (f.length() > 0) f else null
} catch (e: Exception) { null }

/** Opens WhatsApp (or the share sheet) with the message and photos ready. Nothing is sent by the app. */
fun sendThanks(ctx: Context, phone: String, text: String, files: List<File>) {
    val d = digits(phone)
    val full = if (d.length == 10) Store.settings.cc + d else d
    val hasPhone = d.length >= 8
    if (files.isEmpty() && hasPhone) { whatsapp(ctx, phone, text); return }
    val i: Intent
    if (files.isEmpty()) {
        i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
    } else {
        val uris = ArrayList<Uri>(files.map { FileProvider.getUriForFile(ctx, ctx.packageName + ".files", it) })
        i = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        i.type = "image/*"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    i.putExtra(Intent.EXTRA_TEXT, text)
    // Photos are sent with the message as a caption; WhatsApp sometimes drops it, so it is also copied to paste.
    runCatching {
        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("message", text))
    }
    if (hasPhone) {
        i.putExtra("jid", full + "@s.whatsapp.net")
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try { i.setPackage(pkg); ctx.startActivity(i); return } catch (e: Exception) { }
        }
        i.setPackage(null)
    }
    try { ctx.startActivity(Intent.createChooser(i, "Send thank-you")) } catch (e: Exception) { toast(ctx, "Nothing found to send with") }
}

@Composable
fun FileImage(f: File, modifier: Modifier = Modifier, maxPx: Int = 300) {
    var bmp by remember(f.path) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(f.path) {
        bmp = withContext(Dispatchers.IO) {
            try {
                val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.path, b)
                var s = 1
                while (b.outWidth / (s * 2) >= maxPx || b.outHeight / (s * 2) >= maxPx) s *= 2
                BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })?.asImageBitmap()
            } catch (e: Exception) { null }
        }
    }
    val b = bmp
    if (b != null) Image(bitmap = b, contentDescription = null, modifier = modifier, contentScale = ContentScale.Crop)
    else Box(modifier.background(Color.White.copy(alpha = .06f)))
}

@Composable
fun ThankYouDialog(e: Event, c: Customer, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val biz = Store.settings.business
    fun fill(t: String) = t.replace("{name}", c.name).replace("{event}", e.type.ifBlank { "event" }.lowercase()).replace("{biz}", biz)
    var text by remember { mutableStateOf(fill(Store.settings.thanksMsg.ifBlank { DEFAULT_THANKS })) }
    var files by remember { mutableStateOf<List<File>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { File(ctx.cacheDir, "share").listFiles()?.forEach { it.delete() } } }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            busy = true
            scope.launch(Dispatchers.IO) {
                val fs = uris.take(10).mapNotNull { copyToShareCache(ctx, it) }
                withContext(Dispatchers.Main) { files = (files + fs).take(10); busy = false }
            }
        }
    }

    AlertDialog(onDismissRequest = onClose, containerColor = DialogBg, title = { Text("Thank-you for " + c.name) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                TF("Message (editable)", text, { text = it }, lines = 6)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { text = fill(DEFAULT_THANKS) }) { Text("Reset text") }
                    TextButton(onClick = {
                        var t = text
                        if (c.name.isNotBlank()) t = t.replace(c.name, "{name}")
                        if (biz.isNotBlank()) t = t.replace(biz, "{biz}")
                        Store.updateSettings(Store.settings.copy(thanksMsg = t))
                        toast(ctx, "Saved as your default thank-you")
                    }) { Text("Save as my default", color = Accent) }
                }
                if (files.isNotEmpty()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        files.forEach { f ->
                            Box {
                                FileImage(f, Modifier.size(84.dp).clip(RoundedCornerShape(14.dp)))
                                Box(Modifier.align(Alignment.TopEnd).padding(3.dp)) {
                                    RoundIcon(Icons.Default.Close, Color.White, Color(0xAA000000), 26.dp) { files = files - f; f.delete() }
                                }
                            }
                        }
                    }
                }
                PBtn(if (busy) "Adding photos..." else if (files.isEmpty()) "Add photos to send" else "Add more photos",
                    Modifier.fillMaxWidth(), filled = false, icon = Icons.Default.Add) { if (!busy) pick.launch("image/*") }
                T("WhatsApp opens with the message and photos ready. Nothing is sent until you tap Send there.", 11, color = Muted)
                if (digits(c.phone).length < 8) T("This customer has no phone number saved, so you will pick the contact in WhatsApp.", 11, color = Muted)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (!busy) {
                    sendThanks(ctx, c.phone, text, files)
                    Store.put(Store.events, e.copy(thankedAt = System.currentTimeMillis()))
                    onClose()
                }
            }) { Text("Open WhatsApp", color = Accent) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } })
}
