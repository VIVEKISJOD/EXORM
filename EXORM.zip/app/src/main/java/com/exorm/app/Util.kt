package com.exorm.app

import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

const val DAY = 86_400_000L

fun fmtDate(ms: Long): String = if (ms <= 0) "—" else SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(ms))
fun fmtDT(ms: Long): String = if (ms <= 0) "—" else SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(ms))
fun fmtMoney(v: Long): String = Store.settings.currency + NumberFormat.getInstance(Locale("en", "IN")).format(v)

fun startOfDay(ms: Long): Long {
    val c = Calendar.getInstance(); c.timeInMillis = ms
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}
fun addDays(ms: Long, d: Int): Long { val c = Calendar.getInstance(); c.timeInMillis = ms; c.add(Calendar.DAY_OF_MONTH, d); return c.timeInMillis }
fun startOfMonth(ms: Long): Long {
    val c = Calendar.getInstance(); c.timeInMillis = startOfDay(ms); c.set(Calendar.DAY_OF_MONTH, 1); return c.timeInMillis
}
fun addMonths(ms: Long, m: Int): Long { val c = Calendar.getInstance(); c.timeInMillis = ms; c.add(Calendar.MONTH, m); return c.timeInMillis }
fun dayOfMonth(month: Long, day: Int): Long { val c = Calendar.getInstance(); c.timeInMillis = month; c.set(Calendar.DAY_OF_MONTH, day); return c.timeInMillis }
fun monthTitle(ms: Long): String = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(ms))

fun cname(id: String): String = Store.customers.find { it.id == id }?.name ?: "Unknown"
fun digits(s: String): String = s.filter { it.isDigit() }
fun Customer.matches(q: String): Boolean =
    name.contains(q, true) || phone.contains(q) || phone2.contains(q) || requirement.contains(q, true) || notes.contains(q, true)

fun toast(ctx: Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

fun dial(ctx: Context, phone: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(phone)))) }
    catch (e: ActivityNotFoundException) { toast(ctx, "No dialer found") }
}

fun whatsapp(ctx: Context, phone: String, text: String = "") {
    val d = digits(phone)
    val full = if (d.length == 10) Store.settings.cc + d else d
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$full?text=" + Uri.encode(text)))) }
    catch (e: ActivityNotFoundException) { toast(ctx, "WhatsApp not available") }
}

fun openUrl(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: ActivityNotFoundException) { toast(ctx, "No browser found") }
}

fun openMap(ctx: Context, link: String) {
    val l = link.trim()
    val uri = when {
        l.startsWith("http://") || l.startsWith("https://") || l.startsWith("geo:") -> Uri.parse(l)
        l.contains(".") && !l.contains(" ") -> Uri.parse("https://$l")
        else -> Uri.parse("geo:0,0?q=" + Uri.encode(l))
    }
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (e: ActivityNotFoundException) { toast(ctx, "No maps app or browser found") }
}

fun pickDate(ctx: Context, initial: Long, withTime: Boolean, onPicked: (Long) -> Unit) {
    val c = Calendar.getInstance(); c.timeInMillis = if (initial > 0) initial else System.currentTimeMillis()
    DatePickerDialog(ctx, { _, y, m, d ->
        if (withTime) {
            TimePickerDialog(ctx, { _, h, mi ->
                val r = Calendar.getInstance(); r.set(y, m, d, h, mi, 0); r.set(Calendar.MILLISECOND, 0); onPicked(r.timeInMillis)
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
        } else {
            val r = Calendar.getInstance(); r.set(y, m, d, 0, 0, 0); r.set(Calendar.MILLISECOND, 0); onPicked(r.timeInMillis)
        }
    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
}

fun shareFile(ctx: Context, file: File, mime: String) {
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)
    val i = Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    ctx.startActivity(Intent.createChooser(i, "Share"))
}

fun shareText(ctx: Context, text: String) {
    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
    ctx.startActivity(Intent.createChooser(i, "Share"))
}

fun nextQuoteNumber(): String {
    val year = Calendar.getInstance().get(Calendar.YEAR)
    val max = Store.quotes.mapNotNull { it.number.substringAfterLast('-').toIntOrNull() }.maxOrNull() ?: 0
    return "Q-$year-" + (max + 1).toString().padStart(4, '0')
}

fun quoteText(q: Quote): String {
    val sb = StringBuilder()
    sb.append(Store.settings.business).append("\nQuotation ").append(q.number).append("\n")
    sb.append("For: ").append(cname(q.customerId)).append("\n")
    if (q.title.isNotBlank()) sb.append(q.title).append("\n")
    sb.append("\n")
    q.items.forEach { sb.append("• ").append(it.desc).append(" × ").append(it.qty).append(" = ").append(fmtMoney(it.total)).append("\n") }
    if (q.discount > 0) sb.append("Discount: -").append(fmtMoney(q.discount)).append("\n")
    if (q.taxPct > 0) sb.append("Tax (").append(q.taxPct).append("%): ").append(fmtMoney(q.tax)).append("\n")
    sb.append("Total: ").append(fmtMoney(q.total)).append("\n")
    if (q.validUntil > 0) sb.append("Valid until ").append(fmtDate(q.validUntil)).append("\n")
    if (q.notes.isNotBlank()) sb.append("\n").append(q.notes).append("\n")
    return sb.toString()
}

// ---------- Reminders (local notifications) ----------
object Reminders {
    const val CH = "exorm_reminders"

    fun channel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Reminders", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun pi(ctx: Context, key: String, title: String, text: String, cust: String): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java).putExtra("key", key).putExtra("title", title).putExtra("text", text).putExtra("cust", cust)
        return PendingIntent.getBroadcast(ctx, key.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun sync(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val now = System.currentTimeMillis()
        val on = Store.settings.reminders
        fun set(key: String, time: Long, title: String, text: String, cust: String) {
            val p = pi(ctx, key, title, text, cust)
            if (on && time > now) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, p) else am.cancel(p)
        }
        val nine = 9 * 3600_000L
        Store.followups.forEach {
            set("f:" + it.id, if (it.done || it.dropped) 0 else it.at, "Follow-up: " + cname(it.customerId), it.note.ifBlank { "Time to call this customer" }, it.customerId)
        }
        Store.collections.forEach {
            set("c:" + it.id, if (it.isClosed() || it.date <= 0) 0 else startOfDay(it.date) + nine, "Collection due: " + cname(it.customerId), "Collect equipment from the venue", it.customerId)
        }
        Store.events.forEach {
            val live = it.status == "Confirmed" || it.status == "In Progress"
            set("e:" + it.id, if (live && it.date > 0) addDays(startOfDay(it.date), -1) + nine else 0, "Event tomorrow: " + cname(it.customerId), it.type + " at " + it.venue, it.customerId)
        }
    }

    fun valid(key: String): Boolean {
        val id = key.substring(2)
        return when (key.substring(0, 2)) {
            "f:" -> Store.followups.any { it.id == id && !it.done && !it.dropped }
            "c:" -> Store.collections.any { it.id == id && !it.isClosed() }
            "e:" -> Store.events.any { it.id == id }
            else -> false
        }
    }
}

// ---------- In-app updates from GitHub Releases ----------
object Updater {
    data class Info(val code: Int, val name: String, val url: String)

    fun check(onResult: (Info?, String?) -> Unit) {
        val h = Handler(Looper.getMainLooper())
        if (BuildConfig.GITHUB_REPO == "OWNER/REPO") { onResult(null, "Updates work in builds made by GitHub Actions"); return }
        Thread {
            var info: Info? = null
            var err: String? = null
            try {
                val c = URL("https://api.github.com/repos/${BuildConfig.GITHUB_REPO}/releases/latest").openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                if (c.responseCode == 200) {
                    val o = JSONObject(c.inputStream.bufferedReader().readText())
                    val code = o.getString("tag_name").filter { it.isDigit() }.toIntOrNull() ?: 0
                    var url = o.getString("html_url")
                    val assets = o.optJSONArray("assets")
                    if (assets != null) for (i in 0 until assets.length()) {
                        val a = assets.getJSONObject(i)
                        if (a.getString("name").endsWith(".apk")) url = a.getString("browser_download_url")
                    }
                    if (code > BuildConfig.VERSION_CODE) info = Info(code, o.optString("name"), url)
                } else err = "No release found (the repository must be public)"
            } catch (e: Exception) { err = "Could not check (offline?)" }
            h.post { onResult(info, err) }
        }.start()
    }

    /** Downloads the APK inside the app (no browser). Callbacks run on the main thread. */
    fun download(ctx: Context, url: String, onProgress: (Int) -> Unit, onDone: (File?) -> Unit) {
        val h = Handler(Looper.getMainLooper())
        val app = ctx.applicationContext
        Thread {
            var result: File? = null
            try {
                val out = File(app.cacheDir, "EXORM-update.apk")
                if (out.exists()) out.delete()
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 30000
                c.instanceFollowRedirects = true
                if (c.responseCode == 200) {
                    val total = c.contentLengthLong
                    var got = 0L
                    var last = -1
                    c.inputStream.use { input ->
                        FileOutputStream(out).use { o ->
                            val buf = ByteArray(32 * 1024)
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                o.write(buf, 0, n)
                                got += n
                                if (total > 0) {
                                    val p = (got * 100 / total).toInt()
                                    if (p != last) { last = p; h.post { onProgress(p) } }
                                }
                            }
                        }
                    }
                    if (out.length() > 100000) result = out
                }
            } catch (e: Exception) { result = null }
            h.post { onDone(result) }
        }.start()
    }

    /** Opens Android's install screen for the downloaded APK. Returns false if the user must first allow installs from EXORM. */
    fun install(ctx: Context, f: File): Boolean {
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            val i = Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { ctx.startActivity(i) } catch (e: Exception) { }
            return false
        }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (e: Exception) { return false }
        return true
    }
}

// ---------- PDF quotation (made on the phone, no paid service) ----------
object PdfMaker {
    fun make(ctx: Context, q: Quote): File {
        val c = Store.customers.find { it.id == q.customerId }
        val doc = PdfDocument()
        val w = 595; val h = 842
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create())
        var cv = page.canvas
        val body = Paint().apply { color = 0xFF222222.toInt(); textSize = 11f; isAntiAlias = true }
        val bold = Paint(body).apply { typeface = Typeface.DEFAULT_BOLD }
        val muted = Paint(body).apply { color = 0xFF777777.toInt() }
        val rightP = Paint(body).apply { textAlign = Paint.Align.RIGHT }
        val rightB = Paint(bold).apply { textAlign = Paint.Align.RIGHT }
        val band = Paint().apply { color = 0xFF000000.toInt() }
        val brand = Paint().apply { color = 0xFFEAE35E.toInt(); textSize = 20f; typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true }
        val brandR = Paint(brand).apply { textAlign = Paint.Align.RIGHT; textSize = 14f }
        val rule = Paint().apply { color = 0xFFCCCCCC.toInt(); strokeWidth = 1f }
        var y = 0f

        fun ensure(space: Float) {
            if (y + space > h - 50) {
                doc.finishPage(page); pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create()); cv = page.canvas; y = 50f
            }
        }

        cv.drawRect(0f, 0f, w.toFloat(), 80f, band)
        cv.drawText(Store.settings.business, 40f, 48f, brand)
        cv.drawText("QUOTATION", w - 40f, 48f, brandR)
        y = 110f
        cv.drawText("Quotation No: " + q.number, 40f, y, bold); y += 16f
        cv.drawText("Date: " + fmtDate(q.created), 40f, y, body); y += 16f
        if (q.validUntil > 0) { cv.drawText("Valid until: " + fmtDate(q.validUntil), 40f, y, body); y += 16f }
        if (Store.settings.bizPhone.isNotBlank()) { cv.drawText("Contact: " + Store.settings.bizPhone, 40f, y, body); y += 16f }
        y += 8f
        cv.drawText("Prepared for", 40f, y, muted); y += 16f
        cv.drawText(c?.name ?: "", 40f, y, bold); y += 16f
        if (!c?.phone.isNullOrBlank()) { cv.drawText(c!!.phone, 40f, y, body); y += 16f }
        if (q.title.isNotBlank()) { y += 6f; cv.drawText(q.title, 40f, y, bold); y += 16f }
        y += 10f
        cv.drawLine(40f, y, w - 40f, y, rule); y += 16f
        cv.drawText("Description", 40f, y, bold); cv.drawText("Qty", 370f, y, bold)
        cv.drawText("Price", 460f, y, rightB); cv.drawText("Amount", w - 40f, y, rightB); y += 8f
        cv.drawLine(40f, y, w - 40f, y, rule); y += 16f
        q.items.forEach { it ->
            val lines = it.desc.chunked(55)
            ensure(14f * lines.size + 8f)
            cv.drawText(it.qty.toString(), 370f, y, body)
            cv.drawText(fmtMoney(it.price), 460f, y, rightP)
            cv.drawText(fmtMoney(it.total), w - 40f, y, rightP)
            lines.forEach { l -> cv.drawText(l, 40f, y, body); y += 14f }
            y += 4f
        }
        ensure(100f)
        cv.drawLine(40f, y, w - 40f, y, rule); y += 18f
        cv.drawText("Subtotal", 400f, y, body); cv.drawText(fmtMoney(q.subtotal), w - 40f, y, rightP); y += 16f
        if (q.discount > 0) { cv.drawText("Discount", 400f, y, body); cv.drawText("-" + fmtMoney(q.discount), w - 40f, y, rightP); y += 16f }
        if (q.taxPct > 0) { cv.drawText("Tax (" + q.taxPct + "%)", 400f, y, body); cv.drawText(fmtMoney(q.tax), w - 40f, y, rightP); y += 16f }
        cv.drawText("TOTAL", 400f, y, bold); cv.drawText(fmtMoney(q.total), w - 40f, y, rightB); y += 28f
        if (q.notes.isNotBlank()) {
            ensure(30f)
            cv.drawText("Notes & terms", 40f, y, bold); y += 16f
            q.notes.split("\n").flatMap { it.chunked(90) }.forEach { l -> ensure(16f); cv.drawText(l, 40f, y, body); y += 14f }
        }
        doc.finishPage(page)
        val f = File(ctx.cacheDir, "Quotation_" + q.number + ".pdf")
        FileOutputStream(f).use { doc.writeTo(it) }
        doc.close()
        return f
    }
}
