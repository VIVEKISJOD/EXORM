package com.exorm.app

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

class AppEntry(val label: String, val pkg: String)

fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0).map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
}

fun appLabelOf(ctx: Context, pkg: String): String {
    if (pkg.isBlank()) return ""
    return try { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
}

fun openIntent(ctx: Context, i: Intent, msg: String = "Could not open that page. Please open it from Settings yourself.") {
    try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) { toast(ctx, msg) }
}

fun appInfoIntent(ctx: Context): Intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))

@Composable
fun CheckRow(title: String, ok: Boolean, hint: String, btn: String? = null, onBtn: () -> Unit = {}) {
    Glass {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T(title, 15, true)
                T(hint, 12, color = Muted)
            }
            Tag(if (ok) "OK" else "Missing", if (ok) Good else Danger)
        }
        if (!ok && btn != null) {
            Spacer(Modifier.height(8.dp))
            PBtn(btn, Modifier.fillMaxWidth(), filled = false) { onBtn() }
        }
    }
}

@Composable
fun StepCard(title: String, text: String, btn: String? = null, onBtn: () -> Unit = {}) {
    Glass {
        T(title, 15, true)
        T(text, 12, color = Muted)
        if (btn != null) {
            Spacer(Modifier.height(8.dp))
            PBtn(btn, Modifier.fillMaxWidth(), filled = false) { onBtn() }
        }
    }
}

@Composable
fun LeadSetupScreen() {
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    var pickApp by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf(AutoCall.filter()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1500)
            tick++
        }
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }
    val refresh = tick   // reading this makes the green/red checks refresh by themselves
    val perms = buildList<String> {
        add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.READ_CALL_LOG)
        add(Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }
    fun askPerms() { permLauncher.launch(perms.toTypedArray()) }

    Page("Auto-call setup", back = true) {
        T("Auto-call needs several Android permissions. Make every row below green, then turn the switch ON on the Leads screen. This screen updates by itself when you come back from Settings.", 13, color = Muted)

        Section("1. Your JustDial app")
        val label = appLabelOf(ctx, AutoCall.pkg())
        CheckRow("JustDial app chosen", label.isNotBlank(), if (label.isBlank()) "Pick the JustDial app from your installed apps." else "Chosen: " + label)
        PBtn(if (label.isBlank()) "Choose JustDial app" else "Change JustDial app", Modifier.fillMaxWidth(), filled = false) { pickApp = true }
        TF("Only notifications containing this word (optional)", filter, { filter = it; AutoCall.setFilter(it) })
        T("Example: lead or enquiry. Leave empty to treat every JustDial notification as a lead.", 11, color = Muted)

        Section("2. Android permissions")
        CheckRow("Notification access", AutoCall.notifAccess(), "Lets EXORM read the JustDial lead notification (name and place).", "Open notification access") {
            openIntent(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        CheckRow("Accessibility", AutoCall.accessibilityOn(), "Lets EXORM tap the blue Call button in JustDial for you. Find EXORM in the list and turn it on.", "Open accessibility") {
            openIntent(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        CheckRow("Call permission", AutoCall.hasPerm(Manifest.permission.CALL_PHONE), "Used by the Test lead button to place its call.", "Allow") { askPerms() }
        CheckRow("Call log permission", AutoCall.hasPerm(Manifest.permission.READ_CALL_LOG), "Lets EXORM read the number from your call log after the call and fill it into the lead.", "Allow") { askPerms() }
        CheckRow("Phone state permission", AutoCall.hasPerm(Manifest.permission.READ_PHONE_STATE), "Needed to know the moment the call starts, so the loud sound can stop.", "Allow") { askPerms() }
        CheckRow("Notifications", AutoCall.notifPerm(), "Needed to show the \"Auto-call is ON\" notification.", "Allow") { askPerms() }
        CheckRow("Display over other apps", AutoCall.overlayOk(), "Helps EXORM open JustDial while it is in the background.", "Open this setting") {
            openIntent(ctx, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
        }

        Section("3. Xiaomi / HyperOS steps (cannot be checked by the app)")
        StepCard("Allow restricted settings", "EXORM is installed from outside the Play Store, so Android may grey out Notification access and Accessibility. Open the EXORM app info page, tap the three dots at the top right, and choose Allow restricted settings. Do this BEFORE step 2.", "Open EXORM app info") {
            openIntent(ctx, appInfoIntent(ctx))
        }
        StepCard("Autostart", "Turn Autostart ON for EXORM.", "Open Autostart") {
            openIntent(ctx, Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
                "Could not open Autostart. Open Settings > Apps > Permissions > Autostart and turn EXORM on.")
        }
        StepCard("Battery: No restrictions", "Open the EXORM app info page, tap Battery saver, and choose No restrictions.", "Open EXORM app info") {
            openIntent(ctx, appInfoIntent(ctx))
        }
        StepCard("Pop-ups while running in the background", "On the EXORM app info page open Other permissions (or Permissions) and allow Display pop-up windows while running in the background, if you see it. Without it Xiaomi can block EXORM from opening JustDial.", "Open EXORM app info") {
            openIntent(ctx, appInfoIntent(ctx))
        }
        StepCard("Lock EXORM in recent apps", "Open the recent apps screen, press and hold the EXORM card (or tap its menu), and choose Lock. This stops the phone from closing EXORM.")
        StepCard("Alarm volume and Do Not Disturb", "The loud sound uses the alarm volume. Alarms normally still play in Do Not Disturb, but Total silence can block them.")

        Section("Honest limits")
        T("The phone screen must be on and unlocked while EXORM taps (if it is locked EXORM keeps the sound going for up to 90 seconds, hoping you unlock it, then marks the lead Failed). A JustDial app update can change its screens and break the tapping. The number is read from the call log only after the call ends. After a phone restart the switch is OFF and you turn it on again yourself. When anything fails the lead says Failed with the reason and you can use the manual Call button.", 12, color = Muted)
    }

    if (pickApp) {
        val apps = remember { loadApps(ctx) }
        var q by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { pickApp = false }, containerColor = DialogBg, title = { Text("Choose the JustDial app") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TF("Search", q, { q = it })
                    Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                        apps.filter { q.isBlank() || it.label.contains(q, true) }.forEach { a ->
                            Column(Modifier.fillMaxWidth().clickable { AutoCall.setPkg(a.pkg); pickApp = false }.padding(vertical = 10.dp)) {
                                T(a.label, 15, true)
                                T(a.pkg, 11, color = Muted)
                            }
                        }
                    }
                }
            },
            confirmButton = {}, dismissButton = { TextButton(onClick = { pickApp = false }) { Text("Close") } })
    }
}
