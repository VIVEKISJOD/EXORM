package com.exorm.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/** Launch animation, exactly 1.3 seconds: logo grows in (0.6s), holds (0.4s), fades out (0.3s). */
@Composable
fun SplashOverlay(onDone: () -> Unit) {
    val appear = remember { Animatable(0f) }
    val leave = remember { Animatable(1f) }
    val progress = remember { Animatable(0f) }

    LaunchedEffect(Unit) { progress.animateTo(1f, tween(1300, easing = LinearEasing)) }
    LaunchedEffect(Unit) {
        appear.animateTo(1f, tween(600, easing = FastOutSlowInEasing))
        delay(400)
        leave.animateTo(0f, tween(300, easing = LinearEasing))
        onDone()
    }

    Box(
        Modifier.fillMaxSize().graphicsLayer { alpha = leave.value }.background(Color.Black).pointerInput(Unit) {},
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(R.drawable.exorm_logo),
                contentDescription = "EXORM",
                modifier = Modifier.fillMaxWidth(0.82f).graphicsLayer {
                    alpha = appear.value
                    val s = 0.8f + 0.2f * appear.value
                    scaleX = s
                    scaleY = s
                }
            )
            Spacer(Modifier.height(28.dp))
            Box(Modifier.width(160.dp).height(3.dp).clip(RoundedCornerShape(50)).background(Color(0x33FFFFFF))) {
                Box(Modifier.fillMaxSize().graphicsLayer {
                    scaleX = progress.value
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
                }.background(Color(0xFF2BE600)))
            }
        }
    }
}
