package com.exorm.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

interface HasId { val id: String }
fun newId(): String = UUID.randomUUID().toString()

fun <T> JSONArray.mapObj(f: (JSONObject) -> T): List<T> = (0 until length()).map { f(getJSONObject(it)) }
fun <T> List<T>.toJA(f: (T) -> Any): JSONArray { val a = JSONArray(); forEach { a.put(f(it)) }; return a }
fun JSONArray?.strings(): List<String> = if (this == null) emptyList() else (0 until length()).map { getString(it) }

data class Customer(
    override val id: String = newId(), val name: String = "", val phone: String = "", val phone2: String = "",
    val requirement: String = "", val notes: String = "", val budget: Long = 0, val archived: Boolean = false,
    val created: Long = System.currentTimeMillis()
) : HasId {
    fun toJ(): JSONObject = JSONObject().put("id", id).put("name", name).put("phone", phone).put("phone2", phone2)
        .put("requirement", requirement).put("notes", notes).put("budget", budget).put("archived", archived).put("created", created)
    companion object {
        fun fromJ(o: JSONObject) = Customer(o.getString("id"), o.optString("name"), o.optString("phone"), o.optString("phone2"),
            o.optString("requirement"), o.optString("notes"), o.optLong("budget"), o.optBoolean("archived"), o.optLong("created"))
    }
}

data class Followup(
    override val id: String = newId(), val customerId: String, val at: Long, val note: String = "", val quoted: Long = 0,
    val interest: String = "", val objection: String = "", val promise: String = "", val done: Boolean = false,
    val doneAt: Long = 0, val dropped: Boolean = false, val eventId: String = ""
) : HasId {
    fun toJ(): JSONObject = JSONObject().put("id", id).put("customerId", customerId).put("at", at).put("note", note).put("quoted", quoted)
        .put("interest", interest).put("objection", objection).put("promise", promise).put("done", done).put("doneAt", doneAt).put("dropped", dropped).put("eventId", eventId)
    companion object {
        fun fromJ(o: JSONObject) = Followup(o.getString("id"), o.optString("customerId"), o.optLong("at"), o.optString("note"), o.optLong("quoted"),
            o.optString("interest"), o.optString("objection"), o.optString("promise"), o.optBoolean("done"), o.optLong("doneAt"), o.optBoolean("dropped"), o.optString("eventId"))
    }
}

data class QItem(val desc: String, val qty: Int, val price: Long) {
    val total: Long get() = qty * price
    fun toJ(): JSONObject = JSONObject().put("desc", desc).put("qty", qty).put("price", price)
    companion object { fun fromJ(o: JSONObject) = QItem(o.optString("desc"), o.optInt("qty", 1), o.optLong("price")) }
}

data class Quote(
    override val id: String = newId(), val number: String = "", val customerId: String = "", val title: String = "",
    val items: List<QItem> = emptyList(), val discount: Long = 0, val taxPct: Double = 0.0, val status: String = "Draft",
    val created: Long = System.currentTimeMillis(), val validUntil: Long = 0, val notes: String = "", val history: List<String> = emptyList()
) : HasId {
    val subtotal: Long get() = items.sumOf { it.total }
    val tax: Long get() = Math.round((subtotal - discount).coerceAtLeast(0) * taxPct / 100.0)
    val total: Long get() = (subtotal - discount).coerceAtLeast(0) + tax
    fun effStatus(): String =
        if (validUntil > 0 && validUntil < startOfDay(System.currentTimeMillis()) && status in listOf("Draft", "Sent", "Negotiating")) "Expired" else status
    fun toJ(): JSONObject = JSONObject().put("id", id).put("number", number).put("customerId", customerId).put("title", title)
        .put("items", items.toJA { it.toJ() }).put("discount", discount).put("taxPct", taxPct).put("status", status)
        .put("created", created).put("validUntil", validUntil).put("notes", notes).put("history", history.toJA { it })
    companion object {
        fun fromJ(o: JSONObject) = Quote(o.getString("id"), o.optString("number"), o.optString("customerId"), o.optString("title"),
            o.optJSONArray("items")?.mapObj { QItem.fromJ(it) } ?: emptyList(), o.optLong("discount"), o.optDouble("taxPct", 0.0),
            o.optString("status", "Draft"), o.optLong("created"), o.optLong("validUntil"), o.optString("notes"), o.optJSONArray("history").strings())
    }
}

data class Payment(override val id: String = newId(), val amount: Long, val date: Long, val method: String = "Cash", val note: String = "") : HasId {
    fun toJ(): JSONObject = JSONObject().put("id", id).put("amount", amount).put("date", date).put("method", method).put("note", note)
    companion object { fun fromJ(o: JSONObject) = Payment(o.getString("id"), o.optLong("amount"), o.optLong("date"), o.optString("method"), o.optString("note")) }
}

data class Event(
    override val id: String = newId(), val customerId: String = "", val type: String = "", val date: Long = 0, val venue: String = "",
    val status: String = "Tentative", val agreed: Long = 0, val notes: String = "", val payments: List<Payment> = emptyList(),
    val collect: String = "", val dates: List<Long> = emptyList()
) : HasId {
    /** The main event day plus any extra event dates, each as the start of that day. */
    fun allDays(): List<Long> = (listOf(date) + dates).filter { it > 0 }.map { startOfDay(it) }
    val paid: Long get() = payments.sumOf { it.amount }
    val balance: Long get() = agreed - paid
    fun toJ(): JSONObject = JSONObject().put("id", id).put("customerId", customerId).put("type", type).put("date", date).put("venue", venue)
        .put("status", status).put("agreed", agreed).put("notes", notes).put("payments", payments.toJA { it.toJ() }).put("collect", collect).put("dates", dates.toJA { it })
    companion object {
        fun fromJ(o: JSONObject) = Event(o.getString("id"), o.optString("customerId"), o.optString("type"), o.optLong("date"), o.optString("venue"),
            o.optString("status", "Tentative"), o.optLong("agreed"), o.optString("notes"),
            o.optJSONArray("payments")?.mapObj { Payment.fromJ(it) } ?: emptyList(), o.optString("collect"),
            o.optJSONArray("dates")?.let { a -> (0 until a.length()).map { a.getLong(it) } } ?: emptyList())
    }
}

data class CItem(val name: String, val qty: Int, val got: Boolean = false, val missing: Int = 0, val damaged: Int = 0) {
    fun toJ(): JSONObject = JSONObject().put("name", name).put("qty", qty).put("got", got).put("missing", missing).put("damaged", damaged)
    companion object { fun fromJ(o: JSONObject) = CItem(o.optString("name"), o.optInt("qty", 1), o.optBoolean("got"), o.optInt("missing"), o.optInt("damaged")) }
}

data class Collect(
    override val id: String = newId(), val eventId: String = "", val customerId: String = "", val date: Long = 0,
    val items: List<CItem> = emptyList(), val notes: String = "", val status: String = "Active", val collectedAt: Long = 0
) : HasId {
    /** Active, Cancelled or Issue Reported are manual. Everything else is derived. */
    fun eff(): String {
        if (status == "Cancelled") return "Cancelled"
        if (items.isNotEmpty() && items.all { it.got }) {
            return if (items.any { it.missing > 0 || it.damaged > 0 } || status == "Issue Reported") "Issue Reported" else "Collected"
        }
        if (status == "Issue Reported") return "Issue Reported"
        if (items.any { it.got }) return "Partially Collected"
        if (date <= 0) return "Not Scheduled"
        val t0 = startOfDay(System.currentTimeMillis())
        if (date < t0) return "Overdue"
        if (date < addDays(t0, 3)) return "Due Soon"
        return "Scheduled"
    }
    fun isClosed(): Boolean = eff() in listOf("Collected", "Cancelled")
    fun toJ(): JSONObject = JSONObject().put("id", id).put("eventId", eventId).put("customerId", customerId).put("date", date)
        .put("items", items.toJA { it.toJ() }).put("notes", notes).put("status", status).put("collectedAt", collectedAt)
    companion object {
        fun fromJ(o: JSONObject) = Collect(o.getString("id"), o.optString("eventId"), o.optString("customerId"), o.optLong("date"),
            o.optJSONArray("items")?.mapObj { CItem.fromJ(it) } ?: emptyList(), o.optString("notes"), o.optString("status", "Active"), o.optLong("collectedAt"))
    }
}

data class Settings(
    val business: String = "SHAGUN SFX AND DECOR", val bizPhone: String = "", val currency: String = "₹", val cc: String = "91",
    val addons: Set<String> = emptySet(), val reminders: Boolean = true, val autoUpdate: Boolean = true, val onboarded: Boolean = false
) {
    fun toJ(): JSONObject = JSONObject().put("business", business).put("bizPhone", bizPhone).put("currency", currency).put("cc", cc)
        .put("addons", addons.toList().toJA { it }).put("reminders", reminders).put("autoUpdate", autoUpdate).put("onboarded", onboarded)
    companion object {
        fun fromJ(o: JSONObject) = Settings(o.optString("business", "SHAGUN SFX AND DECOR"), o.optString("bizPhone"), o.optString("currency", "₹"),
            o.optString("cc", "91"), o.optJSONArray("addons").strings().toSet(), o.optBoolean("reminders", true),
            o.optBoolean("autoUpdate", true), o.optBoolean("onboarded"))
    }
}

data class Addon(val id: String, val name: String, val desc: String)
val ADDONS = listOf(
    Addon("events", "Event Planner", "Event calendar, quotations with revisions, payments and outstanding balances."),
    Addon("collections", "Equipment Collection", "After an event, schedule and tick off equipment and leftover material you must collect. Needs Event Planner.")
)
fun addon(id: String): Boolean = id in Store.settings.addons
fun setAddon(id: String, on: Boolean) {
    val s = Store.settings.addons.toMutableSet()
    if (on) { s.add(id); if (id == "collections") s.add("events") } else { s.remove(id); if (id == "events") s.remove("collections") }
    Store.updateSettings(Store.settings.copy(addons = s))
}
