package com.exorm.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

// ---------- shared follow-up pieces ----------

@Composable
fun FollowRow(f: Followup, onLog: (Followup) -> Unit) {
    val ctx = LocalContext.current
    val c = Store.customers.find { it.id == f.customerId }
    val late = !f.done && f.at < startOfDay(System.currentTimeMillis())
    var del by remember { mutableStateOf(false) }
    Glass(onClick = { Nav.go(Screen.CustomerDetail(f.customerId)) }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T(c?.name ?: "Unknown", 16, true, maxLines = 1)
                T(f.note.ifBlank { "Follow-up call" }, 13, color = Muted, maxLines = 2)
                Spacer(Modifier.height(4.dp))
                T(fmtDT(f.at), 12, color = if (late) Danger else Accent)
            }
            if (!f.done && c != null) {
                RoundIcon(Icons.Default.Call, Color.Black, Accent) { dial(ctx, c.phone) }
                Spacer(Modifier.width(8.dp))
                RoundIcon(Icons.Default.Check) { onLog(f) }
            }
            Spacer(Modifier.width(8.dp))
            RoundIcon(Icons.Default.Delete, Danger, size = 40.dp) { del = true }
        }
        if (f.done) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (f.interest.isNotBlank()) Tag(f.interest, if (f.interest == "Not interested") Danger else if (f.interest == "Hot") Accent else Teal)
                if (f.quoted > 0) T("Quoted " + fmtMoney(f.quoted), 12, color = Muted)
            }
            if (f.objection.isNotBlank()) T("Objection: " + f.objection, 12, color = Muted)
            if (f.promise.isNotBlank()) T("Promised: " + f.promise, 12, color = Muted)
        }
    }
    if (del) Confirm("Delete this follow-up?", "The follow-up for " + (c?.name ?: "this customer") + " on " + fmtDT(f.at) + " will be removed.",
        onYes = { del = false; Store.remove(Store.followups, f.id) }, onNo = { del = false })
}

@Composable
fun LogDialog(f: Followup, onClose: () -> Unit) {
    var note by remember { mutableStateOf(f.note) }
    var quoted by remember { mutableStateOf(if (f.quoted > 0) f.quoted.toString() else "") }
    var interest by remember { mutableStateOf(f.interest) }
    var obj by remember { mutableStateOf(f.objection) }
    var promise by remember { mutableStateOf(f.promise) }
    var next by remember { mutableStateOf(0L) }
    AlertDialog(onDismissRequest = onClose, containerColor = DialogBg, title = { Text("Log conversation") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                TF("What the customer said / requested", note, { note = it }, lines = 3)
                TF("Price quoted", quoted, { quoted = it.filter { c -> c.isDigit() } }, kb = KeyboardType.Number)
                T("Interest", 12, color = Muted)
                ChipRow(listOf("Hot", "Warm", "Cold", "Not interested"), interest) { interest = it }
                TF("Objection / negotiation", obj, { obj = it }, lines = 2)
                TF("I promised to…", promise, { promise = it })
                DateField("Next follow-up", next, true) { next = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val notInt = interest == "Not interested"
                Store.put(Store.followups, f.copy(note = note.trim(), quoted = quoted.toLongOrNull() ?: 0, interest = interest,
                    objection = obj.trim(), promise = promise.trim(), done = true, doneAt = System.currentTimeMillis(), dropped = notInt))
                if (next > 0 && !notInt) Store.put(Store.followups, Followup(customerId = f.customerId, at = next, note = promise.trim()))
                onClose()
            }) { Text("Save", color = Accent) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } })
}

@Composable
fun ScheduleDialog(customerId: String, onClose: () -> Unit) {
    var at by remember { mutableStateOf(0L) }
    var note by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    AlertDialog(onDismissRequest = onClose, containerColor = DialogBg, title = { Text("Follow-up: " + cname(customerId)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DateField("When", at, true) { at = it }
                TF("Reminder note", note, { note = it }, lines = 2)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (at <= 0) toast(ctx, "Pick a date and time") else {
                    Store.put(Store.followups, Followup(customerId = customerId, at = at, note = note.trim())); onClose()
                }
            }) { Text("Schedule", color = Accent) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } })
}

@Composable
fun MessageDialog(c: Customer, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val biz = Store.settings.business
    val templates = linkedMapOf(
        "Follow-up" to "Hello ${c.name}, this is $biz. Just following up on your enquiry. Please let me know if you'd like to go ahead or discuss the details.",
        "Quotation" to "Hello ${c.name}, please find our quotation for your event. Let me know if you'd like any changes. – $biz",
        "Confirmed" to "Hello ${c.name}, your booking with $biz is confirmed. Thank you! We will stay in touch about the preparations.",
        "Event reminder" to "Hello ${c.name}, a reminder about your upcoming event. Our team from $biz will be there as planned.",
        "Collection" to "Hello ${c.name}, we will visit the venue to collect our equipment and leftover material. Please tell us a convenient time. – $biz",
        "Payment" to "Hello ${c.name}, a gentle reminder about the pending payment for your event. Thank you! – $biz"
    )
    var key by remember { mutableStateOf("Follow-up") }
    var text by remember { mutableStateOf(templates.getValue("Follow-up")) }
    AlertDialog(onDismissRequest = onClose, containerColor = DialogBg, title = { Text("Message " + c.name) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ChipRow(templates.keys.toList(), key) { key = it; text = templates.getValue(it) }
                TF("Message (editable)", text, { text = it }, lines = 5)
                T("Nothing is sent until you tap Send in WhatsApp.", 11, color = Muted)
            }
        },
        confirmButton = { TextButton(onClick = { whatsapp(ctx, c.phone, text); onClose() }) { Text("Open WhatsApp", color = Accent) } },
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } })
}

@Composable
fun Stat(label: String, value: String, modifier: Modifier, tint: Color? = null, onClick: () -> Unit) {
    val fg = if (tint != null) Color.Black else Color.White
    Glass(modifier, onClick, tint) {
        T(value, 28, true, color = fg)
        T(label, 12, color = if (tint != null) Color(0xAA000000) else Muted)
    }
}

// ---------- Home ----------

@Composable
fun HomeScreen() {
    var logging by remember { mutableStateOf<Followup?>(null) }
    val now = System.currentTimeMillis()
    val t0 = startOfDay(now)
    val t1 = addDays(t0, 1)
    val pend = Store.followups.filter { !it.done && !it.dropped }.sortedBy { it.at }
    val overdue = pend.filter { it.at < t0 }
    val today = pend.filter { it.at >= t0 && it.at < t1 }
    val ev = addon("events")
    val col = addon("collections")
    val upcoming = Store.events.filter { it.date >= t0 && (it.status == "Confirmed" || it.status == "In Progress") }.sortedBy { it.date }
    val todayEvents = upcoming.filter { it.date < t1 }
    val openCols = Store.collections.filter { !it.isClosed() }.sortedBy { it.date }
    val dueCols = openCols.filter { it.date in 1 until t1 }
    val balance = Store.events.filter { it.status == "Confirmed" || it.status == "In Progress" || it.status == "Completed" }
        .sumOf { it.balance.coerceAtLeast(0) }
    val newEnq = Store.customers.filter { !it.archived && Store.followups.none { f -> f.customerId == it.id } }
    val waitingQuotes = Store.quotes.filter { it.effStatus() == "Sent" || it.effStatus() == "Negotiating" }
    val recent = Store.followups.filter { it.done }.sortedByDescending { it.doneAt }.take(4)

    Page("EXORM", actions = { RoundIcon(Icons.Default.Settings) { Nav.go(Screen.Settings) } }) {
        T(Store.settings.business, 13, color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Follow-ups today", today.size.toString(), Modifier.weight(1f), Accent) { Nav.root(Screen.Followups) }
            Stat("Overdue follow-ups", overdue.size.toString(), Modifier.weight(1f)) { Nav.root(Screen.Followups) }
        }
        if (ev) Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Events today", todayEvents.size.toString(), Modifier.weight(1f)) { Nav.root(Screen.Calendar) }
            Stat("Balance to receive", fmtMoney(balance), Modifier.weight(1f)) { Nav.root(Screen.Calendar) }
        }

        if (ev || addon("showcase")) Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (ev) PBtn("Reports", Modifier.weight(1f), filled = false, icon = Icons.Default.List) { Nav.go(Screen.Reports) }
            if (addon("showcase")) PBtn("Showcase", Modifier.weight(1f), filled = false, icon = Icons.Default.Star) { Nav.go(Screen.Showcase) }
        }

        if (addon("leads")) {
            PBtn("Leads", Modifier.fillMaxWidth(), filled = false, icon = Icons.Default.Call) { Nav.go(Screen.Leads) }
        }

        if (overdue.isNotEmpty() || today.isNotEmpty()) {
            Section("Needs your attention", "See all") { Nav.root(Screen.Followups) }
            (overdue + today).take(5).forEach { FollowRow(it) { f -> logging = f } }
        } else Empty("No follow-ups due today. You're all caught up.")

        if (newEnq.isNotEmpty()) {
            Section("New enquiries without a follow-up")
            newEnq.take(3).forEach { c ->
                Glass(onClick = { Nav.go(Screen.CustomerDetail(c.id)) }) { T(c.name, 15, true); T(c.requirement.ifBlank { c.phone }, 12, color = Muted, maxLines = 1) }
            }
        }
        if (ev && waitingQuotes.isNotEmpty()) {
            Section("Quotations awaiting a decision", "All") { Nav.root(Screen.Quotes) }
            waitingQuotes.take(3).forEach { q ->
                Glass(onClick = { Nav.go(Screen.QuoteDetail(q.id)) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { T(cname(q.customerId), 15, true); T(q.number + " • " + fmtMoney(q.total), 12, color = Muted) }
                        Tag(q.effStatus(), Teal)
                    }
                }
            }
        }
        if (ev && upcoming.isNotEmpty()) {
            Section("Upcoming confirmed events", "Calendar") { Nav.root(Screen.Calendar) }
            upcoming.take(4).forEach { EventRow(it) }
        }
        if (col) {
            if (dueCols.isNotEmpty()) {
                Section("Equipment collections due", "All") { Nav.go(Screen.Collections) }
                dueCols.take(4).forEach { CollectRow(it) }
            } else if (openCols.isNotEmpty()) {
                Section("Equipment collections", "All") { Nav.go(Screen.Collections) }
                openCols.take(2).forEach { CollectRow(it) }
            }
        }
        if (recent.isNotEmpty()) {
            Section("Recent customer activity")
            recent.forEach { FollowRow(it) { } }
        }
    }
    logging?.let { LogDialog(it) { logging = null } }
}

// ---------- Customers ----------

@Composable
fun CustomersScreen() {
    var q by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Active") }
    val list = Store.customers.filter { (tab == "Archived") == it.archived && (q.isBlank() || it.matches(q)) }.sortedBy { it.name.lowercase() }
    Page("Customers", actions = { RoundIcon(Icons.Default.Add, Color.Black, Accent) { Nav.go(Screen.CustomerEdit(null)) } }) {
        TF("Search name, phone, notes", q, { q = it })
        ChipRow(listOf("Active", "Archived"), tab) { tab = it }
        if (list.isEmpty()) Empty(if (q.isBlank()) "No customers here yet. Tap + to add one." else "No match for \"$q\".")
        list.forEach { c ->
            val next = Store.followups.filter { it.customerId == c.id && !it.done && !it.dropped }.minByOrNull { it.at }
            Glass(onClick = { Nav.go(Screen.CustomerDetail(c.id)) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).background(Accent, CircleShape), contentAlignment = Alignment.Center) {
                        T(c.name.take(1).uppercase(), 18, true, Color.Black)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        T(c.name, 16, true, maxLines = 1)
                        T(c.phone + if (c.requirement.isNotBlank()) " • " + c.requirement else "", 12, color = Muted, maxLines = 1)
                        if (next != null) T("Follow-up " + fmtDT(next.at), 11, color = if (next.at < startOfDay(System.currentTimeMillis())) Danger else Accent)
                    }
                }
            }
        }
    }
}

@Composable
fun CustomerEditScreen(id: String?) {
    val old = Store.customers.find { it.id == id }
    var name by remember { mutableStateOf(old?.name ?: "") }
    var phone by remember { mutableStateOf(old?.phone ?: "") }
    var phone2 by remember { mutableStateOf(old?.phone2 ?: "") }
    var req by remember { mutableStateOf(old?.requirement ?: "") }
    var budget by remember { mutableStateOf(if ((old?.budget ?: 0) > 0) old!!.budget.toString() else "") }
    var notes by remember { mutableStateOf(old?.notes ?: "") }
    var first by remember { mutableStateOf(0L) }
    var err by remember { mutableStateOf("") }
    var dup by remember { mutableStateOf<Customer?>(null) }

    fun commit() {
        val c = (old ?: Customer()).copy(name = name.trim(), phone = phone.trim(), phone2 = phone2.trim(), requirement = req.trim(),
            budget = budget.toLongOrNull() ?: 0, notes = notes.trim())
        Store.put(Store.customers, c)
        if (old == null && first > 0) Store.put(Store.followups, Followup(customerId = c.id, at = first, note = req.trim()))
        if (old == null) Nav.replace(Screen.CustomerDetail(c.id)) else Nav.back()
    }

    Page(if (old == null) "New customer" else "Edit customer", back = true) {
        TF("Name *", name, { name = it })
        TF("Phone *", phone, { phone = it }, kb = KeyboardType.Phone)
        TF("Alternate phone", phone2, { phone2 = it }, kb = KeyboardType.Phone)
        TF("Requirement", req, { req = it }, lines = 2)
        TF("Budget (if told)", budget, { budget = it.filter { c -> c.isDigit() } }, kb = KeyboardType.Number)
        TF("Notes", notes, { notes = it }, lines = 3)
        if (old == null) DateField("First follow-up (optional)", first, true) { first = it }
        if (err.isNotBlank()) T(err, 13, color = Danger)
        PBtn("Save", Modifier.fillMaxWidth()) {
            if (name.isBlank()) err = "Enter a name"
            else if (digits(phone).length < 5) err = "Enter a valid phone number"
            else {
                err = ""
                val d = digits(phone).takeLast(10)
                val match = Store.customers.find { it.id != old?.id && digits(it.phone).takeLast(10) == d }
                if (match != null) dup = match else commit()
            }
        }
    }
    dup?.let { d ->
        AlertDialog(onDismissRequest = { dup = null }, containerColor = DialogBg, title = { Text("Phone number already exists") },
            text = { Text("${d.name} already uses this number. Open the existing profile instead of creating a duplicate?") },
            confirmButton = { TextButton(onClick = { dup = null; Nav.replace(Screen.CustomerDetail(d.id)) }) { Text("Open existing", color = Accent) } },
            dismissButton = { TextButton(onClick = { dup = null; commit() }) { Text("Save anyway") } })
    }
}

@Composable
fun CustomerDetailScreen(id: String) {
    val ctx = LocalContext.current
    val c = Store.customers.find { it.id == id }
    if (c == null) { Page("Customer", back = true) { Empty("This customer no longer exists.") }; return }
    var logging by remember { mutableStateOf<Followup?>(null) }
    var scheduling by remember { mutableStateOf(false) }
    var messaging by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    val ev = addon("events")
    val pend = Store.followups.filter { it.customerId == id && !it.done && !it.dropped }.sortedBy { it.at }
    val hist = Store.followups.filter { it.customerId == id && it.done }.sortedByDescending { it.doneAt }
    val quotes = Store.quotes.filter { it.customerId == id }.sortedByDescending { it.created }
    val events = Store.events.filter { it.customerId == id }.sortedByDescending { it.date }
    val cols = Store.collections.filter { it.customerId == id }.sortedByDescending { it.date }

    Page(c.name, back = true, actions = { RoundIcon(Icons.Default.Edit) { Nav.go(Screen.CustomerEdit(id)) } }) {
        Glass {
            T(c.phone + if (c.phone2.isNotBlank()) "  /  " + c.phone2 else "", 16, true)
            if (c.archived) Tag("Archived", Muted)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PBtn("Call", Modifier.weight(1f), icon = Icons.Default.Call) { dial(ctx, c.phone) }
                PBtn("WhatsApp", Modifier.weight(1f), filled = false, icon = Icons.Default.Send) { messaging = true }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PBtn("Log call", Modifier.weight(1f), filled = false, icon = Icons.Default.Edit) { logging = Followup(customerId = id, at = System.currentTimeMillis()) }
                PBtn("Follow-up", Modifier.weight(1f), filled = false, icon = Icons.Default.Notifications) { scheduling = true }
            }
        }
        if (c.requirement.isNotBlank() || c.budget > 0 || c.notes.isNotBlank()) Glass {
            if (c.requirement.isNotBlank()) { T("Requirement", 11, color = Muted); T(c.requirement, 14) }
            if (c.budget > 0) { Spacer(Modifier.height(6.dp)); T("Customer budget", 11, color = Muted); T(fmtMoney(c.budget), 14) }
            if (c.notes.isNotBlank()) { Spacer(Modifier.height(6.dp)); T("Notes", 11, color = Muted); T(c.notes, 14) }
        }
        Section("Scheduled follow-ups")
        if (pend.isEmpty()) Empty("None scheduled.")
        pend.forEach { FollowRow(it) { f -> logging = f } }

        if (ev) {
            Section("Quotations", "+ New") { Nav.go(Screen.QuoteEdit(null, id)) }
            if (quotes.isEmpty()) Empty("No quotations yet.")
            quotes.forEach { q ->
                Glass(onClick = { Nav.go(Screen.QuoteDetail(q.id)) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { T(q.number, 14, true); T(q.title.ifBlank { fmtDate(q.created) } + " • " + fmtMoney(q.total), 12, color = Muted) }
                        Tag(q.effStatus(), Teal)
                    }
                }
            }
            Section("Events", "+ New") { Nav.go(Screen.EventEdit(null, id)) }
            if (events.isEmpty()) Empty("No events yet.")
            events.forEach { EventRow(it) }
            if (cols.isNotEmpty()) {
                Section("Equipment collections")
                cols.forEach { CollectRow(it) }
            }
        }
        Section("Conversation history")
        if (hist.isEmpty()) Empty("No conversations logged yet.")
        hist.forEach { FollowRow(it) { } }

        Spacer(Modifier.height(8.dp))
        PBtn(if (c.archived) "Restore from archive" else "Archive customer", Modifier.fillMaxWidth(), filled = false) {
            Store.put(Store.customers, c.copy(archived = !c.archived))
        }
        PBtn("Delete customer", Modifier.fillMaxWidth(), filled = false, danger = true) { deleting = true }
    }
    logging?.let { LogDialog(it) { logging = null } }
    if (scheduling) ScheduleDialog(id) { scheduling = false }
    if (messaging) MessageDialog(c) { messaging = false }
    if (deleting) Confirm("Delete ${c.name}?", "This also deletes their follow-ups, quotations, events and collections. Archive instead if you may need them later.",
        onYes = { deleting = false; Nav.back(); Store.deleteCustomer(id) }, onNo = { deleting = false })
}

// ---------- Follow-ups ----------

@Composable
fun FollowupsScreen() {
    var tab by remember { mutableStateOf("Today") }
    var logging by remember { mutableStateOf<Followup?>(null) }
    val t0 = startOfDay(System.currentTimeMillis())
    val t1 = addDays(t0, 1)
    val pend = Store.followups.filter { !it.done && !it.dropped }.sortedBy { it.at }
    val list = when (tab) {
        "Today" -> pend.filter { it.at >= t0 && it.at < t1 }
        "Overdue" -> pend.filter { it.at < t0 }
        "Upcoming" -> pend.filter { it.at >= t1 }
        "Completed" -> Store.followups.filter { it.done && !it.dropped }.sortedByDescending { it.doneAt }
        else -> Store.followups.filter { it.dropped }.sortedByDescending { it.doneAt }
    }
    Page("Follow-ups") {
        ChipRow(listOf("Today", "Overdue", "Upcoming", "Completed", "Not interested"), tab) { tab = it }
        if (list.isEmpty()) Empty("Nothing in \"$tab\".")
        list.forEach { FollowRow(it) { f -> logging = f } }
    }
    logging?.let { LogDialog(it) { logging = null } }
}
