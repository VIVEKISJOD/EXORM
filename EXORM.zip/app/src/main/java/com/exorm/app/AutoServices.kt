package com.exorm.app

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.telecom.TelecomManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Catches the JustDial notification (name + place) and hands it to AutoCall. Also records leads while the switch is OFF. */
class LeadListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            AutoCall.init(applicationContext)
            val p = AutoCall.pkg()
            if (p.isBlank() || sbn.packageName != p) return
            val n = sbn.notification ?: return
            if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
            if (sbn.isOngoing) return
            val ex = n.extras
            val title = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = (ex?.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex?.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
            if (title.isBlank() && text.isBlank()) return
            val f = AutoCall.filter()
            if (f.isNotBlank() && !(title + " " + text).contains(f, true)) return
            val pi = n.contentIntent
            Handler(Looper.getMainLooper()).post { AutoCall.incoming(title, text, pi) }
        } catch (e: Exception) { }
    }
}

/** Only exists to show the "Auto-call is ON" notification and keep EXORM alive while the switch is ON. */
class AutoCallService : Service() {
    companion object { var running = false }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        AutoCall.init(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("exorm_autocall", "Auto-call", NotificationManager.IMPORTANCE_LOW))
            val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(this, "exorm_autocall")
                .setContentTitle("Auto-call is ON")
                .setContentText("EXORM will call new JustDial leads. Tap to open.")
                .setSmallIcon(android.R.drawable.ic_menu_call)
                .setContentIntent(open)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 34) startForeground(7001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(7001, n)
            running = true
        } catch (e: Exception) {
            running = false
            stopSelf()
            return START_NOT_STICKY
        }
        // after a phone restart the switch is OFF again, so a restarted service stops itself
        if (!AutoCall.readOn()) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }
}

/**
 * Taps the blue Call button in JustDial for us, and the dialer / pop-up button if one appears after that.
 * It only acts while AutoCall is working on a lead, and only in the JustDial app or the phone's dialer app.
 */
class AutoCallAccess : AccessibilityService() {
    companion object { var instance: AutoCallAccess? = null }

    private var followTaps = 0
    private var lastFollow = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (n == null || depth > 25 || out.size > 600) return
        out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    private fun label(n: AccessibilityNodeInfo): String =
        ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "") + " " + (n.viewIdResourceName ?: "")).lowercase()

    private fun isCallish(n: AccessibilityNodeInfo): Boolean {
        val s = label(n)
        if (s.contains("whatsapp") || s.contains("detail") || s.contains("recall")) return false
        return s.contains("call") || s.contains("phone") || s.contains("dial")
    }

    private fun clickTarget(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var p: AccessibilityNodeInfo? = n
        var d = 0
        while (p != null && d < 4) {
            if (p.isClickable) return p
            p = p.parent
            d++
        }
        return null
    }

    private fun callButtonIn(card: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(card, all, 0)
        for (n in all) {
            if (isCallish(n)) {
                val t = clickTarget(n)
                if (t != null) return t
            }
        }
        return null
    }

    private fun topOf(n: AccessibilityNodeInfo): Int { val b = Rect(); n.getBoundsInScreen(b); return b.top }
    private fun leftOf(n: AccessibilityNodeInfo): Int { val b = Rect(); n.getBoundsInScreen(b); return b.left }

    /** Guess for icon-only buttons: in the right half of a big card, text-less, lowest row, leftmost = the Call button. */
    private fun iconButtonIn(card: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val r = Rect()
        card.getBoundsInScreen(r)
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(card, all, 0)
        val cands = ArrayList<AccessibilityNodeInfo>()
        for (n in all) {
            if (!n.isClickable) continue
            if (!n.text.isNullOrBlank()) continue
            val b = Rect()
            n.getBoundsInScreen(b)
            if (b.centerX() <= r.centerX()) continue
            if (label(n).contains("whatsapp")) continue
            cands.add(n)
        }
        if (cands.isEmpty()) return null
        val maxTop = cands.maxOf { topOf(it) }
        return cands.filter { topOf(it) >= maxTop - 60 }.minByOrNull { leftOf(it) }
    }

    /** Looks for this lead's Call button in JustDial and taps it. Returns true only if a tap was made. */
    fun tapCall(pkg: String, name: String): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != pkg) return false
        val rootBounds = Rect()
        root.getBoundsInScreen(rootBounds)
        var target: AccessibilityNodeInfo? = null
        if (name.isNotBlank()) {
            val found = root.findAccessibilityNodeInfosByText(name) ?: emptyList<AccessibilityNodeInfo>()
            for (nn in found) {
                var p: AccessibilityNodeInfo? = nn
                var depth = 0
                while (p != null && depth < 7 && target == null) {
                    target = callButtonIn(p)
                    if (target == null) {
                        val pb = Rect()
                        p.getBoundsInScreen(pb)
                        if (pb.width() >= rootBounds.width() * 0.6) target = iconButtonIn(p)
                    }
                    p = p.parent
                    depth++
                }
                if (target != null) break
            }
        }
        if (target == null) {
            // the lead may have opened on its own screen: if there is exactly one Call button, use it
            val all = ArrayList<AccessibilityNodeInfo>()
            collect(root, all, 0)
            val calls = all.filter { isCallish(it) }.mapNotNull { clickTarget(it) }
            if (calls.size == 1) target = calls[0]
        }
        val t = target ?: return false
        val ok = t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        if (ok) { followTaps = 0; lastFollow = 0L }
        return ok
    }

    /** After the first tap: a pop-up in JustDial, or the dialer showing the number, may need one more tap. */
    fun followUp(justdial: String) {
        val now = System.currentTimeMillis()
        if (followTaps >= 3 || now - lastFollow < 3000L) return
        val root = rootInActiveWindow ?: return
        val p = root.packageName?.toString() ?: return
        if (p == packageName) return
        val dialer = try { (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage } catch (e: Exception) { null }
        val isJd = p == justdial
        val isDialer = (dialer != null && p == dialer) || p.contains("dialer") || p.contains("contacts")
        if (!isJd && !isDialer) return
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all, 0)
        val words = setOf("call", "call now", "yes", "ok", "continue", "proceed", "allow", "confirm")
        for (n in all) {
            val txt = (n.text?.toString() ?: "").trim().lowercase()
            val id = (n.viewIdResourceName ?: "").lowercase()
            val desc = (n.contentDescription?.toString() ?: "").lowercase()
            val hit = if (isJd) txt in words else (id.contains("dial") || desc.contains("dial") || desc == "call" || txt == "call")
            if (!hit) continue
            val t = clickTarget(n) ?: continue
            if (t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                followTaps++
                lastFollow = now
                return
            }
        }
    }
}
