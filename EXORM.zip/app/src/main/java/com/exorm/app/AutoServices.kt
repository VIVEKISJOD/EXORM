package com.exorm.app

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.telecom.TelecomManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Catches the JustDial notification (name + place) and hands it to AutoCall. Also records leads while the switch is OFF. */
class LeadListener : NotificationListenerService() {
    /** Android reconnects this service by itself after a phone restart, so the working-hours schedule is re-checked here. */
    override fun onListenerConnected() {
        super.onListenerConnected()
        try {
            AutoCall.init(applicationContext)
            AutoCall.scheduleCheck()
        } catch (e: Exception) { }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            AutoCall.init(applicationContext)
            AutoCall.scheduleCheck()
            val p = AutoCall.pkg()
            val pk = sbn.packageName ?: return
            if (p.isBlank() || pk != p) {
                if (!sbn.isOngoing) AutoCall.seenPkg(pk)
                return
            }
            val n = sbn.notification ?: return
            val ex = n.extras
            val title = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            var text = (ex?.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex?.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
            if (text.isBlank()) {
                val lines = ex?.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
                if (lines != null) text = lines.joinToString(" ") { it.toString() }
            }
            if (text.isBlank()) text = ex?.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString() ?: ""
            val shown = "[" + title + "] " + text
            if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) { AutoCall.addLog("Ignored (group summary): " + shown); return }
            if (sbn.isOngoing) { AutoCall.addLog("Ignored (ongoing): " + shown); return }
            if (title.isBlank() && text.isBlank()) { AutoCall.addLog("Ignored (empty notification)"); return }
            if (!AutoCall.filterOk(title + " " + text)) { AutoCall.addLog("Ignored (filter word not found): " + shown); return }
            AutoCall.addLog("Accepted as lead: " + shown)
            val pi = n.contentIntent
            Handler(Looper.getMainLooper()).post { AutoCall.incoming(title, text, pi) }
        } catch (e: Exception) { }
    }
}

/** Only exists to show the "Auto-call is ON" notification and keep EXORM alive while the switch is ON. */
class AutoCallService : Service() {
    companion object { var running = false }

    private val beat = Handler(Looper.getMainLooper())
    private val beatRun = object : Runnable {
        override fun run() {
            AutoCall.scheduleCheck()   // switches OFF at the end time even if the alarm was delayed
            if (running) beat.postDelayed(this, 20_000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        AutoCall.init(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("exorm_autocall", "Auto-call", NotificationManager.IMPORTANCE_LOW))
            val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(this, "exorm_autocall")
                .setContentTitle("Auto-call is ON")
                .setContentText("EXORM will call new JustDial leads. Tap to open.")
                .setSmallIcon(android.R.drawable.ic_menu_call)
                .setContentIntent(open)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 34) startForeground(7001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(7001, n)
            running = true
            beat.removeCallbacks(beatRun)
            beat.postDelayed(beatRun, 20_000L)
        } catch (e: Exception) {
            running = false
            stopSelf()
            return START_NOT_STICKY
        }
        // after a phone restart the switch is OFF again, so a restarted service stops itself
        if (!AutoCall.readOn()) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        beat.removeCallbacks(beatRun)
        super.onDestroy()
    }
}

/**
 * Taps the blue Call button in JustDial for us, and the dialer / pop-up button if one appears after that.
 * It only acts while AutoCall is working on a lead, and only in the JustDial app or the phone's dialer app.
 */
class AutoCallAccess : AccessibilityService() {
    companion object { var instance: AutoCallAccess? = null }

    private var followTaps = 0
    private var lastFollow = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (n == null || depth > 25 || out.size > 600) return
        out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    private fun label(n: AccessibilityNodeInfo): String =
        ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "") + " " + (n.viewIdResourceName ?: "")).lowercase()

    private fun isCallish(n: AccessibilityNodeInfo): Boolean {
        val s = label(n)
        if (s.contains("whatsapp") || s.contains("detail") || s.contains("recall")) return false
        return s.contains("call") || s.contains("phone") || s.contains("dial")
    }

    private fun clickTarget(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var p: AccessibilityNodeInfo? = n
        var d = 0
        while (p != null && d < 4) {
            if (p.isClickable) return p
            p = p.parent
            d++
        }
        return null
    }

    private fun callButtonIn(card: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(card, all, 0)
        for (n in all) {
            if (isCallish(n)) {
                val t = clickTarget(n)
                if (t != null) return t
            }
        }
        return null
    }

    private fun topOf(n: AccessibilityNodeInfo): Int { val b = Rect(); n.getBoundsInScreen(b); return b.top }
    private fun leftOf(n: AccessibilityNodeInfo): Int { val b = Rect(); n.getBoundsInScreen(b); return b.left }

    /** Guess for icon-only buttons: in the right half of a big card, text-less, lowest row, leftmost = the Call button. */
    private fun iconButtonIn(card: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val r = Rect()
        card.getBoundsInScreen(r)
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(card, all, 0)
        val cands = ArrayList<AccessibilityNodeInfo>()
        for (n in all) {
            if (!n.isClickable) continue
            if (!n.text.isNullOrBlank()) continue
            val b = Rect()
            n.getBoundsInScreen(b)
            if (b.centerX() <= r.centerX()) continue
            if (label(n).contains("whatsapp")) continue
            cands.add(n)
        }
        if (cands.isEmpty()) return null
        val maxTop = cands.maxOf { topOf(it) }
        return cands.filter { topOf(it) >= maxTop - 60 }.minByOrNull { leftOf(it) }
    }

    private fun txt(n: AccessibilityNodeInfo): String = (n.text?.toString() ?: "").trim()

    /** The whole lead card around a "Details" link: the biggest wide-but-short box that contains it. */
    private fun cardOf(d: AccessibilityNodeInfo, rb: Rect): AccessibilityNodeInfo? {
        var p: AccessibilityNodeInfo? = d.parent
        var best: AccessibilityNodeInfo? = null
        var depth = 0
        while (p != null && depth < 10) {
            val b = Rect()
            p.getBoundsInScreen(b)
            if (b.width() >= rb.width() * 0.6 && b.height() <= rb.height() * 0.4) best = p
            else if (best != null) break
            p = p.parent
            depth++
        }
        return best
    }

    private fun cardText(card: AccessibilityNodeInfo): String {
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(card, all, 0)
        return all.joinToString(" ") { (it.text?.toString() ?: "") + " " + (it.contentDescription?.toString() ?: "") }.lowercase()
    }

    /** The blue phone button of a lead card: label says call, or the left one of the two small round buttons on the right. */
    private fun phoneButtonIn(card: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val byLabel = callButtonIn(card)
        if (byLabel != null) return byLabel
        val r = Rect()
        card.getBoundsInScreen(r)
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(card, all, 0)
        val cands = ArrayList<AccessibilityNodeInfo>()
        for (n in all) {
            if (!n.isClickable || !n.text.isNullOrBlank()) continue
            val b = Rect()
            n.getBoundsInScreen(b)
            if (b.centerX() <= r.centerX() || b.width() > r.width() * 0.25) continue
            if (label(n).contains("whatsapp")) continue
            cands.add(n)
        }
        if (cands.isEmpty()) return null
        val maxTop = cands.maxOf { topOf(it) }
        return cands.filter { topOf(it) >= maxTop - 60 }.minByOrNull { leftOf(it) }
    }

    private fun tapAt(x: Float, y: Float): Boolean {
        return try {
            val path = android.graphics.Path()
            path.moveTo(x, y)
            val g = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0L, 80L)).build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) { false }
    }

    private fun clickOrTap(n: AccessibilityNodeInfo): Boolean {
        val t = clickTarget(n)
        if (t != null && t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val b = Rect()
        n.getBoundsInScreen(b)
        return tapAt(b.centerX().toFloat(), b.centerY().toFloat())
    }

    /**
     * Walks JustDial like a person: bottom "Leads" tab -> "All" chip -> blue phone button of the newest lead.
     * Returns -1 = JustDial is not on screen, 0 = nothing done yet (waiting), 1 = made a navigation tap, 2 = tapped Call.
     */
    fun navigate(pkg: String, name: String, j: CallJob, now: Long): Int {
        val root = rootInActiveWindow ?: return -1
        if (root.packageName?.toString() != pkg) return -1
        val rb = Rect()
        root.getBoundsInScreen(rb)
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all, 0)
        val details = all.filter { txt(it).equals("Details", true) }.sortedBy { topOf(it) }
        val allChip = all.firstOrNull { txt(it).equals("All", true) }
        if (j.sub == 0) {
            if (details.isNotEmpty() && allChip != null) { j.sub = 1; return 0 }       // already on the Leads screen
            val tab = all.filter { txt(it).equals("Leads", true) }.maxByOrNull { topOf(it) }
            if (tab != null && clickOrTap(tab)) { j.sub = 1; return 1 }
            if (j.backs < 3) { j.backs++; performGlobalAction(GLOBAL_ACTION_BACK); return 1 }   // some other JustDial screen is open
            return 0
        }
        if (j.sub == 1) {
            if (allChip == null) return 0                                                // Leads screen still loading
            if (clickOrTap(allChip)) { j.sub = 2; j.waitFrom = 0L; return 1 }
            return 0
        }
        // sub 2: the newest lead is the top card
        if (details.isEmpty()) {
            val sc = all.firstOrNull { it.isScrollable }
            sc?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
            return 0
        }
        val cards = details.mapNotNull { d -> cardOf(d, rb) }
        if (cards.isEmpty()) return 0
        val nm = name.trim().lowercase()
        var pick: AccessibilityNodeInfo? = if (nm.isNotEmpty()) cards.firstOrNull { cardText(it).contains(nm) } else null
        if (pick == null) {
            if (j.waitFrom == 0L) j.waitFrom = now
            // give the new lead up to 12 seconds to show up in JustDial's list, then use the top card
            if (nm.isNotEmpty() && now - j.waitFrom < 12_000L) return 0
            pick = cards.first()
        }
        val btn = phoneButtonIn(pick)
        if (btn != null && btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) { followTaps = 0; lastFollow = 0L; return 2 }
        // last resort: tap where the blue phone button sits on the card (about 20% from the right edge, middle of the card)
        val b = Rect()
        pick.getBoundsInScreen(b)
        if (tapAt(b.right - 0.195f * b.width(), b.top + 0.5f * b.height())) { followTaps = 0; lastFollow = 0L; return 2 }
        return 0
    }

    /** A short text picture of what is on the screen, for the Notification log when something gets stuck. */
    fun screenDump(): String {
        val root = rootInActiveWindow ?: return "no screen"
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all, 0)
        val sb = StringBuilder()
        sb.append(root.packageName).append(": ")
        var n = 0
        for (x in all) {
            val t = txt(x)
            val d = (x.contentDescription?.toString() ?: "").trim()
            if (t.isEmpty() && d.isEmpty() && !x.isClickable) continue
            val b = Rect()
            x.getBoundsInScreen(b)
            sb.append("[").append((x.className?.toString() ?: "").substringAfterLast('.')).append(" '").append(t.take(25))
                .append("' '").append(d.take(25)).append("' ").append(if (x.isClickable) "C " else "")
                .append(b.left).append(",").append(b.top).append("] ")
            n++
            if (n >= 40) break
        }
        return sb.toString()
    }

    /** Looks for this lead's Call button in JustDial and taps it. Returns true only if a tap was made. */
    fun tapCall(pkg: String, name: String): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != pkg) return false
        val rootBounds = Rect()
        root.getBoundsInScreen(rootBounds)
        var target: AccessibilityNodeInfo? = null
        if (name.isNotBlank()) {
            val found = root.findAccessibilityNodeInfosByText(name) ?: emptyList<AccessibilityNodeInfo>()
            for (nn in found) {
                var p: AccessibilityNodeInfo? = nn
                var depth = 0
                while (p != null && depth < 7 && target == null) {
                    target = callButtonIn(p)
                    if (target == null) {
                        val pb = Rect()
                        p.getBoundsInScreen(pb)
                        if (pb.width() >= rootBounds.width() * 0.6) target = iconButtonIn(p)
                    }
                    p = p.parent
                    depth++
                }
                if (target != null) break
            }
        }
        if (target == null) {
            // the lead may have opened on its own screen: if there is exactly one Call button, use it
            val all = ArrayList<AccessibilityNodeInfo>()
            collect(root, all, 0)
            val calls = all.filter { isCallish(it) }.mapNotNull { clickTarget(it) }
            if (calls.size == 1) target = calls[0]
        }
        val t = target ?: return false
        val ok = t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        if (ok) { followTaps = 0; lastFollow = 0L }
        return ok
    }

    /** In WhatsApp, with the message already typed by the wa.me link: taps the Send button. */
    fun tapSend(): Boolean {
        val root = rootInActiveWindow ?: return false
        val p = root.packageName?.toString() ?: return false
        if (p != "com.whatsapp" && p != "com.whatsapp.w4b") return false
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all, 0)
        for (n in all) {
            val id = (n.viewIdResourceName ?: "").lowercase()
            val desc = (n.contentDescription?.toString() ?: "").trim().lowercase()
            if (id.endsWith(":id/send") || desc == "send") {
                val t = clickTarget(n) ?: continue
                if (t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
        }
        return false
    }

    /** After the first tap: a pop-up in JustDial, or the dialer showing the number, may need one more tap. */
    fun followUp(justdial: String) {
        val now = System.currentTimeMillis()
        if (followTaps >= 3 || now - lastFollow < 3000L) return
        val root = rootInActiveWindow ?: return
        val p = root.packageName?.toString() ?: return
        if (p == packageName) return
        val dialer = try { (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage } catch (e: Exception) { null }
        val isJd = p == justdial
        val isDialer = (dialer != null && p == dialer) || p.contains("dialer") || p.contains("contacts")
        if (!isJd && !isDialer) return
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all, 0)
        val words = setOf("call", "call now", "yes", "ok", "continue", "proceed", "allow", "confirm")
        for (n in all) {
            val txt = (n.text?.toString() ?: "").trim().lowercase()
            val id = (n.viewIdResourceName ?: "").lowercase()
            val desc = (n.contentDescription?.toString() ?: "").lowercase()
            val hit = if (isJd) txt in words else (id.contains("dial") || desc.contains("dial") || desc == "call" || txt == "call")
            if (!hit) continue
            val t = clickTarget(n) ?: continue
            if (t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                followTaps++
                lastFollow = now
                return
            }
        }
    }
}
