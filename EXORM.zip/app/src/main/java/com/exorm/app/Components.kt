package com.exorm.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Accent = Color(0xFFEAE35E)
val Blue = Color(0xFF3B5BDB)
val Teal = Color(0xFF5FA8B8)
val Muted = Color(0x99FFFFFF)
val GlassBorder = Color(0x26FFFFFF)
val Danger = Color(0xFFFF6B6B)
val Good = Color(0xFF63E6A0)
val DialogBg = Color(0xFF141414)

@Composable
fun ExormTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, onPrimary = Color.Black, background = Color.Black, surface = DialogBg,
            onSurface = Color.White, onBackground = Color.White, secondary = Blue
        ), content = content
    )
}

/** Pure-black AMOLED base with soft blurred colour glows behind translucent glass cards. */
@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Box(Modifier.offset((-90).dp, (-70).dp).size(300.dp).blur(60.dp)
            .background(Brush.radialGradient(listOf(Accent.copy(alpha = .30f), Color.Transparent)), CircleShape))
        Box(Modifier.align(Alignment.CenterEnd).offset(110.dp, 40.dp).size(300.dp).blur(70.dp)
            .background(Brush.radialGradient(listOf(Blue.copy(alpha = .38f), Color.Transparent)), CircleShape))
        Box(Modifier.align(Alignment.BottomStart).offset((-80).dp, 60.dp).size(280.dp).blur(70.dp)
            .background(Brush.radialGradient(listOf(Teal.copy(alpha = .26f), Color.Transparent)), CircleShape))
        content()
    }
}

@Composable
fun Glass(
    modifier: Modifier = Modifier.fillMaxWidth(), onClick: (() -> Unit)? = null, tint: Color? = null,
    pad: Dp = 16.dp, content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    val bg = if (tint != null) Brush.verticalGradient(listOf(tint, tint))
    else Brush.verticalGradient(listOf(Color.White.copy(alpha = .11f), Color.White.copy(alpha = .04f)))
    var m = modifier.clip(shape).background(bg).border(1.dp, GlassBorder, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(pad), content = content)
}

@Composable
fun T(text: String, size: Int = 14, bold: Boolean = false, color: Color = Color.White, modifier: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE) {
    Text(text, modifier = modifier, color = color, fontSize = size.sp, fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal,
        maxLines = maxLines, overflow = TextOverflow.Ellipsis)
}

@Composable
fun RoundIcon(icon: ImageVector, tint: Color = Color.White, bg: Color = Color.White.copy(alpha = .10f), size: Dp = 44.dp, onClick: () -> Unit) {
    Box(Modifier.size(size).clip(CircleShape).background(bg).border(1.dp, GlassBorder, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun Header(title: String, back: Boolean = false, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back) { RoundIcon(Icons.Default.ArrowBack) { Nav.back() }; Spacer(Modifier.width(12.dp)) }
        T(title, 24, true, modifier = Modifier.weight(1f), maxLines = 1)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically, content = actions)
    }
}

@Composable
fun Page(title: String, back: Boolean = false, actions: @Composable RowScope.() -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header(title, back, actions)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}

@Composable
fun PBtn(text: String, modifier: Modifier = Modifier, filled: Boolean = true, icon: ImageVector? = null, danger: Boolean = false, onClick: () -> Unit) {
    val bg = if (filled) (if (danger) Danger else Accent) else Color.White.copy(alpha = .08f)
    val fg = if (filled) Color.Black else (if (danger) Danger else Color.White)
    Row(modifier.clip(RoundedCornerShape(50)).background(bg)
        .border(1.dp, if (filled) Color.Transparent else GlassBorder, RoundedCornerShape(50))
        .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) { Icon(icon, null, tint = fg, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun Chip(text: String, sel: Boolean, onClick: () -> Unit) {
    Text(text, color = if (sel) Color.Black else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) Color.White else Color.White.copy(alpha = .08f))
            .border(1.dp, GlassBorder, RoundedCornerShape(50)).clickable(onClick = onClick).padding(14.dp, 8.dp))
}

@Composable
fun ChipRow(options: List<String>, sel: String, onSel: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { Chip(it, it == sel) { onSel(it) } }
    }
}

@Composable
fun Tag(text: String, color: Color) {
    Text(text.uppercase(), color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = .16f)).padding(8.dp, 3.dp))
}

@Composable
fun TF(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier.fillMaxWidth(),
       kb: KeyboardType = KeyboardType.Text, lines: Int = 1) {
    OutlinedTextField(
        value = value, onValueChange = onChange, modifier = modifier, label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = kb), singleLine = lines == 1,
        minLines = lines, maxLines = if (lines > 1) 6 else 1, shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Accent, unfocusedBorderColor = GlassBorder, focusedLabelColor = Accent, unfocusedLabelColor = Muted,
            focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Accent,
            focusedContainerColor = Color.White.copy(alpha = .05f), unfocusedContainerColor = Color.White.copy(alpha = .05f)
        )
    )
}

@Composable
fun DateField(label: String, value: Long, withTime: Boolean, onChange: (Long) -> Unit) {
    val ctx = LocalContext.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .05f))
        .border(1.dp, GlassBorder, RoundedCornerShape(16.dp)).clickable { pickDate(ctx, value, withTime, onChange) }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            T(label, 11, color = Muted)
            T(if (value > 0) (if (withTime) fmtDT(value) else fmtDate(value)) else "Tap to set", 15)
        }
        if (value > 0) Icon(Icons.Default.Clear, null, tint = Muted, modifier = Modifier.size(22.dp).clickable { onChange(0) })
        else Icon(Icons.Default.DateRange, null, tint = Muted, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun Empty(text: String) {
    Glass { T(text, 14, color = Muted) }
}

@Composable
fun Section(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        T(title, 17, true, modifier = Modifier.weight(1f))
        if (action != null) Text(action, color = Accent, fontSize = 13.sp, modifier = Modifier.clickable(onClick = onAction))
    }
}

@Composable
fun Confirm(title: String, text: String, ok: String = "Delete", onYes: () -> Unit, onNo: () -> Unit) {
    AlertDialog(onDismissRequest = onNo, containerColor = DialogBg, title = { Text(title) }, text = { Text(text) },
        confirmButton = { TextButton(onClick = onYes) { Text(ok, color = Danger) } },
        dismissButton = { TextButton(onClick = onNo) { Text("Cancel") } })
}

@Composable
fun PickCustomer(onPick: (Customer) -> Unit, onClose: () -> Unit) {
    var q by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, containerColor = DialogBg, title = { Text("Choose customer") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TF("Search", q, { q = it })
                Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                    val list = Store.customers.filter { !it.archived && (q.isBlank() || it.matches(q)) }.sortedBy { it.name.lowercase() }
                    if (list.isEmpty()) T("No customers yet. Add one first.", 13, color = Muted)
                    list.forEach { c ->
                        Column(Modifier.fillMaxWidth().clickable { onPick(c) }.padding(vertical = 10.dp)) {
                            T(c.name, 15, true); T(c.phone, 12, color = Muted)
                        }
                    }
                }
            }
        },
        confirmButton = {}, dismissButton = { TextButton(onClick = onClose) { Text("Close") } })
}

@Composable
fun UpdateDialog(info: Updater.Info, onClose: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(onDismissRequest = onClose, containerColor = DialogBg, title = { Text("Update available") },
        text = { Text("A newer version of EXORM (build ${info.code}) is ready. Tap Download, then open the downloaded file to install. Your data is kept.") },
        confirmButton = { TextButton(onClick = { openUrl(ctx, info.url); onClose() }) { Text("Download", color = Accent) } },
        dismissButton = { TextButton(onClick = onClose) { Text("Later") } })
}

@Composable
fun BottomBar(current: Screen) {
    val tabs = buildList<Triple<String, ImageVector, Screen>> {
        add(Triple("Home", Icons.Default.Home, Screen.Home))
        add(Triple("Customers", Icons.Default.Person, Screen.Customers))
        add(Triple("Follow-ups", Icons.Default.Notifications, Screen.Followups))
        if (addon("events")) {
            add(Triple("Calendar", Icons.Default.DateRange, Screen.Calendar))
            add(Triple("Quotes", Icons.Default.List, Screen.Quotes))
        }
    }
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clip(RoundedCornerShape(32.dp))
        .background(Color(0xCC101010)).border(1.dp, GlassBorder, RoundedCornerShape(32.dp)).padding(6.dp)) {
        tabs.forEach { (label, icon, scr) ->
            val sel = current == scr
            Column(Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).background(if (sel) Accent else Color.Transparent)
                .clickable { Nav.root(scr) }.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(icon, null, tint = if (sel) Color.Black else Muted, modifier = Modifier.size(22.dp))
                Text(label, fontSize = 10.sp, color = if (sel) Color.Black else Muted, maxLines = 1)
            }
        }
    }
}
