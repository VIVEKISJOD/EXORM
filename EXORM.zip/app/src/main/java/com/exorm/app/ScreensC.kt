package com.exorm.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------- collections ----------

@Composable
fun CollectionsScreen() {
    var tab by remember { mutableStateOf("Pending") }
    var deciding by remember { mutableStateOf<Event?>(null) }
    val t0 = startOfDay(System.currentTimeMillis())
    val t1 = addDays(t0, 1)
    val all = Store.collections.sortedBy { it.date }
    val list = when (tab) {
        "Pending" -> all.filter { !it.isClosed() }
        "Today" -> all.filter { !it.isClosed() && it.date >= t0 && it.date < t1 }
        "Soon" -> all.filter { it.eff() == "Due Soon" }
        "Overdue" -> all.filter { it.eff() == "Overdue" }
        "Partial" -> all.filter { it.eff() == "Partially Collected" }
        "Issues" -> all.filter { it.eff() == "Issue Reported" }
        "Done" -> all.filter { it.eff() == "Collected" }
        else -> all
    }
    val undecided = Store.events.filter { it.status == "Completed" && it.collect == "unsure" && Store.collections.none { c -> c.eventId == it.id } }
    Page("Collections", back = true) {
        ChipRow(listOf("Pending", "Today", "Soon", "Overdue", "Partial", "Issues", "Done", "All"), tab) { tab = it }
        if (undecided.isNotEmpty()) {
            Section("Decide: collection not sure yet")
            undecided.forEach { e -> Glass(onClick = { deciding = e }) { T(cname(e.customerId) + " • " + e.type, 15, true); T("Tap to decide", 12, color = Accent) } }
        }
        if (list.isEmpty()) Empty("No collections in \"$tab\".")
        list.forEach { CollectRow(it) }
    }
    deciding?.let { e -> CollectPrompt(e) { cid -> deciding = null; if (cid != null) Nav.go(Screen.CollectionDetail(cid)) } }
}

@Composable
fun CollectionDetailScreen(id: String) {
    val ctx = LocalContext.current
    val col = Store.collections.find { it.id == id }
    if (col == null) { Page("Collection", back = true) { Empty("This collection no longer exists.") }; return }
    val ev = Store.events.find { it.id == col.eventId }
    val cu = Store.customers.find { it.id == col.customerId }
    var notes by remember { mutableStateOf(col.notes) }
    var adding by remember { mutableStateOf(false) }
    var issueFor by remember { mutableStateOf<Int?>(null) }
    var deleting by remember { mutableStateOf(false) }
    val eff = col.eff()

    fun saveItems(items: List<CItem>) {
        val all = items.isNotEmpty() && items.all { it.got }
        Store.put(Store.collections, col.copy(items = items, collectedAt = if (all) (if (col.collectedAt > 0) col.collectedAt else System.currentTimeMillis()) else 0))
    }

    Page("Collection", back = true) {
        Glass {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { T(cu?.name ?: "Unknown", 17, true); T(cu?.phone ?: "", 13, color = Muted) }
                Tag(eff, statusColor(eff))
            }
            Spacer(Modifier.height(8.dp))
            if (ev != null) {
                T("Event", 11, color = Muted); T(ev.type + " • " + fmtDate(ev.date) + " (" + ev.status + ")", 14)
                Spacer(Modifier.height(4.dp))
                T("Venue", 11, color = Muted); T(ev.venue.ifBlank { "—" }, 14)
            }
            if (col.collectedAt > 0) { Spacer(Modifier.height(4.dp)); T("Actual collection date", 11, color = Muted); T(fmtDate(col.collectedAt), 14) }
            if (cu != null) {
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PBtn("Call", Modifier.weight(1f), icon = Icons.Default.Call) { dial(ctx, cu.phone) }
                    PBtn("WhatsApp", Modifier.weight(1f), filled = false, icon = Icons.Default.Send) {
                        whatsapp(ctx, cu.phone, "Hello ${cu.name}, we will visit the venue on ${fmtDate(col.date)} to collect our equipment and leftover material. Please tell us a convenient time. – ${Store.settings.business}")
                    }
                }
            }
        }
        DateField("Planned collection date", col.date, false) { Store.put(Store.collections, col.copy(date = it)) }
        if (ev != null) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PBtn("Event + 2 days", Modifier.weight(1f), filled = false) { Store.put(Store.collections, col.copy(date = addDays(startOfDay(ev.date), 2))) }
            PBtn("Event + 3 days", Modifier.weight(1f), filled = false) { Store.put(Store.collections, col.copy(date = addDays(startOfDay(ev.date), 3))) }
        }
        Section("Items to collect", "+ Add") { adding = true }
        if (col.items.isEmpty()) Empty("Add the items you need to bring back.")
        col.items.forEachIndexed { i, it ->
            Glass {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(it.got, { g -> saveItems(col.items.toMutableList().also { l -> l[i] = it.copy(got = g) }) })
                    Column(Modifier.weight(1f)) {
                        T(it.name + " × " + it.qty, 15, true)
                        if (it.missing > 0 || it.damaged > 0) T("Missing " + it.missing + " • Damaged " + it.damaged, 12, color = Danger)
                    }
                    RoundIcon(Icons.Default.Warning, if (it.missing > 0 || it.damaged > 0) Danger else Muted, size = 36.dp) { issueFor = i }
                    Spacer(Modifier.width(6.dp))
                    RoundIcon(Icons.Default.Delete, Danger, size = 36.dp) { saveItems(col.items.filterIndexed { j, _ -> j != i }) }
                }
            }
        }
        if (col.items.isNotEmpty()) PBtn("Mark all collected", Modifier.fillMaxWidth(), icon = Icons.Default.Check) { saveItems(col.items.map { it.copy(got = true) }) }
        TF("Notes (where items are stored, who to contact)", notes, { notes = it }, lines = 3)
        PBtn("Save notes", Modifier.fillMaxWidth(), filled = false) { Store.put(Store.collections, col.copy(notes = notes.trim())); toast(ctx, "Saved") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PBtn(if (col.status == "Issue Reported") "Clear issue" else "Report issue", Modifier.weight(1f), filled = false) {
                Store.put(Store.collections, col.copy(status = if (col.status == "Issue Reported") "Active" else "Issue Reported"))
            }
            PBtn(if (col.status == "Cancelled") "Reopen" else "Cancel task", Modifier.weight(1f), filled = false) {
                Store.put(Store.collections, col.copy(status = if (col.status == "Cancelled") "Active" else "Cancelled"))
            }
        }
        PBtn("Delete task", Modifier.fillMaxWidth(), filled = false, danger = true) { deleting = true }
    }

    if (adding) {
        var name by remember { mutableStateOf("") }
        var qty by remember { mutableStateOf("1") }
        AlertDialog(onDismissRequest = { adding = false }, containerColor = DialogBg, title = { Text("Add item") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TF("Item name", name, { name = it })
                    TF("Quantity", qty, { qty = it.filter { c -> c.isDigit() } }, kb = KeyboardType.Number)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) saveItems(col.items + CItem(name.trim(), (qty.toIntOrNull() ?: 1).coerceAtLeast(1)))
                    adding = false
                }) { Text("Add", color = Accent) }
            }, dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } })
    }
    issueFor?.let { idx ->
        val item = col.items.getOrNull(idx)
        if (item == null) issueFor = null else {
            var missing by remember { mutableStateOf(item.missing.toString()) }
            var damaged by remember { mutableStateOf(item.damaged.toString()) }
            AlertDialog(onDismissRequest = { issueFor = null }, containerColor = DialogBg, title = { Text("Missing or damaged: " + item.name) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        TF("Missing quantity (of ${item.qty})", missing, { missing = it.filter { c -> c.isDigit() } }, kb = KeyboardType.Number)
                        TF("Damaged quantity", damaged, { damaged = it.filter { c -> c.isDigit() } }, kb = KeyboardType.Number)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        saveItems(col.items.toMutableList().also { l ->
                            l[idx] = item.copy(missing = (missing.toIntOrNull() ?: 0).coerceIn(0, item.qty), damaged = (damaged.toIntOrNull() ?: 0).coerceIn(0, item.qty))
                        })
                        issueFor = null
                    }) { Text("Save", color = Accent) }
                }, dismissButton = { TextButton(onClick = { issueFor = null }) { Text("Cancel") } })
        }
    }
    if (deleting) Confirm("Delete this collection task?", "The event itself is not affected.", onYes = { deleting = false; Nav.back(); Store.remove(Store.collections, id) }, onNo = { deleting = false })
}

// ---------- settings, add-ons, backup ----------

@Composable
fun AddonsScreen() {
    Page("Add-ons", back = true) {
        T("Add-ons change what EXORM does for you. Turning one off only hides it. Your data stays safe.", 13, color = Muted)
        ADDONS.forEach { a ->
            Glass {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { T(a.name, 16, true); T(a.desc, 12, color = Muted) }
                    Switch(checked = addon(a.id), onCheckedChange = { setAddon(a.id, it) },
                        colors = SwitchDefaults.colors(checkedTrackColor = Accent, checkedThumbColor = Color.Black))
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val s = Store.settings
    var biz by remember { mutableStateOf(s.business) }
    var phone by remember { mutableStateOf(s.bizPhone) }
    var cur by remember { mutableStateOf(s.currency) }
    var cc by remember { mutableStateOf(s.cc) }
    var pending by remember { mutableStateOf<JSONObject?>(null) }
    var update by remember { mutableStateOf<Updater.Info?>(null) }
    val stamp = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) try {
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(Store.toJson().toString(2).toByteArray()) }
            toast(ctx, "Backup saved")
        } catch (e: Exception) { toast(ctx, "Backup failed") }
    }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = try { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() } catch (e: Exception) { null }
            val o = text?.let { Store.validate(it) }
            if (o == null) toast(ctx, "This is not a valid EXORM backup") else pending = o
        }
    }
    val csv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) try {
            val sb = StringBuilder("Name,Phone,Alternate phone,Requirement,Budget,Notes,Archived\n")
            fun q(x: String) = "\"" + x.replace("\"", "\"\"") + "\""
            Store.customers.forEach { sb.append(q(it.name)).append(',').append(q(it.phone)).append(',').append(q(it.phone2)).append(',')
                .append(q(it.requirement)).append(',').append(it.budget).append(',').append(q(it.notes)).append(',').append(it.archived).append('\n') }
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(sb.toString().toByteArray()) }
            toast(ctx, "Exported")
        } catch (e: Exception) { toast(ctx, "Export failed") }
    }

    Page("Settings", back = true) {
        Glass {
            T("Business", 16, true)
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TF("Business name", biz, { biz = it })
                TF("Business phone (shown on quotations)", phone, { phone = it }, kb = KeyboardType.Phone)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TF("Currency", cur, { cur = it }, Modifier.weight(1f))
                    TF("Country code", cc, { cc = it.filter { c -> c.isDigit() } }, Modifier.weight(1f), KeyboardType.Number)
                }
                PBtn("Save", Modifier.fillMaxWidth()) {
                    Store.updateSettings(Store.settings.copy(business = biz.trim().ifBlank { "My Business" }, bizPhone = phone.trim(), currency = cur.ifBlank { "₹" }, cc = cc.ifBlank { "91" }))
                    toast(ctx, "Saved")
                }
            }
        }
        Glass(onClick = { Nav.go(Screen.Addons) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { T("Add-ons", 16, true); T(if (s.addons.isEmpty()) "None enabled" else s.addons.size.toString() + " enabled", 12, color = Muted) }
                Icon(Icons.Default.ArrowForward, null, tint = Muted)
            }
        }
        Glass {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { T("Reminders", 16, true); T("Local notifications for follow-ups, events and collections", 12, color = Muted) }
                Switch(checked = s.reminders, onCheckedChange = { Store.updateSettings(Store.settings.copy(reminders = it)) },
                    colors = SwitchDefaults.colors(checkedTrackColor = Accent, checkedThumbColor = Color.Black))
            }
        }
        Glass {
            T("Backup & export", 16, true)
            T("Your data lives only on this phone. Keep backups somewhere safe, such as Google Drive or WhatsApp to yourself.", 12, color = Muted)
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PBtn("Create backup", Modifier.fillMaxWidth()) { export.launch("exorm-backup-$stamp.json") }
                PBtn("Restore from backup", Modifier.fillMaxWidth(), filled = false) { import.launch(arrayOf("*/*")) }
                PBtn("Export customers (CSV)", Modifier.fillMaxWidth(), filled = false) { csv.launch("exorm-customers-$stamp.csv") }
            }
        }
        Glass {
            T("App updates", 16, true)
            T("Version " + BuildConfig.VERSION_NAME, 12, color = Muted)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                T("Check automatically on start", 13, modifier = Modifier.weight(1f))
                Switch(checked = s.autoUpdate, onCheckedChange = { Store.updateSettings(Store.settings.copy(autoUpdate = it)) },
                    colors = SwitchDefaults.colors(checkedTrackColor = Accent, checkedThumbColor = Color.Black))
            }
            PBtn("Check for updates now", Modifier.fillMaxWidth(), filled = false) {
                Updater.check { info, err -> if (info != null) update = info else toast(ctx, err ?: "You are up to date") }
            }
        }
    }
    pending?.let { o ->
        Confirm("Replace all current data?", "Restoring replaces everything in the app with the backup. This cannot be undone.", ok = "Restore",
            onYes = { Store.load(o); Store.save(); pending = null; toast(ctx, "Backup restored") }, onNo = { pending = null })
    }
    update?.let { UpdateDialog(it) { update = null } }
}
