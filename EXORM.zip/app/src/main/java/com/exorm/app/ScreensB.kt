package com.exorm.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

val EVENT_STATUSES = listOf("Enquiry", "Tentative", "Confirmed", "In Progress", "Completed", "Cancelled")
val EVENT_TYPES = listOf("Wedding", "Ring Ceremony", "Diwali Decor", "Birthday", "Corporate", "Other")

fun statusColor(s: String): Color = when (s) {
    "Confirmed" -> Accent
    "In Progress" -> Color(0xFF74A0FF)
    "Completed", "Collected", "Accepted" -> Good
    "Cancelled", "Overdue", "Rejected", "Issue Reported", "Expired" -> Danger
    "Due Soon" -> Accent
    "Partially Collected", "Sent", "Negotiating" -> Teal
    else -> Muted
}

// ---------- rows ----------

@Composable
fun EventRow(e: Event) {
    val soft = e.status == "Enquiry" || e.status == "Tentative"
    Glass(onClick = { Nav.go(Screen.EventDetail(e.id)) }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.width(54.dp).clip(RoundedCornerShape(16.dp)).background(if (soft) Color.White.copy(alpha = .08f) else Accent).padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                val d = Date(e.date)
                T(SimpleDateFormat("dd", Locale.getDefault()).format(d), 20, true, if (soft) Color.White else Color.Black)
                T(SimpleDateFormat("MMM", Locale.getDefault()).format(d).uppercase(), 10, false, if (soft) Muted else Color.Black)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                T(e.type.ifBlank { "Event" } + " • " + cname(e.customerId), 15, true, maxLines = 1)
                T(e.venue.ifBlank { "Venue not set" }, 12, color = Muted, maxLines = 1)
                if (e.agreed > 0) T(fmtMoney(e.agreed) + (if (e.balance > 0) " • due " + fmtMoney(e.balance) else " • paid"), 11, color = Muted)
            }
            Tag(if (soft) e.status + " (not booked)" else e.status, statusColor(e.status))
        }
    }
}

@Composable
fun CollectRow(c: Collect) {
    val ev = Store.events.find { it.id == c.eventId }
    Glass(onClick = { Nav.go(Screen.CollectionDetail(c.id)) }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T(cname(c.customerId), 15, true, maxLines = 1)
                T((ev?.venue ?: "").ifBlank { "Venue not set" } + " • " + fmtDate(c.date), 12, color = Muted, maxLines = 1)
                T(c.items.count { it.got }.toString() + " of " + c.items.size + " items collected", 11, color = Muted)
            }
            Tag(c.eff(), statusColor(c.eff()))
        }
    }
}

// ---------- calendar ----------

@Composable
fun CalendarScreen() {
    var month by remember { mutableStateOf(startOfMonth(System.currentTimeMillis())) }
    var sel by remember { mutableStateOf(startOfDay(System.currentTimeMillis())) }
    val cal = Calendar.getInstance().apply { timeInMillis = month }
    val dim = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstDow = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
    val rows = (firstDow + dim + 6) / 7
    val live = Store.events.filter { it.status != "Cancelled" }
    val t0 = startOfDay(System.currentTimeMillis())
    val onDay = live.filter { startOfDay(it.date) == sel }.sortedBy { it.date }
    val upcoming = live.filter { it.date >= t0 && it.status != "Completed" }.sortedBy { it.date }.take(8)

    Page("Calendar", actions = { RoundIcon(Icons.Default.Add, Color.Black, Accent) { Nav.go(Screen.EventEdit(null)) } }) {
        if (addon("collections")) PBtn("Equipment collections", Modifier.fillMaxWidth(), filled = false, icon = Icons.Default.Build) { Nav.go(Screen.Collections) }
        Glass {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RoundIcon(Icons.Default.ArrowBack, size = 36.dp) { month = addMonths(month, -1) }
                T(monthTitle(month), 17, true, modifier = Modifier.weight(1f))
                RoundIcon(Icons.Default.ArrowForward, size = 36.dp) { month = addMonths(month, 1) }
            }
            Spacer(Modifier.height(8.dp))
            Row { listOf("M", "T", "W", "T", "F", "S", "S").forEach { Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { T(it, 11, color = Muted) } } }
            for (w in 0 until rows) {
                Row {
                    for (d in 0..6) {
                        val day = w * 7 + d - firstDow + 1
                        if (day < 1 || day > dim) Box(Modifier.weight(1f).aspectRatio(1f))
                        else {
                            val ds = dayOfMonth(month, day)
                            val es = live.filter { startOfDay(it.date) == ds }
                            val isSel = ds == sel
                            Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp).clip(CircleShape)
                                .background(if (isSel) Accent else Color.Transparent)
                                .then(if (ds == t0 && !isSel) Modifier.border(1.dp, Accent, CircleShape) else Modifier)
                                .clickable { sel = ds }, contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    T(day.toString(), 13, isSel, if (isSel) Color.Black else Color.White)
                                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                        es.take(3).forEach {
                                            val soft = it.status == "Enquiry" || it.status == "Tentative"
                                            Box(Modifier.size(5.dp).clip(CircleShape).background(if (soft) Color.Transparent else if (isSel) Color.Black else statusColor(it.status))
                                                .border(1.dp, if (soft) Muted else Color.Transparent, CircleShape))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            T("Filled dot = booked. Hollow dot = enquiry or tentative, not a confirmed booking.", 10, color = Muted)
        }
        Section(fmtDate(sel))
        if (onDay.isEmpty()) Empty("No events on this day.")
        onDay.forEach { EventRow(it) }
        Section("Upcoming")
        if (upcoming.isEmpty()) Empty("No upcoming events.")
        upcoming.forEach { EventRow(it) }
    }
}

// ---------- events ----------

@Composable
fun CollectPrompt(e: Event, onDone: (String?) -> Unit) {
    AlertDialog(onDismissRequest = { onDone(null) }, containerColor = DialogBg,
        title = { Text("Do you need to collect equipment or leftover materials from this event?") },
        text = { Text("Completing the event does not mark anything as collected. Collection is tracked separately.") },
        confirmButton = {
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = {
                    var c = Store.collections.find { it.eventId == e.id && it.status != "Cancelled" }
                    if (c == null) {
                        c = Collect(eventId = e.id, customerId = e.customerId, date = addDays(startOfDay(e.date), 2))
                        Store.put(Store.collections, c)
                    }
                    Store.put(Store.events, e.copy(collect = "yes"))
                    onDone(c.id)
                }) { Text("Yes, collection required", color = Accent) }
                TextButton(onClick = { Store.put(Store.events, e.copy(collect = "no")); onDone(null) }) { Text("No collection required") }
                TextButton(onClick = { Store.put(Store.events, e.copy(collect = "unsure")); onDone(null) }) { Text("Not sure yet") }
            }
        })
}

@Composable
fun EventEditScreen(id: String?, customerId: String?) {
    val old = Store.events.find { it.id == id }
    var cust by remember { mutableStateOf(old?.customerId ?: customerId ?: "") }
    var type by remember { mutableStateOf(old?.type ?: "Wedding") }
    var date by remember { mutableStateOf(old?.date ?: 0L) }
    var venue by remember { mutableStateOf(old?.venue ?: "") }
    var status by remember { mutableStateOf(old?.status ?: "Tentative") }
    var agreed by remember { mutableStateOf(if ((old?.agreed ?: 0) > 0) old!!.agreed.toString() else "") }
    var notes by remember { mutableStateOf(old?.notes ?: "") }
    var pickC by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    var dateWarn by remember { mutableStateOf(false) }
    var prompt by remember { mutableStateOf<Event?>(null) }

    fun commit(moveCol: Boolean) {
        val e = (old ?: Event()).copy(customerId = cust, type = type.trim(), date = date, venue = venue.trim(), status = status,
            agreed = agreed.toLongOrNull() ?: 0, notes = notes.trim())
        Store.put(Store.events, e)
        if (moveCol) Store.collections.filter { it.eventId == e.id && !it.isClosed() }.forEach {
            Store.put(Store.collections, it.copy(date = addDays(startOfDay(e.date), 2)))
        }
        if (e.status == "Completed" && old?.status != "Completed" && addon("collections")) prompt = e else Nav.back()
    }

    Page(if (old == null) "New event" else "Edit event", back = true) {
        Glass(onClick = { pickC = true }) {
            T("Customer *", 11, color = Muted)
            T(if (cust.isBlank()) "Tap to choose" else cname(cust), 15)
        }
        TF("Event type", type, { type = it })
        ChipRow(EVENT_TYPES, type) { type = it }
        DateField("Event date & time *", date, true) { date = it }
        TF("Venue / address", venue, { venue = it }, lines = 2)
        T("Status", 12, color = Muted)
        ChipRow(EVENT_STATUSES, status) { status = it }
        if (status == "Enquiry" || status == "Tentative") T("Enquiries and tentative events are shown as not booked on the calendar.", 11, color = Muted)
        TF("Agreed amount", agreed, { agreed = it.filter { c -> c.isDigit() } }, kb = KeyboardType.Number)
        TF("Special instructions / notes", notes, { notes = it }, lines = 3)
        if (err.isNotBlank()) T(err, 13, color = Danger)
        PBtn("Save", Modifier.fillMaxWidth()) {
            if (cust.isBlank()) err = "Choose a customer"
            else if (date <= 0) err = "Set the event date"
            else {
                err = ""
                val hasCol = old != null && old.date != date && Store.collections.any { it.eventId == old.id && !it.isClosed() }
                if (hasCol) dateWarn = true else commit(false)
            }
        }
    }
    if (pickC) PickCustomer({ cust = it.id; pickC = false }, { pickC = false })
    if (dateWarn) {
        AlertDialog(onDismissRequest = { dateWarn = false }, containerColor = DialogBg, title = { Text("Event date changed") },
            text = { Text("This event has a collection task that is not finished. Its collection date is not changed automatically. Move it to 2 days after the new event date?") },
            confirmButton = { TextButton(onClick = { dateWarn = false; commit(true) }) { Text("Move collection", color = Accent) } },
            dismissButton = { TextButton(onClick = { dateWarn = false; commit(false) }) { Text("Keep collection date") } })
    }
    prompt?.let { e -> CollectPrompt(e) { cid -> prompt = null; if (cid != null) Nav.replace(Screen.CollectionDetail(cid)) else Nav.back() } }
}

@Composable
fun PaymentDialog(e: Event, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var amount by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("Cash") }
    var date by remember { mutableStateOf(startOfDay(System.currentTimeMillis())) }
    var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, containerColor = DialogBg, title = { Text("Record payment") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                T("Balance now: " + fmtMoney(e.balance), 12, color = Muted)
                TF("Amount received", amount, { amount = it.filter { c -> c.isDigit() } }, kb = KeyboardType.Number)
                ChipRow(listOf("Cash", "UPI", "Bank", "Cheque", "Other"), method) { method = it }
                DateField("Payment date", date, false) { date = it }
                TF("Note", note, { note = it })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = amount.toLongOrNull() ?: 0
                if (a <= 0) toast(ctx, "Enter an amount")
                else if (e.agreed > 0 && a > e.balance) toast(ctx, "That is more than the balance due")
                else {
                    Store.put(Store.events, e.copy(payments = e.payments + Payment(amount = a, date = if (date > 0) date else System.currentTimeMillis(), method = method, note = note.trim())))
                    onClose()
                }
            }) { Text("Save", color = Accent) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } })
}

@Composable
fun EventDetailScreen(id: String) {
    val ctx = LocalContext.current
    val e = Store.events.find { it.id == id }
    if (e == null) { Page("Event", back = true) { Empty("This event no longer exists.") }; return }
    val c = Store.customers.find { it.id == e.customerId }
    var paying by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var delPay by remember { mutableStateOf<Payment?>(null) }
    var prompt by remember { mutableStateOf(false) }
    var messaging by remember { mutableStateOf(false) }
    val cols = Store.collections.filter { it.eventId == id }

    Page(e.type.ifBlank { "Event" }, back = true, actions = { RoundIcon(Icons.Default.Edit) { Nav.go(Screen.EventEdit(id)) } }) {
        Glass {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable { Nav.go(Screen.CustomerDetail(e.customerId)) }) {
                    T(c?.name ?: "Unknown", 17, true); T(c?.phone ?: "", 13, color = Muted)
                }
                Tag(e.status, statusColor(e.status))
            }
            Spacer(Modifier.height(10.dp))
            T("When", 11, color = Muted); T(fmtDT(e.date), 14)
            Spacer(Modifier.height(6.dp))
            T("Venue", 11, color = Muted); T(e.venue.ifBlank { "—" }, 14)
            if (e.notes.isNotBlank()) { Spacer(Modifier.height(6.dp)); T("Instructions", 11, color = Muted); T(e.notes, 14) }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (c != null) PBtn("Call", Modifier.weight(1f), icon = Icons.Default.Call) { dial(ctx, c.phone) }
                if (c != null) PBtn("Message", Modifier.weight(1f), filled = false, icon = Icons.Default.Send) { messaging = true }
            }
        }
        T("Status", 12, color = Muted)
        ChipRow(EVENT_STATUSES, e.status) { s ->
            if (s != e.status) {
                Store.put(Store.events, e.copy(status = s))
                if (s == "Completed" && addon("collections")) prompt = true
            }
        }
        Glass {
            T("Payments", 15, true)
            Spacer(Modifier.height(6.dp))
            Row { Column(Modifier.weight(1f)) { T("Agreed", 11, color = Muted); T(fmtMoney(e.agreed), 15, true) }
                Column(Modifier.weight(1f)) { T("Paid", 11, color = Muted); T(fmtMoney(e.paid), 15, true, Good) }
                Column(Modifier.weight(1f)) { T("Balance", 11, color = Muted); T(fmtMoney(e.balance), 15, true, if (e.balance > 0) Accent else Good) } }
            Spacer(Modifier.height(8.dp))
            if (e.payments.isEmpty()) T("No payments recorded yet.", 12, color = Muted)
            e.payments.sortedBy { it.date }.forEach { p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { T(fmtMoney(p.amount) + " • " + p.method, 14); T(fmtDate(p.date) + if (p.note.isNotBlank()) " • " + p.note else "", 11, color = Muted) }
                    RoundIcon(Icons.Default.Delete, Danger, size = 34.dp) { delPay = p }
                }
            }
            Spacer(Modifier.height(8.dp))
            PBtn("Add payment", Modifier.fillMaxWidth(), icon = Icons.Default.Add) { paying = true }
        }
        if (addon("collections")) {
            Section("Equipment collection")
            if (cols.isEmpty()) {
                Empty(when (e.collect) { "no" -> "Marked: no collection required."; "unsure" -> "Collection: not sure yet."; else -> "No collection task for this event." })
                PBtn("Create collection task", Modifier.fillMaxWidth(), filled = false) { prompt = true }
            }
            cols.forEach { CollectRow(it) }
        }
        PBtn("Delete event", Modifier.fillMaxWidth(), filled = false, danger = true) { deleting = true }
    }
    if (paying) PaymentDialog(e) { paying = false }
    if (messaging && c != null) MessageDialog(c) { messaging = false }
    delPay?.let { p -> Confirm("Delete this payment?", fmtMoney(p.amount) + " on " + fmtDate(p.date) + " will be removed from the record.",
        onYes = { Store.put(Store.events, e.copy(payments = e.payments.filter { it.id != p.id })); delPay = null }, onNo = { delPay = null }) }
    if (deleting) Confirm("Delete this event?", "Its payments and collection tasks will also be deleted.",
        onYes = { deleting = false; Nav.back(); Store.deleteEvent(id) }, onNo = { deleting = false })
    if (prompt) CollectPrompt(e) { cid -> prompt = false; if (cid != null) Nav.go(Screen.CollectionDetail(cid)) }
}

// ---------- quotations ----------

@Composable
fun QuotesScreen() {
    var tab by remember { mutableStateOf("All") }
    var q by remember { mutableStateOf("") }
    val list = Store.quotes.filter { (tab == "All" || it.effStatus() == tab) && (q.isBlank() || it.number.contains(q, true) || cname(it.customerId).contains(q, true) || it.title.contains(q, true)) }
        .sortedByDescending { it.created }
    Page("Quotations", actions = { RoundIcon(Icons.Default.Add, Color.Black, Accent) { Nav.go(Screen.QuoteEdit(null)) } }) {
        TF("Search number, customer, title", q, { q = it })
        ChipRow(listOf("All", "Draft", "Sent", "Negotiating", "Accepted", "Rejected", "Expired"), tab) { tab = it }
        if (list.isEmpty()) Empty("No quotations here.")
        list.forEach { qt ->
            Glass(onClick = { Nav.go(Screen.QuoteDetail(qt.id)) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        T(cname(qt.customerId), 16, true, maxLines = 1)
                        T(qt.number + " • " + fmtDate(qt.created), 12, color = Muted)
                        T(fmtMoney(qt.total), 14, true, Accent)
                    }
                    Tag(qt.effStatus(), statusColor(qt.effStatus()))
                }
            }
        }
    }
}

data class RowS(val desc: String, val qty: String, val price: String)

@Composable
fun QuoteEditScreen(id: String?, customerId: String?) {
    val old = Store.quotes.find { it.id == id }
    var cust by remember { mutableStateOf(old?.customerId ?: customerId ?: "") }
    var title by remember { mutableStateOf(old?.title ?: "") }
    val rows = remember {
        mutableStateListOf<RowS>().apply {
            addAll(old?.items?.map { RowS(it.desc, it.qty.toString(), it.price.toString()) } ?: listOf(RowS("", "1", "")))
        }
    }
    var discount by remember { mutableStateOf(if ((old?.discount ?: 0) > 0) old!!.discount.toString() else "") }
    var tax by remember { mutableStateOf(if ((old?.taxPct ?: 0.0) > 0) old!!.taxPct.toString() else "") }
    var status by remember { mutableStateOf(old?.status ?: "Draft") }
    var valid by remember { mutableStateOf(old?.validUntil ?: 0L) }
    var notes by remember { mutableStateOf(old?.notes ?: "") }
    var pickC by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }

    fun items(): List<QItem> = rows.filter { it.desc.isNotBlank() && (it.price.toLongOrNull() ?: 0) > 0 }
        .map { QItem(it.desc.trim(), (it.qty.toIntOrNull() ?: 1).coerceAtLeast(1), it.price.toLong()) }
    val preview = Quote(items = items(), discount = discount.toLongOrNull() ?: 0, taxPct = tax.toDoubleOrNull() ?: 0.0)

    Page(if (old == null) "New quotation" else "Revise " + old.number, back = true) {
        Glass(onClick = { pickC = true }) { T("Customer *", 11, color = Muted); T(if (cust.isBlank()) "Tap to choose" else cname(cust), 15) }
        TF("Event / title (e.g. Wedding entry effects)", title, { title = it })
        Section("Items")
        rows.forEachIndexed { i, r ->
            Glass {
                TF("Service / description", r.desc, { rows[i] = r.copy(desc = it) })
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TF("Qty", r.qty, { rows[i] = r.copy(qty = it.filter { c -> c.isDigit() }) }, Modifier.weight(0.35f), KeyboardType.Number)
                    TF("Price each", r.price, { rows[i] = r.copy(price = it.filter { c -> c.isDigit() }) }, Modifier.weight(0.65f), KeyboardType.Number)
                    if (rows.size > 1) RoundIcon(Icons.Default.Delete, Danger, size = 40.dp) { rows.removeAt(i) }
                }
            }
        }
        PBtn("Add item", Modifier.fillMaxWidth(), filled = false, icon = Icons.Default.Add) { rows.add(RowS("", "1", "")) }
        TF("Discount (amount)", discount, { discount = it.filter { c -> c.isDigit() } }, kb = KeyboardType.Number)
        TF("Tax % (leave empty for none)", tax, { tax = it.filter { c -> c.isDigit() || c == '.' } }, kb = KeyboardType.Decimal)
        Glass {
            Row { T("Subtotal", 13, color = Muted, modifier = Modifier.weight(1f)); T(fmtMoney(preview.subtotal), 13) }
            if (preview.tax > 0) Row { T("Tax", 13, color = Muted, modifier = Modifier.weight(1f)); T(fmtMoney(preview.tax), 13) }
            Row { T("Total", 16, true, modifier = Modifier.weight(1f)); T(fmtMoney(preview.total), 16, true, Accent) }
        }
        DateField("Valid until", valid, false) { valid = it }
        T("Status", 12, color = Muted)
        ChipRow(listOf("Draft", "Sent", "Negotiating", "Accepted", "Rejected"), status) { status = it }
        TF("Notes, exclusions, terms", notes, { notes = it }, lines = 3)
        if (err.isNotBlank()) T(err, 13, color = Danger)
        PBtn("Save quotation", Modifier.fillMaxWidth()) {
            val its = items()
            if (cust.isBlank()) err = "Choose a customer"
            else if (its.isEmpty()) err = "Add at least one item with a description and price"
            else if ((discount.toLongOrNull() ?: 0) > preview.subtotal) err = "Discount is larger than the subtotal"
            else {
                val base = old ?: Quote(number = nextQuoteNumber())
                var hist = base.history
                if (old != null && (old.items != its || old.discount != preview.discount || old.taxPct != preview.taxPct)) {
                    hist = hist + (fmtDT(System.currentTimeMillis()) + ": previous total " + fmtMoney(old.total) + " (" +
                        old.items.joinToString { it.desc + " ×" + it.qty } + ")")
                }
                val saved = base.copy(customerId = cust, title = title.trim(), items = its, discount = preview.discount, taxPct = preview.taxPct,
                    status = status, validUntil = valid, notes = notes.trim(), history = hist)
                Store.put(Store.quotes, saved)
                if (old == null) Nav.replace(Screen.QuoteDetail(saved.id)) else Nav.back()
            }
        }
    }
    if (pickC) PickCustomer({ cust = it.id; pickC = false }, { pickC = false })
}

@Composable
fun QuoteDetailScreen(id: String) {
    val ctx = LocalContext.current
    val q = Store.quotes.find { it.id == id }
    if (q == null) { Page("Quotation", back = true) { Empty("This quotation no longer exists.") }; return }
    var deleting by remember { mutableStateOf(false) }
    Page(q.number, back = true, actions = { RoundIcon(Icons.Default.Edit) { Nav.go(Screen.QuoteEdit(id)) } }) {
        Glass {
            T(Store.settings.business, 15, true, Accent)
            T("QUOTATION " + q.number + " • " + fmtDate(q.created), 11, color = Muted)
            Spacer(Modifier.height(8.dp))
            T("For " + cname(q.customerId), 15, true)
            if (q.title.isNotBlank()) T(q.title, 13, color = Muted)
            Spacer(Modifier.height(10.dp))
            q.items.forEach {
                Row(Modifier.padding(vertical = 3.dp)) {
                    T(it.desc + " × " + it.qty, 13, modifier = Modifier.weight(1f)); T(fmtMoney(it.total), 13)
                }
            }
            Spacer(Modifier.height(8.dp))
            if (q.discount > 0) Row { T("Discount", 13, color = Muted, modifier = Modifier.weight(1f)); T("-" + fmtMoney(q.discount), 13) }
            if (q.tax > 0) Row { T("Tax (" + q.taxPct + "%)", 13, color = Muted, modifier = Modifier.weight(1f)); T(fmtMoney(q.tax), 13) }
            Row { T("Total", 17, true, modifier = Modifier.weight(1f)); T(fmtMoney(q.total), 17, true, Accent) }
            if (q.validUntil > 0) T("Valid until " + fmtDate(q.validUntil), 12, color = Muted)
            if (q.notes.isNotBlank()) { Spacer(Modifier.height(8.dp)); T(q.notes, 12, color = Muted) }
        }
        T("Status", 12, color = Muted)
        ChipRow(listOf("Draft", "Sent", "Negotiating", "Accepted", "Rejected"), q.status) { Store.put(Store.quotes, q.copy(status = it)) }
        if (q.effStatus() == "Expired") Tag("Expired — validity date passed", Danger)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PBtn("Share PDF", Modifier.weight(1f), icon = Icons.Default.Share) {
                try { shareFile(ctx, PdfMaker.make(ctx, q), "application/pdf") } catch (e: Exception) { toast(ctx, "Could not create PDF") }
            }
            PBtn("Share text", Modifier.weight(1f), filled = false) { shareText(ctx, quoteText(q)) }
        }
        if (q.history.isNotEmpty()) {
            Section("Previous versions")
            q.history.reversed().forEach { Glass { T(it, 12, color = Muted) } }
        }
        PBtn("Delete quotation", Modifier.fillMaxWidth(), filled = false, danger = true) { deleting = true }
    }
    if (deleting) Confirm("Delete ${q.number}?", "Its revision history will be lost too.", onYes = { deleting = false; Nav.back(); Store.remove(Store.quotes, id) }, onNo = { deleting = false })
}
