package com.exorm.app

import android.app.Application
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

class ExormApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Reminders.channel(this)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        Store.init(ctx)
        val key = i.getStringExtra("key") ?: return
        if (!Reminders.valid(key)) return
        Reminders.channel(ctx)
        val open = Intent(ctx, MainActivity::class.java)
            .putExtra("customerId", i.getStringExtra("cust"))
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(ctx, key.hashCode(), open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, Reminders.CH)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(i.getStringExtra("title"))
            .setContentText(i.getStringExtra("text"))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try { ctx.getSystemService(NotificationManager::class.java).notify(key.hashCode(), n) } catch (e: SecurityException) { }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            Store.init(ctx)
            Reminders.sync(ctx)
        }
    }
}
