package com.exorm.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

val LEAD_STATUSES = listOf("New", "Called", "Replied", "Talked", "Follow-up", "Not interested")

@Composable
fun LeadsScreen() {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf("Today") }
    var editing by remember { mutableStateOf<Lead?>(null) }
    var editingNew by remember { mutableStateOf(false) }
    var testDlg by remember { mutableStateOf(false) }
    var askPhone by remember { mutableStateOf<Lead?>(null) }
    var dup by remember { mutableStateOf<Pair<Lead, Customer>?>(null) }
    var delFor by remember { mutableStateOf<Lead?>(null) }
    var resetDlg by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { AutoCall.on = AutoCall.readOn() }

    val t0 = startOfDay(System.currentTimeMillis())
    val all = Store.leads.sortedByDescending { it.received }
    val today = all.filter { it.received >= t0 && it.status != "Not interested" }
    val shown = if (tab == "Today") today else all
    val todayLabel = "Today (" + today.size + ")"
    val allLabel = "All time (" + all.size + ")"

    // ---- Confirmed flow: only this makes a real Customer ----
    fun finish(l: Lead, c: Customer) {
        Store.put(Store.leads, l.copy(status = "Converted", convertedCustomerId = c.id))
    }
    fun createCustomer(l: Lead) {
        val extra = (if (l.place.isNotBlank()) " - " + l.place else "") + (if (l.note.isNotBlank()) ". " + l.note else "")
        val c = Customer(name = l.name.trim(), phone = l.phone.trim(), requirement = l.service, notes = "From JustDial lead" + extra)
        Store.put(Store.customers, c)
        finish(l, c)
        toast(ctx, "Customer created")
    }
    fun checkDuplicate(l: Lead) {
        val d = digits(l.phone).takeLast(10)
        val match = Store.customers.find { digits(it.phone).takeLast(10) == d }
        if (match != null) dup = Pair(l, match) else createCustomer(l)
    }
    fun startConfirm(l: Lead) {
        if (digits(l.phone).length < 5) askPhone = l else checkDuplicate(l)
    }

    Page("Leads", back = true) {
        T("Leads are NOT customers. A lead becomes a customer only when you tap Confirmed. Until then it stays out of Customers, Follow-ups, Calendar, Reports and Home totals.", 12, color = Muted)
        Glass {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Auto-call new JustDial leads", 17, true)
                    T(if (AutoCall.on) "ON - new leads are called" else "OFF - new leads are only recorded", 13, color = if (AutoCall.on) Good else Muted)
                }
                Switch(checked = AutoCall.on, modifier = Modifier.scale(1.4f).padding(end = 8.dp),
                    colors = SwitchDefaults.colors(checkedTrackColor = Accent, checkedThumbColor = Color.Black),
                    onCheckedChange = { v ->
                        if (v) {
                            val miss = AutoCall.missingForOn()
                            if (miss.isEmpty()) AutoCall.switchOn(true)
                            else {
                                toast(ctx, "Finish the setup first: " + miss.joinToString(", "))
                                Nav.go(Screen.LeadSetup)
                            }
                        } else AutoCall.switchOn(false)
                    })
            }
            if (AutoCall.status.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                T(AutoCall.status, 12, color = Muted)
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PBtn("Setup checklist", Modifier.weight(1f), filled = false) { Nav.go(Screen.LeadSetup) }
                if (AutoCall.soundOn) PBtn("Stop sound", Modifier.weight(1f), danger = true) { AutoCall.stopSound() }
            }
        }
        Glass {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Auto WhatsApp message", 17, true)
                    T(if (AutoCall.waState) "ON - sent after the call" else "OFF", 13, color = if (AutoCall.waState) Good else Muted)
                }
                Switch(checked = AutoCall.waState, modifier = Modifier.scale(1.4f).padding(end = 8.dp),
                    colors = SwitchDefaults.colors(checkedTrackColor = Accent, checkedThumbColor = Color.Black),
                    onCheckedChange = { v ->
                        if (v && !AutoCall.accessibilityOn()) {
                            toast(ctx, "Turn on Accessibility first")
                            Nav.go(Screen.LeadSetup)
                        } else AutoCall.switchWa(v)
                    })
            }
            Spacer(Modifier.height(8.dp))
            var wt by remember { mutableStateOf(AutoCall.waText()) }
            TF("Message ({name} = customer name, {biz} = your business)", wt, { wt = it; AutoCall.setWaText(it) }, lines = 4)
            if (AutoCall.waStatus.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                T(AutoCall.waStatus, 12, color = Muted)
            }
            Spacer(Modifier.height(6.dp))
            T("Sent only after the call ends and the number is known, once per number, and only while Auto-call is ON. EXORM opens WhatsApp and taps Send for you; the phone must be unlocked. Automated messages are against WhatsApp rules, so keep the text short and send only to people who enquired. Not tested on a phone yet.", 11, color = Muted)
        }
        T("Each customer is auto-called only once. The phone screen must be on and unlocked, and a JustDial app update can break the tapping. If a call cannot be made the lead says Failed with the reason and you can use the Call button on the card. This part is new and not tested on a phone yet.", 11, color = Muted)
        ChipRow(listOf(todayLabel, allLabel), if (tab == "Today") todayLabel else allLabel) { tab = if (it == todayLabel) "Today" else "All time" }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PBtn("Add lead", Modifier.weight(1f), icon = Icons.Default.Add) { editingNew = true; editing = Lead() }
            PBtn("Test lead", Modifier.weight(1f), filled = false) { testDlg = true }
        }
        PBtn("Reset called list (" + AutoCall.calledCount + ")", Modifier.fillMaxWidth(), filled = false) { resetDlg = true }
        if (shown.isEmpty()) {
            Empty(if (tab == "Today") "No leads today. Leads marked Not interested are hidden here but stay in All time." else "No leads yet. Tap Add lead.")
        }
        shown.forEach { l ->
            LeadCard(l, onConfirm = { startConfirm(it) }, onEdit = { editingNew = false; editing = it }, onDelete = { delFor = it })
        }
    }

    editing?.let { l -> LeadDialog(l, editingNew) { editing = null } }
    if (testDlg) TestLeadDialog { testDlg = false }

    askPhone?.let { l ->
        var p by remember { mutableStateOf("") }
        var err by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { askPhone = null }, containerColor = DialogBg, title = { Text("Type the phone number first") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("This lead has no number yet. Type it, then the customer will be created.")
                    TF("Phone *", p, { p = it }, kb = KeyboardType.Phone)
                    if (err.isNotBlank()) T(err, 13, color = Danger)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (digits(p).length < 5) err = "Enter a valid phone number"
                    else {
                        val updated = l.copy(phone = p.trim())
                        Store.put(Store.leads, updated)
                        askPhone = null
                        checkDuplicate(updated)
                    }
                }) { Text("Continue", color = Accent) }
            },
            dismissButton = { TextButton(onClick = { askPhone = null }) { Text("Cancel") } })
    }

    dup?.let { pair ->
        val l = pair.first
        val c = pair.second
        AlertDialog(onDismissRequest = { dup = null }, containerColor = DialogBg, title = { Text("Phone number already exists") },
            text = { Text(c.name + " already uses this number. Link this lead to that customer, or create a new customer anyway?") },
            confirmButton = { TextButton(onClick = { dup = null; finish(l, c); toast(ctx, "Linked to " + c.name) }) { Text("Use existing", color = Accent) } },
            dismissButton = {
                Row {
                    TextButton(onClick = { dup = null }) { Text("Cancel") }
                    TextButton(onClick = { dup = null; createCustomer(l) }) { Text("Save anyway") }
                }
            })
    }

    if (resetDlg) {
        Confirm("Reset the called list?", "EXORM will forget who it already called or messaged, so it may call and message the same customers again if they enquire again. Your leads are not deleted.",
            ok = "Reset", onYes = { resetDlg = false; AutoCall.resetCalled() }, onNo = { resetDlg = false })
    }

    delFor?.let { l ->
        Confirm("Delete this lead?", l.name.ifBlank { "This lead" } + " will be removed from Leads. A customer already made from it is kept.",
            onYes = { delFor = null; Store.remove(Store.leads, l.id) }, onNo = { delFor = null })
    }
}

@Composable
fun LeadCard(l: Lead, onConfirm: (Lead) -> Unit, onEdit: (Lead) -> Unit, onDelete: (Lead) -> Unit) {
    val ctx = LocalContext.current
    val cust = if (l.convertedCustomerId.isBlank()) null else Store.customers.find { it.id == l.convertedCustomerId }
    val hasPhone = digits(l.phone).length >= 5
    Glass {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                T(l.name.ifBlank { "No name" }, 16, true, maxLines = 1)
                if (l.place.isNotBlank()) T(l.place, 13, color = Muted, maxLines = 2)
                if (l.service.isNotBlank()) T(l.service, 13, color = Teal, maxLines = 1)
                Spacer(Modifier.height(4.dp))
                T(fmtDT(l.received), 12, color = Accent)
                T(if (l.phone.isNotBlank()) "Number: " + l.phone else "Number: not known yet", 12, color = Muted)
            }
            if (hasPhone) RoundIcon(Icons.Default.Call, androidx.compose.ui.graphics.Color.Black, Accent) { dial(ctx, l.phone) }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            val cr = l.callResult
            Tag(cr.ifBlank { "Not called" }, if (cr == "Called") Good else if (cr.startsWith("Failed")) Danger else Muted)
            if (cust != null) Tag("Converted", Good)
            if (l.test) Tag("Test", Teal)
        }
        if (l.waResult.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            T("WhatsApp: " + l.waResult, 12, color = if (l.waResult.startsWith("Failed")) Danger else if (l.waResult.startsWith("Skipped")) Muted else Good)
        }
        if (l.note.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            T("Note: " + l.note, 12, color = Muted)
        }
        Spacer(Modifier.height(8.dp))
        if (cust != null) {
            T("Customer: " + cust.name, 13, true)
            Spacer(Modifier.height(6.dp))
            PBtn("Open customer", Modifier.fillMaxWidth(), filled = false) { Nav.go(Screen.CustomerDetail(cust.id)) }
        } else {
            ChipRow(LEAD_STATUSES, if (l.status == "Converted") "" else l.status) { Store.put(Store.leads, l.copy(status = it)) }
            if (l.convertedCustomerId.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                T("The customer made from this lead was deleted. You can tap Confirmed again.", 11, color = Muted)
            }
            if (hasPhone) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("WhatsApp", false) { whatsapp(ctx, l.phone) }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (cust == null) PBtn("Confirmed", Modifier.weight(1f), icon = Icons.Default.Check) { onConfirm(l) }
            PBtn("Edit / note", Modifier.weight(1f), filled = false, icon = Icons.Default.Edit) { onEdit(l) }
            RoundIcon(Icons.Default.Delete, Danger, size = 40.dp) { onDelete(l) }
        }
    }
}

@Composable
fun LeadDialog(lead: Lead, isNew: Boolean, onClose: () -> Unit) {
    var name by remember { mutableStateOf(lead.name) }
    var place by remember { mutableStateOf(lead.place) }
    var service by remember { mutableStateOf(lead.service) }
    var phone by remember { mutableStateOf(lead.phone) }
    var note by remember { mutableStateOf(lead.note) }
    var at by remember { mutableStateOf(lead.received) }
    var err by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, containerColor = DialogBg, title = { Text(if (isNew) "Add lead" else "Edit lead") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                TF("Name *", name, { name = it })
                TF("Place", place, { place = it })
                TF("Service / category", service, { service = it })
                TF("Phone number (can stay empty)", phone, { phone = it }, kb = KeyboardType.Phone)
                DateField("Received", at, true) { at = it }
                TF("Note (anything else)", note, { note = it }, lines = 3)
                if (err.isNotBlank()) T(err, 13, color = Danger)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) err = "Enter a name"
                else if (phone.isNotBlank() && digits(phone).length < 5) err = "Phone number looks too short"
                else {
                    Store.put(Store.leads, lead.copy(name = name.trim(), place = place.trim(), service = service.trim(), phone = phone.trim(),
                        note = note.trim(), received = if (at > 0) at else System.currentTimeMillis()))
                    onClose()
                }
            }) { Text("Save", color = Accent) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } })
}

@Composable
fun TestLeadDialog(onClose: () -> Unit) {
    var num by remember { mutableStateOf("0000000000") }
    var err by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, containerColor = DialogBg, title = { Text("Add a test lead?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("This adds a fake lead called \"Test Customer\" and runs the same steps as a real lead. If the Auto-call switch is ON it plays the loud sound and places a REAL call to the number below (it dials the number directly, so it does not test the JustDial tapping). If the Auto WhatsApp switch is also ON, a WhatsApp message goes to that number after the call. If the switch is OFF the lead is saved as \"Skipped: switch OFF\". Use your own number if you want to test calling.")
                TF("Test phone number", num, { num = it }, kb = KeyboardType.Phone)
                if (err.isNotBlank()) T(err, 13, color = Danger)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (digits(num).length < 5) err = "Enter a valid number"
                else {
                    AutoCall.runTest(Lead(name = "Test Customer", place = "Test Area, Delhi", service = "Test enquiry",
                        phone = num.trim(), note = "Fake lead made with the Test lead button", test = true))
                    onClose()
                }
            }) { Text("Add test lead", color = Accent) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } })
}
